"""
app.py
------
Reezeium Imager — entry point.

Three run modes:
    1. CLI         (--cli)            Headless forensic capture
    2. Web Server  (default, script)  Flask on localhost + auto-open browser
    3. Desktop App (frozen .exe)      pywebview native window hosting Flask
"""

from flask import Flask
import argparse
import sys
import datetime
import os
import platform
import webbrowser
import threading
import logging

from routes import api
from core import engine, cpu_sampler


# --- Logging configuration ----------------------------------------------------
# Forensic audit trail: log to both console and a file. The file lives next to
# the project so investigators can preserve it as evidence alongside dumps.

LOG_FORMAT = '%(asctime)s [%(levelname)s] %(name)s: %(message)s'

logging.basicConfig(
    level=logging.INFO,
    format=LOG_FORMAT,
    handlers=[
        logging.FileHandler('reezium.log'),
        logging.StreamHandler(),
    ],
)

logger = logging.getLogger('reezium.app')


# --- Flask app ---------------------------------------------------------------

app = Flask(__name__)
app.register_blueprint(api)



BANNER = r"""
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   ██████╗ ███████╗███████╗███████╗██╗██╗   ██╗███╗   ███╗     ║
║   ██╔══██╗██╔════╝██╔════╝╚══███╔╝██║██║   ██║████╗ ████║     ║
║   ██████╔╝█████╗  █████╗    ███╔╝ ██║██║   ██║██╔████╔██║     ║
║   ██╔══██╗██╔══╝  ██╔══╝   ███╔╝  ██║██║   ██║██║╚██╔╝██║     ║
║   ██║  ██║███████╗███████╗███████╗██║╚██████╔╝██║ ╚═╝ ██║     ║
║   ╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝╚═╝ ╚═════╝ ╚═╝     ╚═╝     ║
║                   ▀▀ I M A G E R ▀▀                           ║
║                                                               ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
"""


# --- Entry point -------------------------------------------------------------

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description="Reezium Imager: Memory Acquisition & Threat Hunt Tool"
    )
    parser.add_argument('--cli', action='store_true',
                        help="Run in Headless CLI Mode (Low Footprint)")
    parser.add_argument('--case', default="CASE001",
                        help="Case ID for metadata")
    parser.add_argument('--format', default="raw",
                        choices=['raw', 'lime', 'mem'],
                        help="Output format")
    parser.add_argument('--output',
                        help="Custom output filename (optional)")

    # parse_known_args avoids conflicts with the Flask reloader's own argv
    args, unknown = parser.parse_known_args()

    print(BANNER)

    # ---------------------------------------------------------------- CLI MODE
    if args.cli:
        print("\n[!] RUNNING IN HEADLESS MODE (Best for Forensics)")
        print("[*] Minimizing memory footprint...")

        # CLI mode doesn't need the CPU sampler — it doesn't run the UI.

        run_wizard = (args.case == "CASE001" and args.output is None)
        case_id = args.case
        fmt = args.format
        output = args.output

        if run_wizard:
            print("\n[?] INTERACTIVE CAPTURE WIZARD")
            print("    (Press ENTER to accept defaults)\n")
            try:
                i_case = input(f"    Case ID [{case_id}]: ").strip()
                if i_case:
                    case_id = i_case
                i_fmt = input(
                    f"    Output Format (raw/lime/mem) [{fmt}]: "
                ).strip().lower()
                if i_fmt and i_fmt in ['raw', 'lime', 'mem']:
                    fmt = i_fmt
                print(f"\n[+] Configuration: Case={case_id}, Format={fmt}")
                confirm = input("    Start Capture? [Y/n]: ").strip().lower()
                if confirm == 'n':
                    sys.exit(0)
            except KeyboardInterrupt:
                sys.exit(0)

        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = output if output else f"{case_id}_{timestamp}.{fmt}"

        if getattr(sys, 'frozen', False):
            save_dir = os.path.dirname(sys.executable)
        else:
            save_dir = os.path.dirname(os.path.abspath(__file__))

        output_path = os.path.join(save_dir, filename)

        options = {
            "case_id":      case_id,
            "investigator": os.getlogin(),
            "format":       fmt,
            "timestamp":    datetime.datetime.now().isoformat(),
        }

        try:
            engine.run_capture(output_path, options, is_cli=True)
            sys.exit(0)
        except Exception:
            sys.exit(1)

    # ----------------------------------------------------------- GUI MODES
    else:
        is_admin = engine.is_admin()
        if is_admin:
            print("[+] Admin Privileges: DETECTED (Ready for Capture)")
        else:
            print("[-] Admin Privileges: MISSING (Capture Disabled)")
            print("    Please Run as Administrator.")

        # Start the background CPU sampler before serving any request.
        # This keeps cpu_percent() readings warm so /api/processes,
        # /api/stats, and /api/suspicious return real values from the
        # first call instead of zeros.
        logger.info("Starting background CPU sampler...")
        cpu_sampler.start()

        is_frozen = getattr(sys, 'frozen', False)

        if is_frozen:
            # DESKTOP APP — frozen binary built by PyInstaller.
            #
            # On Windows: pywebview opens a native window via Edge WebView2,
            # which ships with Windows 10/11. No extra packages needed.
            #
            # On Linux: pywebview needs GTK+WebKit2 or Qt+QtWebEngine on the
            # system to render. These cannot reliably be bundled by
            # PyInstaller, so the bundled binary will hit a backend-init
            # failure even though pywebview itself is installed. We therefore
            # skip pywebview entirely on Linux and use the browser fallback,
            # which matches the convention of Linux forensic tools (Volatility
            # web UI, MISP, Velociraptor, GRR — all browser-based).
            #
            # The try/except below catches BOTH cases:
            #   - ImportError (pywebview not installed at all)
            #   - WebViewException / RuntimeError (pywebview installed but
            #     no GTK/Qt backend available)
            print("\n[!] RUNNING IN DESKTOP APP MODE")

            def _launch_browser_fallback(reason):
                """Open the dashboard in the user's default browser."""
                logger.info("Launching browser fallback: %s", reason)
                print(f"[*] {reason}")
                print("[*] Opening dashboard in your default browser at "
                      "http://127.0.0.1:5000")
                threading.Timer(
                    1.5,
                    lambda: webbrowser.open_new("http://127.0.0.1:5000/")
                ).start()
                app.run(debug=False, host='127.0.0.1', port=5000,
                        use_reloader=False, threaded=True)

            # On Linux, we know pywebview's GTK/Qt backends will not be
            # bundled with the PyInstaller binary, so we skip the attempt
            # entirely and go straight to the browser fallback. This avoids
            # spamming the terminal with backend-failure tracebacks.
            current_os = platform.system()
            if current_os == 'Linux':
                _launch_browser_fallback(
                    "Linux platform — using browser-based dashboard "
                    "(standard for Linux forensic tools)."
                )
            else:
                # On Windows, attempt the native window first.
                try:
                    import webview
                    webview.create_window(
                        "Reezium Imager", app, width=1280, height=800
                    )
                    webview.start()
                except ImportError:
                    _launch_browser_fallback(
                        "pywebview not installed — using browser mode."
                    )
                except Exception as e:
                    # Catches webview.errors.WebViewException, RuntimeError,
                    # and any other backend-initialisation failure. Keeps the
                    # exception name visible so the user understands what
                    # happened, but doesn't crash the program.
                    _launch_browser_fallback(
                        f"Native window unavailable ({type(e).__name__}) "
                        f"— using browser mode."
                    )
        else:
            # WEB SERVER MODE — used during development
            print("\n[!] RUNNING IN WEB SERVER MODE (Developer/Browser)")
            print("[*] Access at: http://127.0.0.1:5000")

            def open_dashboard():
                webbrowser.open_new("http://127.0.0.1:5000/")

            threading.Timer(1.5, open_dashboard).start()
            # Bound to 127.0.0.1 only — never expose forensic tooling
            # to the LAN. Bind to 0.0.0.0 only if you understand the
            # security implications.
            app.run(debug=False, host='127.0.0.1', port=5000,
                    use_reloader=False, threaded=True)