"""
routes/memory.py
----------------
UC06 — Inspect Memory (Memory Map page)

This module backs the Memory Map page and covers two distinct sub-functions:

1. /api/memory  —  System memory overview  (always executed on page load)
   - Reads host virtual memory totals (total, used, available, percent) via
     psutil.virtual_memory().  These are real, measured values.
   - Lists up to 20 processes whose resident set size (RSS) exceeds 50 MB.
     Processes below that threshold are filtered out to keep the list useful.
     The RSS values shown are real, measured host values.
   - Returns a 'regions' breakdown of system-level memory categories:
       Used, Available, Swap Used, Swap Free — real values on all platforms.
       Cached, Buffers — real values on Linux/macOS only; omitted on Windows.

2. /api/dump/<pid>  —  PID inspector  (optional, triggered by user input)
   - Accepts a PID entered by the investigator in the Process Memory Inspector
     panel.  This is an <<extend>> use case — it only runs when a valid PID
     is submitted.
   - Returns the process name, resident memory (RSS in MB), up to 20 open
     file paths, and up to 20 unique loaded library paths that the tool can
     access.  Access-denied paths are silently skipped.
   - Does NOT return raw process memory bytes, virtual address maps, or
     per-segment heap/stack/code breakdown.

Data accuracy note
------------------
All values surfaced by /api/memory are real host measurements.  The older
Heap/Stack/Code illustrative proportions have been removed.  The regions
table now shows genuine OS-reported memory categories.
"""

from flask import jsonify
import psutil
import logging

from . import api

logger = logging.getLogger('reezium.routes')


@api.route('/api/memory')
def api_memory():
    """
    UC06 — Read memory statistics + List top memory users + Show regions.

    Returns
    -------
    total, available, used (GB), percent : real virtual-memory stats.
    top_processes : up to 20 processes with RSS > 50 MB, sorted descending.
    regions : real system memory breakdown (Used, Available, Swap, and on
              Linux/macOS also Cached/Buffers).
    """
    try:
        mem = psutil.virtual_memory()

        # Top memory users (filter out tiny processes to keep the list useful).
        top = []
        for p in psutil.process_iter(['pid', 'name', 'memory_info']):
            try:
                mb = p.info['memory_info'].rss / 1024 / 1024
                if mb > 50:
                    top.append({
                        'pid': p.info['pid'],
                        'name': p.info['name'],
                        'memory': round(mb, 2),
                    })
            except (psutil.NoSuchProcess, psutil.AccessDenied,
                    psutil.ZombieProcess, AttributeError):
                pass
        top.sort(key=lambda x: x['memory'], reverse=True)

        # Real system-level memory breakdown from psutil.
        # 'cached' and 'buffers' are Linux/macOS only; not available on Windows.
        swap = psutil.swap_memory()
        regions = [
            {'name': 'Used',      'size': f'{round(mem.used      / 1024**3, 2)} GB', 'type': 'RAM'},
            {'name': 'Available', 'size': f'{round(mem.available / 1024**3, 2)} GB', 'type': 'RAM'},
            {'name': 'Swap Used', 'size': f'{round(swap.used     / 1024**3, 2)} GB', 'type': 'Swap'},
            {'name': 'Swap Free', 'size': f'{round(swap.free     / 1024**3, 2)} GB', 'type': 'Swap'},
        ]
        # Cached + buffers are available on Linux/macOS only
        if hasattr(mem, 'cached'):
            regions.insert(2, {'name': 'Cached', 'size': f'{round(mem.cached / 1024**3, 2)} GB', 'type': 'RAM'})
        if hasattr(mem, 'buffers'):
            regions.insert(3, {'name': 'Buffers', 'size': f'{round(mem.buffers / 1024**3, 2)} GB', 'type': 'RAM'})

        return jsonify({
            'total':     round(mem.total / 1024**3, 2),
            'available': round(mem.available / 1024**3, 2),
            'used':      round(mem.used / 1024**3, 2),
            'percent':   mem.percent,
            'top_processes': top[:20],
            'regions': regions,
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500



@api.route('/api/dump/<int:pid>')
def api_dump(pid):
    """
    UC06 (extend) — Inspect process files and libraries.

    Triggered only when the investigator submits a valid PID in the Process
    Memory Inspector panel.  Returns process name, RSS, up to 20 open file
    paths, and up to 20 unique loaded library paths accessible to this tool.
    Access-denied paths are silently skipped.  Raw memory bytes and virtual
    address maps are not returned.
    """
    try:
        p = psutil.Process(pid)

        files = []
        try:
            for f in p.open_files():
                files.append(f.path)
        except (psutil.AccessDenied, OSError):
            pass

        libs = []
        try:
            for m in p.memory_maps():
                libs.append(m.path)
        except (psutil.AccessDenied, OSError):
            pass

        return jsonify({
            'pid': pid,
            'name': p.name(),
            'memory_mb': round(p.memory_info().rss / 1024 / 1024, 2),
            'files': files[:20],
            'libs': list(set(libs))[:20],
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500
