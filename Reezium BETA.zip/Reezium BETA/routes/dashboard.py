"""
routes/dashboard.py
-------------------
Home page (renders index.html) and the live-stats endpoint used by the
dashboard widgets (CPU/RAM/process/connection counters).

The "SYSTEM HEALTH" badge on the dashboard now uses the SAME detection
engine as the Threat Hunt page (in statistical mode — skipping ML to
keep the 2-second poll cheap). This eliminates the previous
inconsistency where the badge showed "1 THREAT" but the Threat Hunt
page showed zero, because the badge was just counting processes with
>80% CPU regardless of whether they were legitimate.

Performance note
----------------
The threat count is cached for THREAT_CACHE_TTL seconds so the 2-second
dashboard poll doesn't re-run the full statistical scan on every tick.
The scan itself is now ~10 ms (after the ML enrichment guard was added
to scorer.py), but caching still avoids unnecessary process enumeration
on every single poll.
"""

from flask import render_template, jsonify
import psutil
import time
import datetime
import logging

from . import api
from core.detection import scorer

logger = logging.getLogger('reezium.routes')


# --- Threat count cache for the dashboard badge ----------------------------
# Running the full statistical scan every 2 seconds is wasteful. The threat
# count doesn't change that fast — caching it for 15 seconds is accurate
# enough for the dashboard badge while dramatically reducing CPU load.

THREAT_CACHE_TTL = 15   # seconds

_threat_cache = {
    'count': 0,
    'timestamp': 0,
}


def _get_cached_threat_count():
    """Return the cached threat count, refreshing if stale."""
    now = time.time()
    if now - _threat_cache['timestamp'] > THREAT_CACHE_TTL:
        try:
            threats = scorer.run_threat_scan(mode='statistical')
            _threat_cache['count'] = len(threats)
        except Exception as e:
            logger.warning("Quick threat count failed: %s", e)
            # Keep the previous count on failure rather than resetting to 0
        _threat_cache['timestamp'] = now
    return _threat_cache['count']


@api.route('/')
def home():
    """Render the single-page UI."""
    return render_template('index.html')


@api.route('/api/stats')
def api_stats():
    """Return live system stats for the dashboard widgets.

    The 'suspicious_count' field reflects the real detection engine
    (statistical mode, no ML). The count is cached for 15 seconds so
    the 2-second dashboard poll stays lightweight.
    """
    try:
        cpu = psutil.cpu_percent(interval=0.1)
        ram = psutil.virtual_memory().percent
        proc_count = len(psutil.pids())

        conn_count = 0
        try:
            conn_count = len(psutil.net_connections(kind='inet'))
        except (psutil.AccessDenied, OSError):
            pass

        suspicious_count = _get_cached_threat_count()

        boot_time = psutil.boot_time()
        uptime = str(datetime.timedelta(seconds=int(time.time() - boot_time)))

        return jsonify({
            'cpu': cpu,
            'ram': ram,
            'process_count': proc_count,
            'connection_count': conn_count,
            'suspicious_count': suspicious_count,
            'uptime': uptime,
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500