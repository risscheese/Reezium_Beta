"""
routes/threat_hunt.py
---------------------
Endpoints for the Threat Hunt and Event Timeline views.

Three threat-hunt endpoints:

    GET /api/suspicious                 — default (hybrid mode)
    GET /api/suspicious?mode=statistical  — Modified Z-Score only
    GET /api/suspicious?mode=ml           — Isolation Forest only
    GET /api/suspicious?mode=hybrid       — both, same as default

    GET /api/suspicious/compare         — runs all three modes and
                                          returns a side-by-side diff
                                          (used by FYP evaluation chapter)

The heavy lifting lives in core.detection.scorer. This route file is
purely HTTP plumbing.
"""

from flask import jsonify, request
import psutil
import datetime
import logging

from . import api
from core.detection import scorer
from core.cloud.threat_intel import intel_client

logger = logging.getLogger('reezium.routes')


VALID_MODES = {'statistical', 'ml', 'hybrid'}


@api.route('/api/suspicious')
def api_suspicious():
    """Run the threat-hunt pipeline and return ranked threats.

    Optional query parameters:
        ?mode=statistical | ml | hybrid   (default: hybrid)
        ?enrich=true                      (add cloud threat intel)

    Each threat in the response includes structured MITRE ATT&CK data:
        mitre_techniques: list of {id, name, tactic, url} dicts
        mitre_tactics:    list of unique tactic names (e.g. "Defense Evasion")
    These fields are empty lists for purely statistical/ML anomalies.

    When enrich=true, threats may also include a 'cloud_intel' key with
    VirusTotal and/or AbuseIPDB enrichment data.
    """
    mode = request.args.get('mode', 'hybrid').lower()
    if mode not in VALID_MODES:
        mode = 'hybrid'

    enrich = request.args.get('enrich', 'true').lower() == 'true'

    try:
        threats = scorer.run_threat_scan(mode=mode)

        # Optional cloud enrichment — only when explicitly requested
        # to avoid slowing down the default 10-second auto-refresh.
        if enrich and intel_client.is_configured():
            try:
                connections = {}
                for c in psutil.net_connections(kind='inet'):
                    if c.pid:
                        connections.setdefault(int(c.pid), []).append(c)
                intel_client.enrich_threats(threats, connections)
            except Exception as e:
                logger.warning("Cloud enrichment failed (non-fatal): %s", e)

        return jsonify({
            'mode': mode,
            'threats': threats,
        })
    except Exception as e:
        logger.error("Threat scan failed (mode=%s): %s", mode, e)
        return jsonify({'error': str(e)}), 500


@api.route('/api/suspicious/compare')
def api_suspicious_compare():
    """Run all three detection modes on the current process snapshot.

    Returns each mode's threat list plus a summary with agreement/
    disagreement statistics. This is the dedicated endpoint for the FYP
    evaluation chapter — front-end tooling or a notebook can poll this
    repeatedly to gather comparative data.
    """
    try:
        result = scorer.compare_modes()
        return jsonify(result)
    except Exception as e:
        logger.error("Mode-comparison scan failed: %s", e)
        return jsonify({'error': str(e)}), 500


@api.route('/api/timeline')
def api_timeline():
    """Build a creation-time timeline of all running processes."""
    timeline = []
    try:
        for p in psutil.process_iter(['pid', 'name', 'create_time']):
            try:
                t = datetime.datetime.fromtimestamp(p.info['create_time'])
                timeline.append({
                    'time': t.strftime('%H:%M:%S'),
                    'event': f"Process Started: {p.info['name']}",
                    'details': f"PID: {p.info['pid']} | {t.strftime('%Y-%m-%d')}",
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied,
                    psutil.ZombieProcess, OSError, ValueError):
                pass
        timeline.sort(key=lambda x: x['time'], reverse=True)
        return jsonify(timeline[:50])
    except Exception as e:
        logger.error("Timeline failed: %s", e)
        return jsonify([])