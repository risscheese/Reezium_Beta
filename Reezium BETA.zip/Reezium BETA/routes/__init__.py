"""Reezeium Imager — routes package.

Creates the shared Flask Blueprint (`api`) and imports every route module
so that their @api.route() decorators register on the blueprint.
"""

from flask import Blueprint

api = Blueprint('api', __name__)

# Import all route modules so their decorators register on the blueprint.
# These must come AFTER the blueprint is created to avoid circular imports.
from . import dashboard    # noqa: E402, F401
from . import capture      # noqa: E402, F401
from . import connections  # noqa: E402, F401
from . import memory       # noqa: E402, F401
from . import processes    # noqa: E402, F401
from . import system       # noqa: E402, F401
from . import threat_hunt  # noqa: E402, F401
from . import threat_intel  # noqa: E402, F401
from . import ai_assistant  # noqa: E402, F401
