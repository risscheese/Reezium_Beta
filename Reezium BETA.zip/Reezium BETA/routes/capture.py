"""
routes/capture.py
-----------------
Endpoints that drive the RAM Capture view in the UI:
    /api/capture/info     — pre-flight info (admin status, RAM size, etc.)
    /api/capture/start    — kicks off acquisition in a background thread
    /api/capture/status   — polled by the UI for progress updates
    /api/download/<file>  — serves the completed dump for browser download
    /api/reveal/<file>    — opens Explorer/Finder at the dump location (EXE mode)
"""

from flask import jsonify, request, send_file
import psutil
import platform
import datetime
import time
import os
import sys
import re
import threading
import subprocess
import logging

from . import api
from core.capture_engine import engine

logger = logging.getLogger('reezium.routes')

# Regex for valid filenames — only alphanumeric, underscores, hyphens, dots
SAFE_FILENAME_RE = re.compile(r'^[\w\-. ]+$')


def _validate_filename(filename):
    """Validate that a filename is safe (no path traversal or shell injection).

    Returns True if safe, False otherwise.
    """
    if not filename:
        return False
    # Block path traversal
    if '..' in filename or '/' in filename or '\\' in filename:
        return False
    # Block shell metacharacters
    if not SAFE_FILENAME_RE.match(filename):
        return False
    return True


@api.route('/api/capture/info')
def api_capture_info():
    """Pre-flight info for the Capture view's 'Target System' widget."""
    mem = psutil.virtual_memory()
    boot_time = psutil.boot_time()
    uptime = str(datetime.timedelta(seconds=int(time.time() - boot_time)))
    return jsonify({
        'hostname': platform.node(),
        'os': f"{platform.system()} {platform.release()}",
        'ram_total': f"{round(mem.total / 1024**3, 2)} GB",
        'uptime': uptime,
        'is_admin': engine.is_admin(),
        'is_exe': getattr(sys, 'frozen', False),
    })


@api.route('/api/capture/start', methods=['POST'])
def api_capture_start():
    """Begin a capture in a background thread so the HTTP request returns
    immediately. The UI then polls /api/capture/status.
    """
    if engine.status == 'running':
        return jsonify({'error': 'A capture is already in progress.'}), 409

    if not engine.is_admin():
        return jsonify({
            'error': 'Administrator/root privileges required for memory capture. '
                     'Please restart with sudo (Linux) or Run as Administrator (Windows).'
        }), 403

    try:
        options = request.json
        case_id = options.get('case_id', 'CASE')
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')

        # Validate output format
        requested_format = options.get('format', 'raw').lower()
        if requested_format not in ['raw', 'lime', 'mem']:
            requested_format = 'raw'

        filename = f"{case_id}_{timestamp}.{requested_format}"
        base_dir = engine.get_storage_dir()
        output_path = os.path.join(base_dir, filename)

        thread = threading.Thread(
            target=engine.run_capture,
            args=(output_path, options, False),
        )
        thread.start()

        return jsonify({'status': 'started', 'file': filename})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@api.route('/api/capture/status')
def api_capture_status():
    """Polled by the UI every ~2s while a capture is in progress."""
    return jsonify({
        'status':   engine.status,
        'progress': engine.progress,
        'message':  engine.message,
        'filename': engine.filename,
    })


@api.route('/api/download/<path:filename>')
def api_download(filename):
    """Stream a completed dump file to the user's browser."""
    if not _validate_filename(filename):
        return jsonify({'error': 'Invalid filename'}), 400

    try:
        base_dir = engine.get_storage_dir()
        filepath = os.path.join(base_dir, filename)

        # Ensure the resolved path is still within the storage dir
        real_path = os.path.realpath(filepath)
        real_base = os.path.realpath(base_dir)
        if not real_path.startswith(real_base):
            return jsonify({'error': 'Access denied'}), 403

        return send_file(real_path, as_attachment=True)
    except Exception as e:
        return str(e), 404


@api.route('/api/reveal/<path:filename>')
def api_reveal(filename):
    """Open Explorer with the dump file selected (EXE / desktop mode)."""
    if not _validate_filename(filename):
        return jsonify({'error': 'Invalid filename'}), 400

    try:
        base_dir = engine.get_storage_dir()
        full_path = os.path.join(base_dir, filename)

        # Path traversal protection
        real_path = os.path.realpath(full_path)
        real_base = os.path.realpath(base_dir)
        if not real_path.startswith(real_base):
            return jsonify({'error': 'Access denied'}), 403

        if not os.path.exists(real_path):
            return jsonify({'error': 'File not found'}), 404

        # Use list-form Popen to prevent shell injection.
        # Cross-platform: Explorer (Windows), open -R (macOS), xdg-open (Linux).
        system = platform.system()
        if system == 'Windows':
            subprocess.Popen(['explorer', '/select,', real_path])
        elif system == 'Darwin':
            subprocess.Popen(['open', '-R', real_path])
        else:
            # Linux: xdg-open doesn't support file selection, open parent dir
            subprocess.Popen(['xdg-open', os.path.dirname(real_path)])
        return jsonify({'status': 'ok'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
