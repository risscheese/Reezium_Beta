"""
routes/processes.py
-------------------
Endpoints for the Process Manager view:
    /api/processes       — full process list (top 150 by memory)
    /api/process/<pid>   — detailed info for one process
    /api/kill/<pid>      — terminate a process (admin power tool)

NOTE on CPU values:
    psutil.cpu_percent() returns 0.0 on a first call (it needs a baseline
    to compare against). Rather than blocking the request for 0.5s to
    prime the counter, this module reads CPU values from the shared
    background CpuSampler which has them warm at all times.
"""

from flask import jsonify
import psutil
import datetime
import logging

from . import api
from core.utils import cpu_sampler

logger = logging.getLogger('reezium.routes')


@api.route('/api/processes')
def api_processes():
    """Return the top 150 processes by memory usage.

    CPU% comes from the background sampler (warm cache), so values are
    real on the very first request instead of 0.0.
    """
    procs = []

    # Pull the entire CPU cache once. Avoids a per-process lock acquire in
    # the loop below.
    cpu_cache = cpu_sampler.get_all()

    # Build a global mapping of PID to active network connections.
    # Querying connections once globally is hundreds of times faster than per-process queries.
    conn_counts = {}
    try:
        for conn in psutil.net_connections(kind='inet'):
            if conn.pid:
                conn_counts[conn.pid] = conn_counts.get(conn.pid, 0) + 1
    except Exception:
        pass

    try:
        # First pass: enumerate basic process attributes to minimize initial system calls
        for p in psutil.process_iter(['pid', 'name', 'memory_percent']):
            try:
                info = p.info.copy()
                # Read CPU% from the warm sampler cache, not the stale
                # process_iter snapshot (which would be 0.0 first-call).
                info['cpu_percent'] = cpu_cache.get(info['pid'], 0.0)
                procs.append(info)
            except (psutil.NoSuchProcess, psutil.AccessDenied,
                    psutil.ZombieProcess):
                pass

        # Sort by memory usage descending and keep the top 150
        procs.sort(key=lambda x: x.get('memory_percent') or 0, reverse=True)
        top_procs = procs[:150]

        # Second pass: query expensive properties (status, threads) only for the top 150 processes
        for info in top_procs:
            pid = info['pid']
            try:
                p = psutil.Process(pid)
                info['status'] = p.status()
                info['num_threads'] = p.num_threads()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                info['status'] = 'unknown'
                info['num_threads'] = 0

            # Attach pre-calculated connections count
            info['connections'] = conn_counts.get(pid, 0)

        return jsonify(top_procs)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@api.route('/api/process/<int:pid>')
def api_process_detail(pid):
    """Return rich metadata for a single process (the 'Inspect' button)."""
    try:
        p = psutil.Process(pid)
        return jsonify({
            'name': p.name(),
            'status': p.status(),
            'ppid': p.ppid(),
            'create_time': datetime.datetime.fromtimestamp(
                p.create_time()
            ).strftime('%Y-%m-%d %H:%M:%S'),
            'username': p.username(),
            'exe': p.exe(),
            'cmdline': ' '.join(p.cmdline()),
            'memory_info': {
                'rss': p.memory_info().rss,
                'vms': p.memory_info().vms,
            },
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@api.route('/api/kill/<int:pid>', methods=['POST'])
def api_kill(pid):
    """Terminate a process by PID. Requires admin for most system processes."""
    try:
        psutil.Process(pid).terminate()
        return jsonify({'message': f'Process {pid} terminated'})
    except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
        return jsonify({'message': str(e)}), 403
    except Exception as e:
        return jsonify({'message': str(e)}), 500