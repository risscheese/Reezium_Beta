"""
routes/threat_intel.py
----------------------
Endpoints for cloud-based threat intelligence lookups.

    GET /api/intel/hash/<hash>   — VirusTotal file hash lookup
    GET /api/intel/ip/<ip>       — AbuseIPDB IP reputation lookup
    GET /api/intel/status        — API key configuration status

All endpoints return JSON and degrade gracefully when API keys
are not configured.
"""

from flask import jsonify
import logging

from . import api
from core.cloud.threat_intel import intel_client

logger = logging.getLogger('reezium.routes')


@api.route('/api/intel/status')
def api_intel_status():
    """Check which threat intelligence APIs are configured."""
    return jsonify(intel_client.get_status())


@api.route('/api/intel/hash/<path:file_hash>')
def api_intel_hash(file_hash):
    """Look up a file hash on VirusTotal.

    The hash can be SHA256, SHA1, or MD5.
    """
    if not file_hash or len(file_hash) < 32:
        return jsonify({'error': 'Invalid hash. Provide MD5, SHA1, or SHA256.'}), 400

    try:
        result = intel_client.lookup_hash(file_hash.strip())
        return jsonify(result)
    except Exception as e:
        logger.error("Hash lookup failed: %s", e)
        return jsonify({'error': str(e)}), 500


@api.route('/api/intel/ip/<path:ip_address>')
def api_intel_ip(ip_address):
    """Look up an IP address on AbuseIPDB."""
    if not ip_address:
        return jsonify({'error': 'IP address required.'}), 400

    try:
        result = intel_client.lookup_ip(ip_address.strip())
        return jsonify(result)
    except Exception as e:
        logger.error("IP lookup failed: %s", e)
        return jsonify({'error': str(e)}), 500
