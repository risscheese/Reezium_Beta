"""
routes/connections.py
---------------------
Endpoint for the Network Connections view: lists active sockets with PID,
process name, local/remote addresses, status, and type.
"""

from flask import jsonify, request
import psutil
import socket
import logging

from . import api

logger = logging.getLogger('reezium.routes')


@api.route('/api/connections')
def api_connections():
    """List active TCP/UDP connections, optionally filtered by status."""
    conns = []
    status_filter = request.args.get('status', '').upper()
    try:
        # Build a process names cache to avoid hundreds of separate Process queries in the loop
        pid_to_name = {}
        for p in psutil.process_iter(['pid', 'name']):
            try:
                pid_to_name[p.info['pid']] = p.info['name']
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        for c in psutil.net_connections(kind='inet'):
            try:
                if status_filter and c.status != status_filter:
                    continue

                proc_name = "Unknown"
                if c.pid:
                    proc_name = pid_to_name.get(c.pid, "Unknown")

                conns.append({
                    'pid': c.pid,
                    'local': (f"{c.laddr.ip}:{c.laddr.port}"
                              if c.laddr else "N/A"),
                    'remote': (f"{c.raddr.ip}:{c.raddr.port}"
                               if c.raddr else "N/A"),
                    'status': c.status,
                    'type': ('TCP' if c.type == socket.SOCK_STREAM else 'UDP'),
                    'process': proc_name,
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        return jsonify(conns[:250])
    except Exception as e:
        return jsonify({'error': str(e)}), 500
