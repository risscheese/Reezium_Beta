"""
routes/system.py
----------------
Endpoint for the System Specs view: OS, CPU, disks, and network interfaces.
"""

from flask import jsonify
import psutil
import platform
import socket
import logging

from . import api

logger = logging.getLogger('reezium.routes')


@api.route('/api/specs')
def api_specs():
    """Return host hardware/OS specs for the System Specs panel."""
    try:
        # Disks — list every partition with usage stats.
        disks = []
        for part in psutil.disk_partitions(all=False):
            # Skip CD-ROM / optical drives and empty fstypes to avoid long timeouts/blocking on Windows
            if 'cdrom' in part.opts or not part.fstype or part.mountpoint.upper().startswith(('A:', 'B:')):
                continue
            try:
                u = psutil.disk_usage(part.mountpoint)
                disks.append({
                    'device':  part.device,
                    'used':    f"{round(u.used / 1024**3, 1)} GB",
                    'total':   f"{round(u.total / 1024**3, 1)} GB",
                    'percent': u.percent,
                })
            except (PermissionError, OSError):
                pass

        # Network interfaces — IPv4 addresses only.
        net = []
        for k, v in psutil.net_if_addrs().items():
            for a in v:
                if a.family == socket.AF_INET:
                    net.append({'interface': k, 'address': a.address})

        return jsonify({
            'os':           platform.system(),
            'release':      platform.release(),
            'version':      platform.version(),
            'node':         platform.node(),
            'processor':    platform.processor(),
            'architecture': platform.machine(),
            'phys_cores':   psutil.cpu_count(logical=False),
            'total_cores':  psutil.cpu_count(logical=True),
            'disks':        disks,
            'network':      net,
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500
