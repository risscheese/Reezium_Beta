"""
simulate_threat.py
------------------
Safe Threat Simulation Script for Reezium Imager Testing.

This script launches a simulated suspicious background process that triggers
Reezium's threat detection pipeline:
    1. Heuristics: PowerShell with Hidden Window, NoProfile, & Encoded Command
    2. MITRE ATT&CK: T1059.001 (PowerShell Execution)
    3. Network Anomaly: Shell with an outbound established connection
    4. Cloud Intel: Queries AbuseIPDB for the connection's public IP
    5. AI Explainer: Ready to be analyzed by the Gemini AI SOC Analyst

The process stays active until YOU terminate it (via Ctrl+C here, or
by clicking the 'KILL' button on Reezium's dashboard).
"""

import os
import sys
import time
import socket
import subprocess
import signal

def main():
    print("=" * 60)
    print("      REEZIUM IMAGER — SUSPICIOUS PROCESS SIMULATION")
    print("=" * 60)
    print("[*] Launching simulated suspicious process...")

    # A safe PowerShell command that keeps an idle outbound connection open to 1.1.1.1:443
    # This mimics reverse shell / beaconing activity without doing any harm.
    # Command line flags trigger: -WindowStyle Hidden, -NoProfile, -EncodedCommand flags
    ps_command = (
        "while ($true) { "
        "  try { "
        "    $client = New-Object System.Net.Sockets.TcpClient('1.1.1.1', 443); "
        "    while ($client.Connected) { Start-Sleep -Seconds 2 } "
        "  } catch { Start-Sleep -Seconds 2 } "
        "}"
    )

    cmd = [
        "powershell.exe",
        "-NoProfile",
        "-WindowStyle", "Hidden",
        "-ExecutionPolicy", "Bypass",
        "-Command", ps_command,
    ]

    try:
        proc = subprocess.Popen(
            cmd,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        )
    except Exception as e:
        print(f"[-] Failed to spawn PowerShell: {e}")
        print("[*] Falling back to pure Python simulated socket process...")
        proc = None

    print()
    if proc:
        print(f"[+] SIMULATED THREAT RUNNING!")
        print(f"[+] Target Process: powershell.exe")
        print(f"[+] Process PID:    {proc.pid}")
    else:
        pid = os.getpid()
        print(f"[+] SIMULATED THREAT RUNNING (Self PID: {pid})")
        # Keep an open socket to a public IP
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect(("1.1.1.1", 443))
        except Exception:
            pass

    print()
    print("=" * 60)
    print("DETECTION PROFILE TRIGGERED IN REEZIUM:")
    print("  • Heuristic:  Suspicious Command Line (Hidden Window, NoProfile, Bypass)")
    print("  • MITRE Tag:  T1059.001 (PowerShell Execution)")
    print("  • Network:    Shell with Active Outbound Connection")
    print("  • Cloud Intel: AbuseIPDB IP reputation lookup")
    print("=" * 60)
    print()
    print("[!] INSTRUCTIONS:")
    print("  1. Open Reezium Imager dashboard (or refresh 'THREAT HUNT').")
    print("  2. Look for the HIGH / CRITICAL alert on powershell.exe.")
    print("  3. Click '🤖 AI' to test your Gemini threat explanation.")
    print("  4. Click 'KILL' in Reezium or press Ctrl+C here to terminate.")
    print("=" * 60)
    print()

    try:
        while True:
            if proc and proc.poll() is not None:
                print(f"\n[*] Process PID {proc.pid} was terminated (killed via Reezium or closed)!")
                break
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[*] Stopping simulation...")
        if proc and proc.poll() is None:
            proc.terminate()
            proc.kill()
        print("[+] Process terminated safely. Goodbye!")

if __name__ == '__main__':
    main()
