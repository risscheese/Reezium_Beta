"""Reezium Imager — AI integrations package.

Provides LLM-powered threat explanation and investigation
guidance via Google Gemini, OpenAI, or local Ollama.
"""
