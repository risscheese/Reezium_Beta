"""
core/ai/llm_assistant.py
------------------------
LLM-powered threat explanation and investigation guidance for
Reezium Imager.

Provides a SOC-analyst co-pilot that takes a threat detection
from the scoring pipeline and produces:

    1. A plain-English explanation of WHY this is suspicious
    2. The real-world attack technique this resembles
    3. Step-by-step investigation actions
    4. Risk assessment (likely true/false positive)

Supported LLM providers:
    - Google Gemini  (recommended — free tier: 60 req/min)
    - OpenAI GPT     (paid, ~$0.01–0.03 per explanation)
    - Local Ollama   (fully offline, weaker quality)

Configuration
-------------
Provider and API key are loaded from (in priority order):
    1. Environment variables:  REEZIUM_AI_PROVIDER, REEZIUM_AI_API_KEY,
                               REEZIUM_AI_MODEL
    2. config.json in the project root

If no AI provider is configured, the module returns a helpful
placeholder message instead of crashing.
"""

import json
import logging
import os
import time
import threading

import requests

logger = logging.getLogger('reezium.ai.assistant')


# --- Configuration loading --------------------------------------------------

def _load_ai_config():
    """Load AI provider settings from env vars or config.json."""
    provider = os.environ.get('REEZIUM_AI_PROVIDER', '')
    api_key = os.environ.get('REEZIUM_AI_API_KEY', '')
    model = os.environ.get('REEZIUM_AI_MODEL', '')

    if not provider or not api_key:
        # Resolve config.json path for both frozen (PyInstaller) and dev mode.
        # When frozen, __file__ points inside _MEIPASS (the temp extraction
        # folder), so we use sys._MEIPASS instead to reach the bundle root.
        import sys
        if getattr(sys, 'frozen', False):
            base_dir = sys._MEIPASS
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(
                os.path.abspath(__file__)
            )))
        config_path = os.path.join(base_dir, 'config.json')
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8-sig') as f:
                    config = json.load(f)
                ai = config.get('ai_assistant', {})
                if not provider:
                    provider = ai.get('provider', '')
                if not api_key:
                    api_key = ai.get('api_key', '')
                if not model:
                    model = ai.get('model', '')
            except (json.JSONDecodeError, OSError) as e:
                logger.warning("Failed to read AI config from config.json: %s", e)

    # Defaults per provider.
    if provider == 'gemini' and not model:
        model = 'gemini-2.5-flash'
    elif provider == 'openai' and not model:
        model = 'gpt-4o-mini'
    elif provider == 'ollama' and not model:
        model = 'llama3.1'

    return provider, api_key, model


# --- Response cache ---------------------------------------------------------

class _ExplanationCache:
    """Simple TTL cache for LLM explanations.

    Keyed on (pid, score, message) so that re-explaining the same
    threat within the TTL window returns the cached response instantly.
    """

    def __init__(self, ttl_seconds=300):
        self._ttl = ttl_seconds
        self._store = {}
        self._lock = threading.Lock()

    def _make_key(self, threat):
        return (
            threat.get('pid', 0),
            threat.get('score', 0),
            threat.get('message', ''),
        )

    def get(self, threat):
        key = self._make_key(threat)
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            value, expire_time = entry
            if time.time() > expire_time:
                del self._store[key]
                return None
            return value

    def set(self, threat, value):
        key = self._make_key(threat)
        with self._lock:
            self._store[key] = (value, time.time() + self._ttl)

    def clear(self):
        with self._lock:
            self._store.clear()


# --- System prompt ----------------------------------------------------------

SYSTEM_PROMPT = """You are a senior SOC (Security Operations Center) analyst and digital \
forensics expert embedded in Reezium Imager, a forensic memory acquisition and threat-hunting \
tool. Your role is to deliver deep, actionable threat intelligence to investigators — from \
junior analysts to experienced IR responders.

When given a process threat detection, you MUST provide ALL of the following sections, \
formatted with clear markdown headers and bullet points:

---

## 🔍 Detection Score Breakdown
Explain what the numerical threat score means (0–100 scale). Break down the individual \
signals that contributed to it: anomaly score, entropy, signature matches, behavioral \
heuristics, cloud intelligence hits (VirusTotal, AbuseIPDB), and MITRE technique matches. \
Explain what HIGH, MEDIUM, and LOW score ranges mean in practice. If the score seems \
disproportionate, explain why.

## 🧬 Why This Is Flagged
A plain-English explanation of exactly why this detection fired. What specific behavioral \
signals or signatures triggered it? What combination of indicators makes this suspicious? \
Relate it to the full context: process name, executable path, command-line arguments, \
parent-child process relationships, and network connections if relevant.

## ⚔️ Attack Technique & Cyber Kill Chain Stage
Identify the real-world attack technique this detection resembles. Reference the MITRE \
ATT&CK technique ID and name if provided. Map it to the Cyber Kill Chain stage \
(Reconnaissance → Weaponization → Delivery → Exploitation → Installation → \
Command & Control → Actions on Objectives). Explain what an attacker typically does \
with this technique and what the ultimate goal is.

## 💥 Potential System Impact
Explain how this threat could damage, compromise, or weaponize the system if it is a \
true positive. Be specific about the potential consequences:
- Data exfiltration, credential theft, or lateral movement potential
- Persistence mechanisms (how it survives reboots)
- Privilege escalation risk
- Impact to system integrity, availability, or confidentiality
- Risk to other systems on the network

## 🛡️ Mitigation & Response Options
Provide THREE tiered response options so the analyst can choose based on urgency:

**Option 1 — Immediate Containment (High Urgency):** Steps to stop the threat RIGHT NOW \
with minimal disruption analysis. Include process termination, network isolation commands, \
or firewall rules.

**Option 2 — Investigate First (Balanced):** Steps to gather evidence before acting. \
Include specific commands or tools (e.g., Volatility, netstat, Process Monitor, Sysinternals, \
lsof, strace). This preserves forensic evidence while assessing true/false positive status.

**Option 3 — Long-term Hardening (Strategic):** After the immediate incident, what \
changes should be made to prevent recurrence? Include policy recommendations, EDR rule \
tuning, application whitelisting, or OS hardening steps.

## 🎯 Verdict: True Positive or False Positive?
Give your honest assessment with a confidence level (e.g., HIGH / MEDIUM / LOW confidence). \
Explain your reasoning. If it is likely a false positive, explain what legitimate software \
commonly triggers this pattern and how to verify.

---

Always use technical terms but briefly explain them for junior analysts. Format every \
section with markdown headers (##) and bullet points. Be specific, actionable, and complete \
every section thoroughly without cutting off."""


# --- Provider implementations -----------------------------------------------

def _call_gemini(prompt, api_key, model):
    """Call Google Gemini API.

    Uses the REST API directly (no SDK dependency) for simplicity.
    Includes automatic retry with backoff for temporary 503/429 spikes.
    """
    models_to_try = [model]
    for fallback in ['gemini-flash-latest', 'gemma-4-26b-a4b-it']:
        if fallback not in models_to_try:
            models_to_try.append(fallback)

    payload = {
        'contents': [{
            'parts': [{'text': prompt}]
        }],
        'systemInstruction': {
            'parts': [{'text': SYSTEM_PROMPT}]
        },
        'generationConfig': {
            'temperature': 0.3,
            'maxOutputTokens': 8192,
        }
    }

    for m in models_to_try:
        url = (
            f'https://generativelanguage.googleapis.com/v1beta/models/'
            f'{m}:generateContent?key={api_key}'
        )
        try:
            resp = requests.post(url, json=payload, timeout=60)
            if resp.status_code == 200:
                data = resp.json()
                candidates = data.get('candidates', [])
                if candidates:
                    cand = candidates[0]
                    finish_reason = cand.get('finishReason')
                    if finish_reason == 'MAX_TOKENS':
                        logger.warning("Gemini hit MAX_TOKENS on %s; output was truncated.", m)
                    parts = cand.get('content', {}).get('parts', [])
                    if parts:
                        return parts[0].get('text', '')
                return None
            else:
                logger.warning("Gemini API %d on %s: %s. Trying fallback...", resp.status_code, m, resp.text[:120])
        except requests.RequestException as e:
            logger.warning("Gemini call timed out or failed on %s: %s. Trying fallback...", m, e)

    return None


def _call_openai(prompt, api_key, model):
    """Call OpenAI Chat Completions API."""
    url = 'https://api.openai.com/v1/chat/completions'
    payload = {
        'model': model,
        'messages': [
            {'role': 'system', 'content': SYSTEM_PROMPT},
            {'role': 'user', 'content': prompt},
        ],
        'temperature': 0.3,
        'max_tokens': 4096,
    }
    try:
        resp = requests.post(
            url,
            json=payload,
            headers={
                'Authorization': f'Bearer {api_key}',
                'Content-Type': 'application/json',
            },
            timeout=60,
        )
        if resp.status_code != 200:
            logger.error("OpenAI API error %d: %s", resp.status_code, resp.text[:200])
            return None
        data = resp.json()
        choices = data.get('choices', [])
        if choices:
            return choices[0].get('message', {}).get('content', '')
        return None
    except requests.RequestException as e:
        logger.error("OpenAI API call failed: %s", e)
        return None


def _call_ollama(prompt, model):
    """Call local Ollama server (no API key needed)."""
    url = 'http://localhost:11434/api/generate'
    payload = {
        'model': model,
        'prompt': f"{SYSTEM_PROMPT}\n\n---\n\n{prompt}",
        'stream': False,
        'options': {
            'temperature': 0.3,
            'num_predict': 4096,
        },
    }
    try:
        resp = requests.post(url, json=payload, timeout=90)
        if resp.status_code != 200:
            logger.error("Ollama error %d: %s", resp.status_code, resp.text[:200])
            return None
        data = resp.json()
        return data.get('response', '')
    except requests.ConnectionError:
        logger.warning(
            "Ollama server not running at localhost:11434. "
            "Start it with: ollama serve"
        )
        return None
    except requests.RequestException as e:
        logger.error("Ollama API call failed: %s", e)
        return None


# --- Public assistant class -------------------------------------------------

class LLMAssistant:
    """LLM-powered threat explanation assistant.

    Instantiated once at app startup. Thread-safe.

    Usage::

        assistant = LLMAssistant()
        result = assistant.explain_threat(threat_dict)
        # result = {'explanation': '...', 'provider': 'gemini', 'cached': False}
    """

    def __init__(self):
        self._provider, self._api_key, self._model = _load_ai_config()
        self._cache = _ExplanationCache(ttl_seconds=300)

        if self._provider and (self._api_key or self._provider == 'ollama'):
            logger.info(
                "AI assistant configured: provider=%s, model=%s",
                self._provider, self._model,
            )
        else:
            logger.info(
                "AI assistant not configured. Set provider and API key "
                "in config.json or via environment variables."
            )

    @property
    def provider(self):
        """Currently configured provider name, or empty string."""
        return self._provider

    @property
    def model(self):
        """Currently configured model name."""
        return self._model

    def is_configured(self):
        """True if a provider is set and has credentials (or is Ollama)."""
        if self._provider == 'ollama':
            return True
        return bool(self._provider and self._api_key)

    def get_status(self):
        """Return configuration status for the /api/ai/status endpoint."""
        return {
            'configured': self.is_configured(),
            'provider': self._provider or 'none',
            'model': self._model or 'none',
        }

    def _build_prompt(self, threat):
        """Construct the user prompt from a threat dict.

        Includes all available context: process name, PID, score,
        severity, detection reasons, MITRE tags, cloud intel, and
        a score interpretation hint to help the LLM calibrate its analysis.
        """
        mitre_info = ''
        techniques = threat.get('mitre_techniques', [])
        if techniques:
            mitre_lines = []
            for t in techniques:
                if isinstance(t, dict):
                    mitre_lines.append(
                        f"  - {t.get('id', '?')}: {t.get('name', '?')} "
                        f"(Tactic: {t.get('tactic', '?')})"
                    )
                else:
                    mitre_lines.append(f"  - {t}")
            mitre_info = "MITRE ATT&CK Techniques:\n" + "\n".join(mitre_lines)

        cloud_info = ''
        cloud_intel = threat.get('cloud_intel', {})
        if cloud_intel:
            cloud_info = f"\nCloud Intelligence:\n{json.dumps(cloud_intel, indent=2)}"

        exe_path = threat.get('exe', '')
        exe_line = f"Executable Path: {exe_path}\n" if exe_path else ""
        file_hash = threat.get('file_hash') or threat.get('hash', '')
        hash_line = f"SHA256 File Hash: {file_hash}\n" if file_hash else ""

        cmdline = threat.get('cmdline', '')
        cmdline_line = f"Command Line: {cmdline}\n" if cmdline else ""

        ppid = threat.get('ppid', '')
        ppid_line = f"Parent PID (PPID): {ppid}\n" if ppid else ""

        username = threat.get('username', '')
        user_line = f"Running As User: {username}\n" if username else ""

        # Derive a score-band hint so the LLM can calibrate its response.
        score = int(threat.get('score', 0))
        if score >= 80:
            score_band = f"{score}/100 — CRITICAL/HIGH band: strong confidence in malicious activity"
        elif score >= 50:
            score_band = f"{score}/100 — MEDIUM band: notable anomalies, warrants investigation"
        elif score >= 25:
            score_band = f"{score}/100 — LOW band: minor signals, likely benign but flag for review"
        else:
            score_band = f"{score}/100 — MINIMAL band: borderline threshold trigger, probably benign"

        prompt = f"""Analyze this threat detection from Reezium Imager and provide a full \
cyber security pipeline analysis:

=== PROCESS CONTEXT ===
Process Name: {threat.get('name', 'Unknown')}
PID: {threat.get('pid', '?')}
{exe_line}{cmdline_line}{ppid_line}{user_line}{hash_line}
=== DETECTION RESULTS ===
Threat Score: {score_band}
Severity: {threat.get('severity', 'unknown').upper()}
Detection Type: {threat.get('type', 'unknown')}
Alert Message: {threat.get('message', 'No message')}
Raw Detection Details: {threat.get('details', 'No details')}

=== THREAT INTELLIGENCE ===
{mitre_info if mitre_info else 'No MITRE ATT&CK techniques mapped.'}
{cloud_info if cloud_info else 'No cloud intelligence data available.'}

Provide your complete analysis across all required sections: Detection Score Breakdown, \
Why This Is Flagged, Attack Technique & Cyber Kill Chain Stage, Potential System Impact, \
Mitigation & Response Options (3 tiers), and Verdict."""

        return prompt

    def explain_threat(self, threat, force_refresh=False):
        """Generate an LLM explanation for a threat detection.

        Args:
            threat: A threat dict from scorer.run_threat_scan().
            force_refresh: If True, ignore any cached explanation and regenerate.

        Returns:
            A dict with:
                explanation: str  — the LLM's analysis text
                provider:    str  — which LLM provider was used
                model:       str  — which model was used
                cached:      bool — whether this was a cache hit
                error:       str  — error message if the call failed
        """
        # Not configured — return a helpful placeholder.
        if not self.is_configured():
            return {
                'explanation': (
                    '**AI Assistant Not Configured**\n\n'
                    'To enable AI-powered threat explanations, add your '
                    'API key to `config.json` or set environment variables:\n\n'
                    '- **Google Gemini (free)**: Set `provider` to `"gemini"` '
                    'and add your API key from '
                    '[aistudio.google.com](https://aistudio.google.com/apikey)\n'
                    '- **OpenAI**: Set `provider` to `"openai"` and add your '
                    'API key\n'
                    '- **Ollama (local)**: Set `provider` to `"ollama"` — no '
                    'API key needed, but requires Ollama running locally'
                ),
                'provider': 'none',
                'model': 'none',
                'cached': False,
                'configured': False,
            }

        # Check cache first (unless force_refresh is requested).
        if not force_refresh:
            cached = self._cache.get(threat)
            if cached is not None:
                return {
                    'explanation': cached,
                    'provider': self._provider,
                    'model': self._model,
                    'cached': True,
                }

        # Build the prompt and call the LLM.
        prompt = self._build_prompt(threat)
        explanation = None

        if self._provider == 'gemini':
            explanation = _call_gemini(prompt, self._api_key, self._model)
        elif self._provider == 'openai':
            explanation = _call_openai(prompt, self._api_key, self._model)
        elif self._provider == 'ollama':
            explanation = _call_ollama(prompt, self._model)
        else:
            return {
                'explanation': '',
                'error': f"Unknown AI provider: '{self._provider}'",
                'provider': self._provider,
                'model': self._model,
                'cached': False,
            }

        if explanation:
            self._cache.set(threat, explanation)
            return {
                'explanation': explanation,
                'provider': self._provider,
                'model': self._model,
                'cached': False,
            }
        else:
            return {
                'explanation': '',
                'error': (
                    f"LLM call failed. Check your {self._provider} API key "
                    f"and network connection."
                ),
                'provider': self._provider,
                'model': self._model,
                'cached': False,
            }


# Module-level singleton — created once, reused across requests.
assistant = LLMAssistant()
