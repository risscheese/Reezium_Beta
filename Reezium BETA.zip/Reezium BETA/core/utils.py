"""
core/utils.py
-------------
Shared utility functions used across the Reezium Imager codebase.

Contains:
    - calculate_entropy(text): Shannon entropy in bits, used by the entropy
      detector to spot random-looking process names.
    - CpuSampler: a thread-safe background sampler that keeps per-process
      CPU% readings warm so the UI endpoints don't pay a 0.5s priming cost
      on every request.

Design rationale for CpuSampler
-------------------------------
psutil.cpu_percent() requires two calls with a measurement interval between
them — the first call seeds an internal counter, the second returns the
delta. Without a delay, every call returns 0.0.

Three options were considered:
    1. Two-pass + sleep inside every endpoint (works, but 0.5s per request).
    2. Use cpu_percent(interval=0.1) per process (~10ms × 200 procs = 2s).
    3. Run a single background sampler that primes counters every few seconds.

We chose option 3. Endpoints become near-instant (just read the cache),
and the cost is a single small thread that ticks every CPU_SAMPLE_INTERVAL
seconds.
"""

import math
import threading
import time
from collections import Counter

import psutil


# How often the background thread re-primes CPU counters, in seconds.
# Lower = fresher readings but more background CPU usage.
# 2.0s matches the UI's dashboard polling rate.
CPU_SAMPLE_INTERVAL = 2.0


def calculate_entropy(text):
    """Compute the Shannon entropy (in bits) of a string.

    Args:
        text: The string to analyse (e.g., a process name without extension).

    Returns:
        A float representing entropy in bits. Returns 0 for empty input.

    Uses collections.Counter for O(n) performance instead of an
    O(n × 256) iteration over every possible byte value.
    """
    if not text:
        return 0.0
    counts = Counter(text)
    length = len(text)
    return -sum((c / length) * math.log2(c / length) for c in counts.values())


class CpuSampler:
    """Background thread that keeps psutil's per-process CPU counters warm.

    psutil tracks CPU% with an internal "last-seen" counter that needs to
    be primed at least once. Without that prime, every cpu_percent() call
    returns 0.0. By running a small background thread that calls
    cpu_percent() on every process every few seconds, we ensure that any
    endpoint asking for CPU% gets a real value immediately.

    Usage:
        sampler = CpuSampler()
        sampler.start()
        # ... later, from any endpoint:
        cpu = sampler.get_cpu(pid)   # returns last-known % for that PID
        cpu = sampler.get_cpu(pid, default=0)
    """

    def __init__(self, interval=CPU_SAMPLE_INTERVAL):
        self.interval = interval
        self._cache = {}            # pid -> last-known cpu_percent
        self._lock = threading.Lock()
        self._thread = None
        self._stop_event = threading.Event()

    def start(self):
        """Begin background sampling. Safe to call once at app start-up."""
        if self._thread and self._thread.is_alive():
            return
        # Prime once synchronously so the first endpoint call has data.
        self._sample_once()
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._loop,
            daemon=True,    # dies with the main process
            name='reezium-cpu-sampler',
        )
        self._thread.start()

    def stop(self):
        """Signal the background thread to exit. Optional — daemon=True."""
        self._stop_event.set()

    def get_cpu(self, pid, default=0.0):
        """Return the last-known CPU% for a PID, or default if unknown."""
        with self._lock:
            return self._cache.get(pid, default)

    def get_all(self):
        """Return a shallow copy of the entire pid -> cpu% cache."""
        with self._lock:
            return dict(self._cache)

    def _sample_once(self):
        """Walk all processes and update the CPU cache. Best-effort."""
        new_cache = {}
        for p in psutil.process_iter(['pid']):
            try:
                # cpu_percent() with no interval uses the time since the
                # last call to this same Process object's counter.
                new_cache[p.info['pid']] = p.cpu_percent()
            except (psutil.NoSuchProcess, psutil.AccessDenied,
                    psutil.ZombieProcess):
                continue
        with self._lock:
            self._cache = new_cache

    def _loop(self):
        """Background thread main loop. Re-samples every `interval` seconds."""
        while not self._stop_event.is_set():
            try:
                self._sample_once()
            except Exception:
                # Never let the sampler thread die from a transient error.
                pass
            # Use wait() instead of sleep() so stop() returns quickly.
            self._stop_event.wait(self.interval)


# Module-level singleton used by every endpoint.
# Started from app.py at boot. Endpoints just import and read.
cpu_sampler = CpuSampler()