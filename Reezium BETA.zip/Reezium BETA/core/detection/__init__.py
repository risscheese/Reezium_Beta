"""Reezeium Imager — detection sub-package.

The detection engine is intentionally broken into focused modules so each
technique can be developed and tested independently:

    statistical.py  — Z-score / MAD-based anomaly detection
    entropy.py      — Shannon entropy on process names
    heuristics.py   — Signature, path, masquerading, reverse-shell rules
    ml_models.py    — Isolation Forest and other ML-based detectors (Pass 3)
    scorer.py       — Combines the above into a single threat score
"""
