"""
core/detection/entropy.py
-------------------------
Entropy-based detection. The intuition: legitimate process names like
'svchost.exe' have low Shannon entropy because they use a limited alphabet
in a structured way. Malware droppers using randomised names like
'x78f9a.exe' or DGA-style names have high entropy.

Combines Shannon entropy with English bigram frequency analysis to reduce
false positives: a name can be high-entropy AND still match common English
bigrams (e.g. "RuntimeBroker" has moderate entropy but natural bigrams).
"""

from core.utils import calculate_entropy


# Threshold above which a name is considered "random-looking".
# 3.8 bits is empirical — most legitimate Windows process names sit below this.
ENTROPY_THRESHOLD = 3.8

# Names shorter than this are excluded (too few characters to be meaningful).
MIN_NAME_LENGTH = 4

# Common file extensions to strip before analysing entropy.
STRIP_EXTENSIONS = ['.exe', '.dll', '.com', '.scr', '.bat', '.cmd', '.ps1']

# Top 30 English bigrams — used to distinguish "random high-entropy" from
# "natural high-entropy" names. Source: letter frequency analysis.
COMMON_BIGRAMS = {
    'th', 'he', 'in', 'er', 'an', 're', 'on', 'at', 'en', 'nd',
    'ti', 'es', 'or', 'te', 'of', 'ed', 'is', 'it', 'al', 'ar',
    'st', 'to', 'nt', 'ng', 'se', 'ha', 'as', 'ou', 'io', 'le',
}

# Bigram ratio below this indicates a "random-looking" name (no natural
# English structure). Most legitimate process names score > 0.15.
BIGRAM_THRESHOLD = 0.1


def _strip_extension(name_lower):
    """Remove common executable extensions from a lowercased name."""
    for ext in STRIP_EXTENSIONS:
        if name_lower.endswith(ext):
            return name_lower[:-len(ext)]
    return name_lower


def bigram_score(text):
    """Return the fraction of character bigrams that match common English bigrams.

    Args:
        text: The string to analyse (lowercased, extension-stripped).

    Returns:
        A float in [0.0, 1.0]. High = natural English, low = random.
    """
    if len(text) < 2:
        return 0.0
    bigrams = [text[i:i+2] for i in range(len(text) - 1)]
    matches = sum(1 for bg in bigrams if bg in COMMON_BIGRAMS)
    return matches / len(bigrams)


def analyze_name_entropy(name_lower):
    """Compute entropy and bigram score for the core of a process name.

    Args:
        name_lower: The process name, lowercased.

    Returns:
        (entropy_value, bigram_ratio, suspicious_bool)
    """
    name_core = _strip_extension(name_lower)
    entropy = calculate_entropy(name_core)
    bg_score = bigram_score(name_core)

    # Suspicious if: high entropy AND low bigram score AND long enough
    is_suspicious = (
        entropy > ENTROPY_THRESHOLD
        and bg_score < BIGRAM_THRESHOLD
        and len(name_core) > MIN_NAME_LENGTH
    )
    return entropy, bg_score, is_suspicious


def score_process_entropy(name_lower):
    """Score a single process based on the entropy of its name.

    MITRE: T1027 (Obfuscated Files or Information)

    Returns:
        (score_contribution, reasons_list, entropy_value, mitre_tags) —
        the entropy value is returned separately because the scorer also
        uses it in the 'details' string of the threat alert.
    """
    from .heuristics import MITRE_TECHNIQUES

    score = 0
    reasons = []
    mitre_tags = []
    entropy, bg_score, is_suspicious = analyze_name_entropy(name_lower)

    if is_suspicious:
        mitre = MITRE_TECHNIQUES['random_name']
        score += 30
        reasons.append(
            f"High Entropy Name (entropy={round(entropy, 2)}, "
            f"bigrams={round(bg_score, 2)}) [{mitre['id']}]"
        )
        mitre_tags.append(mitre)

    return score, reasons, entropy, mitre_tags
