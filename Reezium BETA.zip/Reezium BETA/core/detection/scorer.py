"""
core/detection/scorer.py
------------------------
The Scorer orchestrates the individual detection modules and produces a
single ranked list of threats.

Three detection modes are supported (for FYP comparative evaluation):

    'statistical'  — Modified Z-Score + entropy + heuristics (no ML).
                     This is the baseline detector.

    'ml'           — Isolation Forest + entropy + heuristics.
                     Same heuristic/entropy floor, ML replaces the
                     statistical component.

    'hybrid'       — All four signal types active simultaneously.
                     Production default; offers the best detection rate
                     at the cost of slightly higher false-positive risk.

The route layer exposes both /api/suspicious (production hybrid mode)
and /api/suspicious/compare (runs all three modes and returns the diff
for the FYP evaluation chapter).

Calibration philosophy
----------------------
A single weak signal does NOT trigger an alert. Threats require either:
    (a) one STRONG signal (suspicious name, masquerading, reverse shell,
        suspicious path, malicious parent-child chain), OR
    (b) TWO OR MORE independent weak signals combined.

Both statistical and ML detectors are capped below the reporting
threshold, so neither can fire an alert without corroboration. This
matches real-world EDR design and was the fix for the python.exe /
steamwebhelper.exe false positives observed during testing.
"""

import os
import time
import psutil
import logging

from .statistical import get_stats, score_process_statistical
from .entropy import score_process_entropy
from .heuristics import (
    score_suspicious_names,
    score_network_anomalies,
    score_path_anomalies,
    score_parent_child,
    score_cmdline_anomalies,
    is_known_good,
    SKIP_PROCESSES,
    CMDLINE_INSPECT_PROCESSES,
)
from .ml_models import detector as ml_detector, extract_features, score_process_ml
from core.utils import cpu_sampler, calculate_entropy

logger = logging.getLogger('reezium.detection')


# --- Tuning knobs -----------------------------------------------------------

SEVERITY_THRESHOLDS = [
    (80, 'critical'),
    (50, 'high'),
    (30, 'medium'),
    (0,  'low'),
]

# Minimum cumulative score to surface a process as a threat.
REPORTING_THRESHOLD = 30

# Strong-signal prefixes — any one of these alone is enough to fire.
STRONG_SIGNAL_PREFIXES = (
    'Known Malicious Tool',
    'Suspicious Name Match',
    'System Process Impersonation',
    'Shell with Network Connection',
    'Running from Temporary',
    'Suspicious Process Chain',
    'Suspicious Command Line',
)


# Self-exclusion: Reezium's own PID captured at module load.
_REEZIUM_PID = os.getpid()


# --- Internals -------------------------------------------------------------

def _classify_severity(score):
    """Map a numeric score to a severity label."""
    for threshold, label in SEVERITY_THRESHOLDS:
        if score > threshold:
            return label
    return 'low'


def _has_strong_signal(reasons):
    """True if reasons contain any standalone-strong indicator."""
    for r in reasons:
        if any(r.startswith(prefix) for prefix in STRONG_SIGNAL_PREFIXES):
            return True
    return False


def _gather_connections():
    """Build a dict of pid -> [connections] for O(1) lookup during scoring."""
    connections = {}
    try:
        for c in psutil.net_connections(kind='inet'):
            if c.pid:
                key = int(c.pid)
                if key not in connections:
                    connections[key] = []
                connections[key].append(c)
    except (psutil.AccessDenied, OSError):
        pass
    return connections


def _gather_processes():
    """Single-pass enumeration. CPU values come from the warm sampler.

    Note: 'cmdline' is NOT requested here — on Windows, reading every
    process's command line via the PEB adds 3-5s to enumeration. Instead,
    cmdline is fetched lazily in the scoring loop only for processes in
    CMDLINE_INSPECT_PROCESSES (shells and LOLBins).

    Returns:
        (data_points, cpu_vals, mem_vals, thread_vals, pid_name_map)
    """
    cpu_cache = cpu_sampler.get_all()

    data_points = []
    cpu_vals, mem_vals, thread_vals = [], [], []
    pid_name_map = {}

    for p in psutil.process_iter(['pid', 'name', 'memory_percent',
                                  'num_threads', 'exe', 'ppid']):
        try:
            info = p.info
            pid = info['pid']
            name = info.get('name') or ''
            pid_name_map[pid] = name.lower()

            cpu = cpu_cache.get(pid, 0.0)
            mem = info.get('memory_percent') or 0
            th = info.get('num_threads') or 0

            cpu_vals.append(cpu)
            mem_vals.append(mem)
            thread_vals.append(th)

            data_points.append({
                'info': info,
                'process': p,  # keep reference for lazy cmdline fetch
                'cpu': cpu, 'mem': mem, 'th': th,
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied,
                psutil.ZombieProcess):
            pass

    return data_points, cpu_vals, mem_vals, thread_vals, pid_name_map


# --- Public entry-points ---------------------------------------------------

def run_threat_scan(mode='hybrid'):
    """Run the full threat-hunt pipeline.

    Args:
        mode: one of 'statistical', 'ml', 'hybrid'.

    Returns:
        A list of threat dicts (pid, name, score, severity, type,
        message, details), sorted by score descending, top-50 only.
    """
    if mode not in ('statistical', 'ml', 'hybrid'):
        logger.warning("Unknown scan mode '%s' — falling back to hybrid", mode)
        mode = 'hybrid'

    use_statistical = mode in ('statistical', 'hybrid')
    use_ml = mode in ('ml', 'hybrid')

    threats = []

    connections = _gather_connections()
    (data_points, cpu_vals, mem_vals, thread_vals,
     pid_name_map) = _gather_processes()

    # Statistical baseline — only needed if statistical mode is active.
    if use_statistical:
        mu_cpu, sigma_cpu = get_stats(cpu_vals)
        mu_mem, sigma_mem = get_stats(mem_vals)
        mu_th, sigma_th = get_stats(thread_vals)

    # Pre-compute connection counts, entropy, and (when ML is active)
    # enriched ML features for every process. Result: a parallel list
    # aligned with data_points.
    enrich = []
    now = time.time()
    for item in data_points:
        info = item['info']
        pid = info.get('pid', 0)
        name_lower = (info.get('name') or '').lower()
        ent_score, ent_reasons, ent_value, ent_mitre = score_process_entropy(name_lower)
        item['connections'] = len(connections.get(pid, []))

        # --- Enriched features for ML (Enhancement 1) ---
        # These are ONLY needed when ML mode is active. In statistical-
        # only mode (e.g. the dashboard's 2-second poll) we skip them
        # entirely. This avoids the extremely expensive memory_maps(),
        # num_handles(), and children() syscalls that were causing
        # multi-second blocking on every dashboard tick.
        if use_ml:
            proc_obj = item.get('process')

            # 7. Handle count
            try:
                item['handle_count'] = proc_obj.num_handles() if proc_obj else 0
            except (psutil.NoSuchProcess, psutil.AccessDenied,
                    psutil.ZombieProcess, AttributeError):
                item['handle_count'] = 0

            # 8. Process age (seconds alive)
            try:
                ctime = proc_obj.create_time() if proc_obj else now
                item['process_age'] = max(0, now - ctime)
            except (psutil.NoSuchProcess, psutil.AccessDenied,
                    psutil.ZombieProcess, AttributeError, OSError):
                item['process_age'] = 0

            # 9. Child process count
            try:
                item['child_count'] = len(proc_obj.children()) if proc_obj else 0
            except (psutil.NoSuchProcess, psutil.AccessDenied,
                    psutil.ZombieProcess, AttributeError):
                item['child_count'] = 0

            # 10. Exe exists (0 = missing/invalid, 1 = present)
            exe = info.get('exe') or ''
            item['exe_exists'] = 1 if exe and os.path.isfile(exe) else 0

            # 11. Module count (loaded DLLs)
            try:
                item['module_count'] = len(proc_obj.memory_maps()) if proc_obj else 0
            except (psutil.NoSuchProcess, psutil.AccessDenied,
                    psutil.ZombieProcess, AttributeError):
                item['module_count'] = 0

            # 12. Parent name entropy
            ppid = info.get('ppid', 0)
            parent_name = pid_name_map.get(ppid, '')
            item['parent_entropy'] = calculate_entropy(parent_name) if parent_name else 0.0
        else:
            # Statistical-only mode: set cheap defaults so the item
            # dict has a consistent shape (no KeyError risk downstream).
            item['handle_count'] = 0
            item['process_age'] = 0
            item['child_count'] = 0
            item['exe_exists'] = 1
            item['module_count'] = 0
            item['parent_entropy'] = 0.0

        enrich.append({
            'entropy':      ent_value,
            'ent_score':    ent_score,
            'ent_reasons':  ent_reasons,
            'ent_mitre':    ent_mitre,
            'name_lower':   name_lower,
        })

    # If ML is active, run inference once on the full feature matrix.
    ml_scores = []
    if use_ml and ml_detector.enabled:
        feature_matrix = [
            extract_features(item, enrich[i]['entropy'])
            for i, item in enumerate(data_points)
        ]
        pids = [item['info'].get('pid', 0) for item in data_points]
        ml_scores = ml_detector.fit_and_predict(feature_matrix, pids=pids)
    else:
        ml_scores = [0.0] * len(data_points)

    # Score each process.
    for i, item in enumerate(data_points):
        info = item['info']
        pid = info.get('pid', 0)
        name = info.get('name') or ""
        name_lower = enrich[i]['name_lower']
        exe = info.get('exe') or ""
        ppid = info.get('ppid', 0)
        entropy = enrich[i]['entropy']

        # Self-exclusion + skip lists
        if pid == _REEZIUM_PID:
            continue
        if name_lower in SKIP_PROCESSES:
            continue

        # Known-good check: instead of skipping entirely, flag the process
        # so we suppress weak signals (statistical/ML/entropy) but still
        # run all heuristic checks. This closes the fileless-malware
        # detection gap for shells and LOLBins that are whitelisted to
        # reduce false positives under normal usage.
        known_good = is_known_good(name_lower)

        total_score = 0
        all_reasons = []
        all_mitre_tags = []

        # A + A'. Statistical and ML anomaly detection.
        #
        # SKIP for known-good processes — these weak signals are the main
        # source of false positives on legitimate apps (python.exe,
        # steamwebhelper.exe, etc.). The heuristic checks below are the
        # ones that actually matter for known-good processes.
        #
        # Anti-stacking design: statistical and ML detectors both observe
        # CPU/memory, so their outputs are correlated. SUMMING their scores
        # would let two correlated weak signals stack into a false alarm
        # (observed empirically with ms-teams.exe). Fix: take the MAX of
        # the two scores. Reasons from both detectors are still appended
        # so the alert message accurately reports which detectors fired.
        if not known_good:
            anomaly_score = 0
            if use_statistical:
                s_stat, r_stat, m_stat = score_process_statistical(
                    item, mu_cpu, sigma_cpu, mu_mem, sigma_mem, mu_th, sigma_th
                )
                anomaly_score = max(anomaly_score, s_stat)
                all_reasons.extend(r_stat)
                all_mitre_tags.extend(m_stat)

            if use_ml:
                s_ml, r_ml, m_ml = score_process_ml(ml_scores[i])
                anomaly_score = max(anomaly_score, s_ml)
                all_reasons.extend(r_ml)
                all_mitre_tags.extend(m_ml)

            total_score += anomaly_score

            # B. Entropy + bigram (cached from the enrich pass above)
            total_score += enrich[i]['ent_score']
            all_reasons.extend(enrich[i]['ent_reasons'])
            all_mitre_tags.extend(enrich[i].get('ent_mitre', []))

        # C1. Suspicious keyword — ALWAYS run
        s, r, m = score_suspicious_names(name_lower)
        total_score += s
        all_reasons.extend(r)
        all_mitre_tags.extend(m)

        # C2. Network anomalies (reverse-shell heuristic) — ALWAYS run
        s, r, m = score_network_anomalies(pid, name_lower, connections)
        total_score += s
        all_reasons.extend(r)
        all_mitre_tags.extend(m)

        # C3. Path anomalies (suspicious dirs + masquerading) — ALWAYS run
        s, r, m = score_path_anomalies(name_lower, exe)
        total_score += s
        all_reasons.extend(r)
        all_mitre_tags.extend(m)

        # C4. Parent-child process chain — ALWAYS run
        s, r, m = score_parent_child(ppid, name_lower, pid_name_map)
        total_score += s
        all_reasons.extend(r)
        all_mitre_tags.extend(m)

        # C5. Command-line content analysis (fileless malware) — ALWAYS run
        #
        # Lazy cmdline fetch: only read the command line for processes that
        # score_cmdline_anomalies() will actually inspect (shells, LOLBins).
        # This avoids the 3-5s overhead of reading every process's PEB.
        if name_lower in CMDLINE_INSPECT_PROCESSES:
            try:
                proc_obj = item.get('process')
                cmdline = proc_obj.cmdline() if proc_obj else []
            except (psutil.NoSuchProcess, psutil.AccessDenied,
                    psutil.ZombieProcess):
                cmdline = []
        else:
            cmdline = []
        s, r, m = score_cmdline_anomalies(name_lower, cmdline)
        total_score += s
        all_reasons.extend(r)
        all_mitre_tags.extend(m)

        # Multi-signal requirement: ONE strong, OR TWO+ weak.
        has_strong = _has_strong_signal(all_reasons)
        signal_count = len(all_reasons)
        if not has_strong and signal_count < 2:
            continue

        # Known-good gate: whitelisted processes (powershell, cmd, wscript,
        # winword, etc.) only surface as threats when a STRONG heuristic
        # signal fires. This preserves the FP-suppression intent of the
        # whitelist while still catching fileless malware indicators,
        # suspicious process chains, path anomalies, and reverse shells.
        if known_good and not has_strong:
            continue

        if total_score > REPORTING_THRESHOLD:
            severity = _classify_severity(total_score)

            if all_reasons:
                threat_type = ('ANOMALY DETECTED'
                               if not all_reasons[0].startswith('Suspicious')
                               else 'SIGNATURE MATCH')
            else:
                threat_type = 'ANOMALY DETECTED'

            # Deduplicate MITRE tags by technique ID.
            seen_ids = set()
            unique_mitre = []
            for tag in all_mitre_tags:
                if tag['id'] not in seen_ids:
                    seen_ids.add(tag['id'])
                    unique_mitre.append(tag)

            # Extract unique tactics.
            mitre_tactics = []
            for tag in unique_mitre:
                for tactic in tag.get('tactic', '').split(', '):
                    tactic = tactic.strip()
                    if tactic and tactic not in mitre_tactics:
                        mitre_tactics.append(tactic)

            threats.append({
                'pid': pid,
                'name': name,
                'exe': exe,
                'score': round(total_score),
                'severity': severity,
                'type': threat_type,
                'message': " | ".join(all_reasons[:3]),
                'details': (f"Anomaly Score: {round(total_score)} | "
                            f"Entropy: {round(entropy, 2)} | "
                            f"Mode: {mode}"),
                'mitre_techniques': unique_mitre,
                'mitre_tactics': mitre_tactics,
            })

    threats.sort(key=lambda x: x['score'], reverse=True)
    return threats[:50]


def compare_modes():
    """Run all three detection modes and return their differential output.

    This is the public entry-point for the FYP evaluation chapter. It runs
    each mode independently against the SAME process snapshot (taken once,
    so all three modes see identical input) and returns a structured
    comparison.

    Returns:
        {
            'statistical': [threat, ...],
            'ml':          [threat, ...],
            'hybrid':      [threat, ...],
            'summary': {
                'statistical_count':   int,
                'ml_count':            int,
                'hybrid_count':        int,
                'agreement_pids':      [pid, pid, ...],  # flagged by all three
                'statistical_only':    [pid, ...],
                'ml_only':             [pid, ...],
                'ml_available':        bool,
            }
        }

    Note: each call to run_threat_scan() does its own enumeration, so the
    three modes will see slightly different snapshots if processes start
    or stop between calls. For more rigorous evaluation, snapshot once
    and pass it to the scorers — but for an interactive UI this is
    accurate enough.
    """
    stat_results = run_threat_scan(mode='statistical')
    ml_results   = run_threat_scan(mode='ml')
    hybrid_results = run_threat_scan(mode='hybrid')

    stat_pids   = {t['pid'] for t in stat_results}
    ml_pids     = {t['pid'] for t in ml_results}
    hybrid_pids = {t['pid'] for t in hybrid_results}

    return {
        'statistical': stat_results,
        'ml':          ml_results,
        'hybrid':      hybrid_results,
        'summary': {
            'statistical_count':   len(stat_results),
            'ml_count':            len(ml_results),
            'hybrid_count':        len(hybrid_results),
            'agreement_pids':      sorted(stat_pids & ml_pids & hybrid_pids),
            'statistical_only':    sorted(stat_pids - ml_pids),
            'ml_only':             sorted(ml_pids - stat_pids),
            'ml_available':        ml_detector.enabled,
            'ml_warmed_up':        ml_detector.is_warmed_up,
        },
    }