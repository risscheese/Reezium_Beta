"""
core/detection/ml_models.py
---------------------------
Machine-learning-based anomaly detection using Isolation Forest.

This module is Reezium's "research contribution" detector. It runs
alongside the Modified Z-Score statistical method and enables a
quantitative comparison of two anomaly-detection paradigms on the same
process telemetry.

Algorithm choice rationale
--------------------------
Isolation Forest (Liu, Ting, & Zhou, 2008) is chosen because:

    1. It is UNSUPERVISED — no labelled malware dataset is needed, which
       matches the realistic constraint that a live forensic tool has no
       advance knowledge of what is malicious on the host being analysed.

    2. It is ROBUST to non-Gaussian, heavy-tailed feature distributions
       — exactly what process resource data looks like. The same problem
       that motivated using Modified Z-Score (MAD) over standard Z-score
       for the statistical detector.

    3. It is LIGHTWEIGHT and FAST — training and prediction on a few
       hundred processes complete in well under one second, suitable for
       interactive threat-hunt workflows.

    4. It is EXPLAINABLE at a coarse level — anomaly scores are bounded
       and interpretable, unlike deep-learning detectors whose decisions
       are opaque to forensic analysts.

Reference:
    Liu, F. T., Ting, K. M., & Zhou, Z.-H. (2008). "Isolation Forest."
    ICDM 2008, 413–422.

Training strategy
-----------------
A "warm-up + online retrain" strategy is used:

    - On the first WARMUP_SCANS scans, the model accumulates observations
      and treats every process as normal. No detections are produced.
    - After warm-up, the model retrains on the current snapshot at every
      scan (cheap, ~50 ms for 300 processes) and produces anomaly scores.
    - The contamination parameter is set conservatively (5%) — Isolation
      Forest assumes ~5% of training data are outliers.

This avoids the "cold-start zero-detection" problem and adapts to whatever
baseline the host machine establishes.

Score persistence
-----------------
Raw Isolation Forest scores are smoothed via exponential decay:

    persistent_score = α × current + (1-α) × previous

This ensures that processes which are *consistently* anomalous accumulate
higher scores over multiple scans, while one-off spikes (browser loading
a heavy page, game launcher updating) decay quickly. Stale PIDs are
pruned each scan to prevent unbounded memory growth.

Graceful degradation
--------------------
If scikit-learn is not installed, the module silently returns
(score=0, reasons=[]) instead of crashing. This means Reezium remains
functional even without the ML dependency — the statistical/entropy/
heuristic detectors continue to operate normally.
"""

import logging
import math
import os.path
import time

logger = logging.getLogger('reezium.detection.ml')


# --- Optional scikit-learn import ------------------------------------------
# scikit-learn is the only "heavy" dependency in the project. If it's
# missing, we degrade gracefully instead of breaking the whole tool.

try:
    from sklearn.ensemble import IsolationForest
    from sklearn.preprocessing import StandardScaler
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    logger.warning(
        "scikit-learn not installed. ML detection disabled. "
        "Install with: pip install scikit-learn"
    )


# --- Tunable constants -----------------------------------------------------

# Number of scans to observe before the model starts producing detections.
# During warm-up, the model accumulates observations but flags nothing.
WARMUP_SCANS = 3

# Isolation Forest hyper-parameters.
# contamination = expected proportion of outliers in the training data.
# A typical clean Windows desktop has very few genuine anomalies, so 5%
# is a reasonable upper bound (matches sklearn's recommended default).
N_ESTIMATORS = 100      # number of trees — 100 is sklearn's default
CONTAMINATION = 0.05    # 5% expected outliers
RANDOM_STATE = 42       # reproducibility for the FYP evaluation chapter

# Anomaly-score threshold for flagging. Isolation Forest returns scores
# where MORE NEGATIVE = MORE ANOMALOUS. We flag anything below this.
ANOMALY_SCORE_THRESHOLD = -0.05

# Maximum points contributed to the threat score (parallels the
# statistical detector's STATISTICAL_SCORE_CAP). Kept below the scorer's
# REPORTING_THRESHOLD so ML alone cannot trigger an alert — corroboration
# from another signal is required.
ML_SCORE_CAP = 25

# Exponential-decay factor for score persistence (0 < α ≤ 1).
# Higher α = more weight to the current scan, faster decay of old scores.
# 0.4 gives roughly a 3-scan half-life: a one-off spike at scan T is
# reduced to ~0.22x by scan T+3.
PERSISTENCE_ALPHA = 0.4


# --- Feature extraction ----------------------------------------------------

def extract_features(item, name_entropy):
    """Build the feature vector for one process.

    The same features used to train the model are used at prediction time,
    so this function is the single source of truth for what the model
    "sees" about each process.

    Features 1–6 are the original set; features 7–12 were added to give
    the Isolation Forest a wider behavioral view (handle count, process
    age, child count, exe existence, module count, parent name entropy).

    Args:
        item: dict with 'cpu', 'mem', 'th', 'connections', and the
              enrichment fields 'handle_count', 'process_age',
              'child_count', 'exe_exists', 'module_count',
              'parent_entropy'.  Missing keys default to 0.
        name_entropy: Shannon entropy of the process name (already
                      computed by the entropy detector — passed in to
                      avoid recomputing).

    Returns:
        A list of 12 numeric features.
    """
    info = item.get('info', {})
    name = info.get('name') or ''
    cmdline = info.get('cmdline') or []
    if isinstance(cmdline, list):
        cmdline_len = sum(len(c) for c in cmdline)
    else:
        cmdline_len = len(str(cmdline))

    return [
        # --- Original features (1–6) ---
        item.get('cpu', 0.0),            # 1. CPU%
        item.get('mem', 0.0),            # 2. Memory%
        item.get('th', 0),               # 3. Thread count
        item.get('connections', 0),      # 4. Network connection count
        name_entropy,                    # 5. Entropy of process name
        cmdline_len,                     # 6. Total command-line length
        # --- Enriched features (7–12) ---
        item.get('handle_count', 0),     # 7. Open handles (ransomware signal)
        item.get('process_age', 0),      # 8. Seconds alive (short = suspicious)
        item.get('child_count', 0),      # 9. Child process count (dropper signal)
        item.get('exe_exists', 1),       # 10. 0 if exe path missing/invalid
        item.get('module_count', 0),     # 11. Loaded DLL/module count
        item.get('parent_entropy', 0.0), # 12. Entropy of parent's name
    ]


# --- Detector class --------------------------------------------------------

class IsolationForestDetector:
    """Stateful Isolation Forest detector with online training and score
    persistence.

    The detector is instantiated once at app start and reused across
    scans. Internal state:
        self._scan_count        — how many scans have been seen
        self._model             — the fitted IsolationForest (None during warm-up)
        self._scaler            — feature standardiser (None during warm-up)
        self._persistent_scores — per-PID exponentially-decayed anomaly scores
    """

    def __init__(self):
        self._scan_count = 0
        self._model = None
        self._scaler = None
        self._persistent_scores = {}  # pid -> smoothed anomaly score
        self.enabled = SKLEARN_AVAILABLE

    @property
    def is_warmed_up(self):
        """True when the model has seen enough scans to start detecting."""
        return self._scan_count >= WARMUP_SCANS

    def fit_and_predict(self, feature_matrix, pids=None):
        """Train on the current snapshot and score every process in it.

        Args:
            feature_matrix: list of lists, one row per process, columns
                            in the order produced by extract_features().
            pids: optional parallel list of PIDs (same length as
                  feature_matrix). When provided, anomaly scores are
                  smoothed via exponential decay per PID so that
                  processes which are consistently anomalous accumulate
                  higher scores across scans.

        Returns:
            A list of anomaly scores (one per process), in the same order
            as feature_matrix. Lower (more negative) = more anomalous.
            Returns [0.0] * len(feature_matrix) if scikit-learn is missing
            or the detector is still warming up.
        """
        if not SKLEARN_AVAILABLE:
            return [0.0] * len(feature_matrix)

        self._scan_count += 1

        if not self.is_warmed_up:
            logger.debug(
                "ML detector warming up (%d/%d scans)",
                self._scan_count, WARMUP_SCANS
            )
            return [0.0] * len(feature_matrix)

        if not feature_matrix:
            return []

        try:
            # Standardise features. This is important for Isolation Forest
            # because feature scales vary wildly (CPU% in [0,100],
            # threads in [1, 1000+], cmdline_len in [0, 10000+]).
            self._scaler = StandardScaler()
            X = self._scaler.fit_transform(feature_matrix)

            # Train a fresh forest each scan. With 100 trees on ~300
            # processes, this takes ~50 ms — cheap enough to do online.
            self._model = IsolationForest(
                n_estimators=N_ESTIMATORS,
                contamination=CONTAMINATION,
                random_state=RANDOM_STATE,
                n_jobs=1,  # single-thread to avoid contending with sampler
            )
            self._model.fit(X)

            # decision_function returns scores where MORE NEGATIVE = MORE
            # ANOMALOUS. (Note: there's also score_samples() but
            # decision_function is the convention.)
            raw_scores = self._model.decision_function(X).tolist()

            # --- Score persistence (exponential decay) ---
            # If PIDs are provided, smooth each score so that processes
            # which are consistently anomalous across multiple scans
            # accumulate lower (more anomalous) persistent scores, while
            # one-off spikes decay quickly toward 0.
            if pids and len(pids) == len(raw_scores):
                current_pids = set()
                smoothed = []
                alpha = PERSISTENCE_ALPHA
                for pid, score in zip(pids, raw_scores):
                    current_pids.add(pid)
                    prev = self._persistent_scores.get(pid, 0.0)
                    persistent = alpha * score + (1 - alpha) * prev
                    self._persistent_scores[pid] = persistent
                    smoothed.append(persistent)

                # Prune stale PIDs to prevent unbounded memory growth.
                stale = [p for p in self._persistent_scores
                         if p not in current_pids]
                for p in stale:
                    del self._persistent_scores[p]

                return smoothed

            return raw_scores
        except Exception as e:
            logger.error("Isolation Forest scoring failed: %s", e)
            return [0.0] * len(feature_matrix)


# Module-level singleton — created once, reused across scans.
detector = IsolationForestDetector()


# --- Scoring function (called from scorer.py) ------------------------------

def score_process_ml(anomaly_score):
    """Convert an Isolation Forest anomaly score into Reezium's point system.

    ML anomalies are behavioural and do not map to a specific MITRE ATT&CK
    technique, so mitre_tags is always empty.

    Args:
        anomaly_score: float from IsolationForest.decision_function().
                       More negative = more anomalous.

    Returns:
        (score_contribution, reasons_list, mitre_tags)
    """
    if anomaly_score >= ANOMALY_SCORE_THRESHOLD:
        return 0, [], []

    # Map anomaly_score in roughly [-0.5, ANOMALY_SCORE_THRESHOLD] to
    # points in [0, ML_SCORE_CAP]. The lower (more anomalous) the score,
    # the more points contributed, up to the cap.
    distance = ANOMALY_SCORE_THRESHOLD - anomaly_score   # >= 0
    points = min(ML_SCORE_CAP, distance * 80)

    reasons = [
        f"ML Anomaly (Isolation Forest score: {round(anomaly_score, 3)})"
    ]
    return round(points, 1), reasons, []