"""
core/detection/statistical.py
-----------------------------
Statistical anomaly detection for the threat-hunt engine.

Implements Modified Z-Score using Median Absolute Deviation (MAD), which is
robust to outliers and works on non-normal distributions — unlike the
standard Z-score which assumes normality (a poor assumption for process
resource usage data, which is heavily right-skewed).

Reference: Iglewicz & Hoaglin (1993), "Volume 16: How to Detect and Handle
Outliers", The ASQC Basic References in Quality Control.

Calibration note (post-empirical-tuning):
    Score contributions from this module are capped at 25, which is
    deliberately BELOW the scorer's 30-point reporting threshold. This
    means a process flagged ONLY by statistical anomaly will not surface
    as a threat — it needs at least one other corroborating signal
    (entropy, suspicious path, parent-child chain, etc.) to combine with.

    This matches real-world EDR practice: high resource use alone is not
    a threat indicator. Legitimate apps (Python interpreters running
    Reezium, SteamWebHelper rendering the storefront, Chrome browsing
    heavy pages) routinely look like statistical outliers on a quiet
    system. Requiring corroboration is what separates a noisy signal
    from an actionable alert.
"""

import statistics


# Score-contribution cap. Must be < scorer.REPORTING_THRESHOLD so that
# statistical anomaly cannot trigger an alert by itself.
STATISTICAL_SCORE_CAP = 25


def get_stats(vals):
    """Return (median, MAD) for a list of numeric values.

    Uses Median Absolute Deviation instead of mean/std_dev for robustness
    against the heavy right-skew typical of process resource data.

    Returns:
        (median, mad) — MAD is forced to a small positive value if zero,
        to avoid division-by-zero downstream.
    """
    if not vals or len(vals) < 2:
        return 0, 1
    median = statistics.median(vals)
    mad = statistics.median([abs(v - median) for v in vals])
    # If MAD is 0 (all values identical), use a small fallback
    return median, (mad if mad > 0 else 1)


def modified_z_score(value, median, mad):
    """Modified Z-score using MAD: 0.6745 * (x - median) / MAD.

    The constant 0.6745 is the 0.75 quantile of the standard normal
    distribution, used to make MAD comparable to standard deviation
    for normally distributed data.
    """
    return 0.6745 * (value - median) / mad


def score_process_statistical(item, mu_cpu, sigma_cpu, mu_mem, sigma_mem,
                              mu_th, sigma_th):
    """Score a single process based on resource-usage Modified Z-scores.

    Returns a "contributing signal" score (capped at STATISTICAL_SCORE_CAP),
    not a standalone alert. The scorer combines this with other signals
    before deciding whether to fire a threat.

    Statistical anomalies do not map to a specific MITRE ATT&CK technique,
    so mitre_tags is always empty.

    Args:
        item: A dict containing 'cpu', 'mem', 'th' for the process.
        mu_*, sigma_*: Population statistics (median, MAD) computed
                       across all processes.

    Returns:
        (score_contribution, reasons_list, mitre_tags)
    """
    score = 0
    reasons = []

    z_cpu = modified_z_score(item['cpu'], mu_cpu, sigma_cpu)
    z_mem = modified_z_score(item['mem'], mu_mem, sigma_mem)
    _ = modified_z_score(item['th'], mu_th, sigma_th)   # reserved

    # CPU anomaly — threshold tuned so legitimate apps don't trip the rule.
    # On a real desktop, Z>10 typically means "actually busy", not "malicious".
    # The capped score means this alone can't trigger an alert.
    if z_cpu > 10:
        score += min(z_cpu * 2, STATISTICAL_SCORE_CAP)
        reasons.append(f"Abnormal CPU Usage (Modified Z: {round(z_cpu, 1)})")

    # Memory anomaly — even higher threshold, because legitimate browsers,
    # IDEs, and game launchers routinely sit at Z=5–15 on a clean system.
    if z_mem > 15:
        score += min(z_mem * 1.5, STATISTICAL_SCORE_CAP)
        reasons.append(f"Abnormal Memory Usage (Modified Z: {round(z_mem, 1)})")

    # Hard cap on combined statistical contribution.
    score = min(score, STATISTICAL_SCORE_CAP)

    return score, reasons, []