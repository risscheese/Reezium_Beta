"""
core/cloud/threat_intel.py
--------------------------
Cloud-based threat intelligence enrichment for Reezium Imager.

Integrates with:
    - VirusTotal v3 API  (file hash reputation)
    - AbuseIPDB v2 API   (IP reputation)

Both services offer generous free tiers:
    - VirusTotal: 500 requests/day, 4 requests/minute
    - AbuseIPDB:  1000 requests/day

All lookups are cached in memory with TTL to respect rate limits
and avoid redundant network calls during repeated scans.

Configuration
-------------
API keys are loaded from (in priority order):
    1. Environment variables:  REEZIUM_VT_API_KEY, REEZIUM_ABUSEIPDB_API_KEY
    2. config.json in the project root

If no API keys are configured, every lookup returns an empty result
and the tool continues to function normally with local-only detection.
"""

import hashlib
import json
import logging
import os
import time
import threading

import requests

logger = logging.getLogger('reezium.cloud.threat_intel')


# --- Configuration loading --------------------------------------------------

def _load_config():
    """Load API keys from environment variables or config.json.

    Environment variables take precedence over the config file so that
    CI/CD pipelines and containers can inject secrets without touching
    the filesystem.
    """
    vt_key = os.environ.get('REEZIUM_VT_API_KEY', '')
    abuseipdb_key = os.environ.get('REEZIUM_ABUSEIPDB_API_KEY', '')

    if not vt_key or not abuseipdb_key:
        # Resolve config.json path for both frozen (PyInstaller) and dev mode.
        # When frozen, __file__ points inside _MEIPASS (the temp extraction
        # folder), so we use sys._MEIPASS instead to reach the bundle root.
        import sys
        if getattr(sys, 'frozen', False):
            base_dir = sys._MEIPASS
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(
                os.path.abspath(__file__)
            )))
        config_path = os.path.join(base_dir, 'config.json')
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8-sig') as f:
                    config = json.load(f)
                ti = config.get('threat_intel', {})
                if not vt_key:
                    vt_key = ti.get('virustotal_api_key', '')
                if not abuseipdb_key:
                    abuseipdb_key = ti.get('abuseipdb_api_key', '')
            except (json.JSONDecodeError, OSError) as e:
                logger.warning("Failed to read config.json: %s", e)

    return vt_key, abuseipdb_key


# --- In-memory cache --------------------------------------------------------

class _TTLCache:
    """Thread-safe dict with per-entry time-to-live expiration.

    Entries are lazily pruned on access. No background thread needed
    because the cache is small (hundreds of entries at most).
    """

    def __init__(self, ttl_seconds=3600):
        self._ttl = ttl_seconds
        self._store = {}   # key -> (value, expire_time)
        self._lock = threading.Lock()

    def get(self, key):
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            value, expire_time = entry
            if time.time() > expire_time:
                del self._store[key]
                return None
            return value

    def set(self, key, value):
        with self._lock:
            self._store[key] = (value, time.time() + self._ttl)

    def clear(self):
        with self._lock:
            self._store.clear()

    @property
    def size(self):
        with self._lock:
            return len(self._store)


# --- File hashing -----------------------------------------------------------

# Cache file hashes in memory to avoid re-reading the same exe
# across repeated scans.  Keyed on (path, mtime) so stale entries
# are implicitly invalidated if the file changes on disk.
_file_hash_cache = {}
_file_hash_lock = threading.Lock()


def _hash_file(filepath, algorithm='sha256'):
    """Compute the hash of a file on disk.

    Returns the hex digest string, or None if the file cannot be read
    (permissions, missing, too large, etc.).

    Results are cached keyed on (filepath, mtime) so repeated calls
    for the same unchanged file are effectively free.
    """
    try:
        stat = os.stat(filepath)
        # Skip files larger than 100 MB — hashing them would stall the scan.
        if stat.st_size > 100 * 1024 * 1024:
            return None
        cache_key = (filepath, stat.st_mtime)
    except OSError:
        return None

    with _file_hash_lock:
        cached = _file_hash_cache.get(cache_key)
        if cached is not None:
            return cached

    try:
        h = hashlib.new(algorithm)
        with open(filepath, 'rb') as f:
            for chunk in iter(lambda: f.read(65536), b''):
                h.update(chunk)
        digest = h.hexdigest()
    except (OSError, PermissionError, ValueError):
        return None

    with _file_hash_lock:
        _file_hash_cache[cache_key] = digest
    return digest


# --- Rate limiter -----------------------------------------------------------

class _RateLimiter:
    """Simple sliding-window rate limiter.

    Tracks timestamps of recent calls and blocks (returns False) when
    the limit would be exceeded. Thread-safe.
    """

    def __init__(self, max_calls, period_seconds):
        self._max_calls = max_calls
        self._period = period_seconds
        self._timestamps = []
        self._lock = threading.Lock()

    def allow(self):
        now = time.time()
        with self._lock:
            # Prune old timestamps outside the sliding window.
            self._timestamps = [
                t for t in self._timestamps if now - t < self._period
            ]
            if len(self._timestamps) >= self._max_calls:
                return False
            self._timestamps.append(now)
            return True


# --- VirusTotal client ------------------------------------------------------

_VT_BASE_URL = 'https://www.virustotal.com/api/v3'

def _query_virustotal(file_hash, api_key):
    """Query VirusTotal v3 for a file hash.

    Args:
        file_hash: SHA256, SHA1, or MD5 hash string.
        api_key:   VirusTotal API key.

    Returns:
        A dict with enrichment data, or None on failure.
    """
    try:
        resp = requests.get(
            f'{_VT_BASE_URL}/files/{file_hash}',
            headers={'x-apikey': api_key},
            timeout=10,
        )
        if resp.status_code == 404:
            return {'found': False, 'hash': file_hash}
        if resp.status_code == 429:
            logger.warning("VirusTotal rate limit exceeded")
            return None
        if resp.status_code != 200:
            logger.warning("VirusTotal returned HTTP %d", resp.status_code)
            return None

        data = resp.json().get('data', {}).get('attributes', {})
        stats = data.get('last_analysis_stats', {})

        return {
            'found': True,
            'hash': file_hash,
            'provider': 'virustotal',
            'malicious': stats.get('malicious', 0),
            'suspicious': stats.get('suspicious', 0),
            'undetected': stats.get('undetected', 0),
            'total_engines': sum(stats.values()) if stats else 0,
            'reputation': data.get('reputation', 0),
            'popular_threat_name': data.get('popular_threat_classification', {})
                                       .get('suggested_threat_label', ''),
            'tags': data.get('tags', [])[:5],
        }
    except requests.RequestException as e:
        logger.error("VirusTotal lookup failed: %s", e)
        return None


# --- AbuseIPDB client -------------------------------------------------------

_ABUSEIPDB_BASE_URL = 'https://api.abuseipdb.com/api/v2'

def _query_abuseipdb(ip_address, api_key):
    """Query AbuseIPDB v2 for an IP address reputation.

    Args:
        ip_address: IPv4 or IPv6 string.
        api_key:    AbuseIPDB API key.

    Returns:
        A dict with enrichment data, or None on failure.
    """
    try:
        resp = requests.get(
            f'{_ABUSEIPDB_BASE_URL}/check',
            params={
                'ipAddress': ip_address,
                'maxAgeInDays': 90,
            },
            headers={
                'Key': api_key,
                'Accept': 'application/json',
            },
            timeout=10,
        )
        if resp.status_code == 429:
            logger.warning("AbuseIPDB rate limit exceeded")
            return None
        if resp.status_code != 200:
            logger.warning("AbuseIPDB returned HTTP %d", resp.status_code)
            return None

        data = resp.json().get('data', {})
        return {
            'found': True,
            'ip': ip_address,
            'provider': 'abuseipdb',
            'abuse_confidence': data.get('abuseConfidenceScore', 0),
            'total_reports': data.get('totalReports', 0),
            'country_code': data.get('countryCode', ''),
            'isp': data.get('isp', ''),
            'is_tor': data.get('isTor', False),
            'is_public': data.get('isPublic', True),
            'last_reported': data.get('lastReportedAt', ''),
        }
    except requests.RequestException as e:
        logger.error("AbuseIPDB lookup failed: %s", e)
        return None


# --- Public client class ----------------------------------------------------

class ThreatIntelClient:
    """High-level client for cloud threat intelligence lookups.

    Manages API keys, caching, and rate limiting. Thread-safe.

    Usage::

        client = ThreatIntelClient()
        if client.vt_configured:
            result = client.lookup_hash('abc123...')
        if client.abuseipdb_configured:
            result = client.lookup_ip('1.2.3.4')
    """

    def __init__(self, virustotal_key=None, abuseipdb_key=None):
        default_vt, default_abuse = _load_config()
        self._vt_key = virustotal_key if virustotal_key is not None else default_vt
        self._abuseipdb_key = abuseipdb_key if abuseipdb_key is not None else default_abuse

        # Caches: VT results valid for 1 hour, AbuseIPDB for 30 minutes.
        self._vt_cache = _TTLCache(ttl_seconds=3600)
        self._abuseipdb_cache = _TTLCache(ttl_seconds=1800)

        # Rate limiters matching free-tier quotas.
        # VT free: 4 requests/minute (we use 3 to leave headroom).
        # AbuseIPDB: 1000/day ≈ ~41/hour (we use 30/minute to be safe).
        self._vt_limiter = _RateLimiter(max_calls=3, period_seconds=60)
        self._abuseipdb_limiter = _RateLimiter(max_calls=30, period_seconds=60)

        if self._vt_key:
            logger.info("VirusTotal API key configured")
        if self._abuseipdb_key:
            logger.info("AbuseIPDB API key configured")
        if not self._vt_key and not self._abuseipdb_key:
            logger.info(
                "No threat intelligence API keys configured. "
                "Cloud enrichment disabled. Set keys in config.json "
                "or via environment variables."
            )

    @property
    def vt_configured(self):
        return bool(self._vt_key)

    @property
    def abuseipdb_configured(self):
        return bool(self._abuseipdb_key)

    def is_configured(self):
        """True if at least one cloud provider has an API key."""
        return self.vt_configured or self.abuseipdb_configured

    def get_status(self):
        """Return configuration status for the /api/intel/status endpoint."""
        return {
            'virustotal': {
                'configured': self.vt_configured,
                'cache_size': self._vt_cache.size,
            },
            'abuseipdb': {
                'configured': self.abuseipdb_configured,
                'cache_size': self._abuseipdb_cache.size,
            },
        }

    def lookup_hash(self, file_hash):
        """Look up a file hash on VirusTotal.

        Returns a dict with enrichment data, or a 'not configured'
        placeholder if no API key is set.
        """
        if not self._vt_key:
            return {'error': 'VirusTotal API key not configured'}

        # Check cache first.
        cached = self._vt_cache.get(file_hash)
        if cached is not None:
            cached['cached'] = True
            return cached

        # Rate limit check.
        if not self._vt_limiter.allow():
            return {'error': 'Rate limit exceeded. Try again in a moment.'}

        result = _query_virustotal(file_hash, self._vt_key)
        if result is not None:
            self._vt_cache.set(file_hash, result)
            result['cached'] = False
        else:
            result = {'error': 'VirusTotal lookup failed'}

        return result

    def lookup_ip(self, ip_address):
        """Look up an IP address on AbuseIPDB.

        Returns a dict with enrichment data, or a 'not configured'
        placeholder if no API key is set.
        """
        if not self._abuseipdb_key:
            return {'error': 'AbuseIPDB API key not configured'}

        # Skip private/loopback addresses — they won't be in AbuseIPDB.
        if ip_address.startswith(('127.', '10.', '192.168.', '0.0.0.0', '::')):
            return {'skipped': True, 'reason': 'Private/loopback address'}

        cached = self._abuseipdb_cache.get(ip_address)
        if cached is not None:
            cached['cached'] = True
            return cached

        if not self._abuseipdb_limiter.allow():
            return {'error': 'Rate limit exceeded. Try again in a moment.'}

        result = _query_abuseipdb(ip_address, self._abuseipdb_key)
        if result is not None:
            self._abuseipdb_cache.set(ip_address, result)
            result['cached'] = False
        else:
            result = {'error': 'AbuseIPDB lookup failed'}

        return result

    def enrich_threats(self, threats, connections=None):
        """Batch-enrich a list of threat dicts with cloud intelligence.

        Adds a 'cloud_intel' key to each threat dict in-place.

        This is best-effort: if a lookup fails or is rate-limited,
        the threat simply won't have cloud enrichment data.

        Args:
            threats:     List of threat dicts from scorer.run_threat_scan().
            connections: Optional dict of pid -> [connection_info] for IP
                         lookups. If None, IP enrichment is skipped.
        """
        if not self.is_configured():
            return

        for threat in threats:
            intel = {}

            # VirusTotal: hash the process executable and look it up.
            if self.vt_configured:
                exe_path = threat.get('exe', '')
                if not exe_path and threat.get('pid'):
                    try:
                        import psutil
                        p = psutil.Process(int(threat['pid']))
                        exe_path = p.exe()
                        threat['exe'] = exe_path
                    except (Exception,):
                        pass

                if exe_path and os.path.isfile(exe_path):
                    file_hash = _hash_file(exe_path)
                    if file_hash:
                        threat['file_hash'] = file_hash
                        vt_result = self.lookup_hash(file_hash)
                        if vt_result and not vt_result.get('error'):
                            intel['virustotal'] = vt_result

            # AbuseIPDB: enrich remote IPs from connections associated
            # with this threat's PID.
            if self.abuseipdb_configured and connections:
                pid = threat.get('pid')
                pid_conns = connections.get(pid, [])
                ip_results = []
                for conn in pid_conns[:3]:  # Limit to 3 IPs per process.
                    raddr = getattr(conn, 'raddr', None)
                    if raddr and raddr.ip:
                        ip_result = self.lookup_ip(raddr.ip)
                        if ip_result and not ip_result.get('skipped'):
                            ip_results.append(ip_result)
                if ip_results:
                    intel['ip_reputation'] = ip_results

            if intel:
                threat['cloud_intel'] = intel


# Module-level singleton — created once, reused across requests.
intel_client = ThreatIntelClient()
