@echo off
echo ============================================
echo   Reezium Imager - Build Script
echo ============================================

echo.
echo [1/3] Checking/Installing Build Dependencies...
python -m pip install --upgrade pip
python -m pip install pyinstaller pywebview flask psutil requests scikit-learn

echo.
echo [2/3] Cleaning previous builds...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist *.spec del /q *.spec

echo.
echo [3/3] Running PyInstaller...
REM --onefile     : Bundle everything into a single .exe
REM --icon        : Application icon
REM --add-data    : Include Flask templates, static assets, and detection config
REM --add-binary  : Include the WinPMEM driver for memory capture
REM --hidden-import: Ensure dynamically loaded modules are found
REM --name        : Output filename

python -m PyInstaller --noconfirm --onefile --clean ^
    --icon "static\favicon.ico" ^
    --name "Reezium Imager" ^
    --add-data "templates;templates" ^
    --add-data "static;static" ^
    --add-data "config.json;." ^
    --add-data "core\detection\whitelist.json;core\detection" ^
    --add-binary "winpmem.exe;." ^
    --hidden-import "core" ^
    --hidden-import "core.capture_engine" ^
    --hidden-import "core.utils" ^
    --hidden-import "core.detection" ^
    --hidden-import "core.detection.scorer" ^
    --hidden-import "core.detection.statistical" ^
    --hidden-import "core.detection.entropy" ^
    --hidden-import "core.detection.heuristics" ^
    --hidden-import "core.detection.ml_models" ^
    --hidden-import "core.ai" ^
    --hidden-import "core.ai.llm_assistant" ^
    --hidden-import "core.cloud" ^
    --hidden-import "core.cloud.threat_intel" ^
    --hidden-import "routes" ^
    --hidden-import "routes.dashboard" ^
    --hidden-import "routes.processes" ^
    --hidden-import "routes.connections" ^
    --hidden-import "routes.threat_hunt" ^
    --hidden-import "routes.memory" ^
    --hidden-import "routes.system" ^
    --hidden-import "routes.capture" ^
    --hidden-import "routes.threat_intel" ^
    --hidden-import "routes.ai_assistant" ^
    --hidden-import "webview" ^
    --hidden-import "sklearn" ^
    --hidden-import "sklearn.ensemble" ^
    --hidden-import "sklearn.ensemble._iforest" ^
    --hidden-import "sklearn.preprocessing" ^
    --hidden-import "sklearn.utils._typedefs" ^
    --hidden-import "sklearn.neighbors._partition_nodes" ^
    --hidden-import "engineio.async_drivers.threading" ^
    app.py

echo.
if exist "dist\Reezium Imager.exe" (
    echo ============================================
    echo [SUCCESS] Build successful!
    echo Location: dist\Reezium Imager.exe
    echo ============================================
) else (
    echo ============================================
    echo [ERROR] Build failed. Check the error messages above.
    echo ============================================
)
pause
