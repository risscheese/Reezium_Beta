#!/bin/bash
# ============================================================================
# build_linux.sh — Reezium Imager Build Script for Linux (Kali, Ubuntu, etc.)
# ============================================================================
#
# Linux counterpart of build_exe.bat. Produces a standalone ELF binary in
# dist/reezium-linux that can be copied to a USB stick and run on any Linux
# host of the same CPU architecture without requiring Python or any of
# Reezium's pip dependencies to be installed on the target.
#
# IMPORTANT — This script MUST run on Linux. PyInstaller does not cross-
# compile from Windows. If you need a Linux build, run this on Kali, Ubuntu,
# or a Linux VM — not on your Windows dev machine.
#
# This version uses a virtual environment (PEP 668 compliant), required by
# modern Kali, Debian 12+, and Ubuntu 24+ which refuse system-wide pip
# installs by default to protect OS-managed Python packages.
#
# Usage:
#     chmod +x build_linux.sh
#     ./build_linux.sh
#
# Output:
#     dist/reezium-linux    — the standalone Linux binary (~30-50 MB)
# ============================================================================

set -e   # Exit on any error — don't silently continue with a broken build.

echo "============================================"
echo "  Reezium Imager - Linux Build Script"
echo "============================================"
echo

# ---- Step 0: sanity check — refuse to run on the wrong OS ------------------

if [[ "$(uname)" != "Linux" ]]; then
    echo "[ERROR] This script must be run on Linux."
    echo "        Detected OS: $(uname)"
    echo "        PyInstaller cannot cross-compile from Windows or macOS."
    exit 1
fi

echo "[0/5] Detected OS:   $(uname) $(uname -r)"
echo "      Detected arch: $(uname -m)"
echo

# ---- Step 1: ensure venv support is available -----------------------------
# python3-venv is sometimes not installed by default on minimal Linux images.

echo "[1/5] Ensuring python3-venv is available..."
if ! python3 -c "import venv" 2>/dev/null; then
    echo "      python3-venv module not found — installing via apt..."
    sudo apt update
    sudo apt install -y python3-venv python3-pip
else
    echo "      python3-venv: OK"
fi
echo

# ---- Step 2: create or reuse the virtual environment ----------------------
# A venv isolates our build dependencies (PyInstaller, sklearn, flask, etc.)
# from the system Python, which is required by PEP 668 on modern Kali.

VENV_DIR="venv-build"

echo "[2/5] Preparing virtual environment in ./${VENV_DIR}/ ..."
if [[ ! -d "$VENV_DIR" ]]; then
    python3 -m venv "$VENV_DIR"
    echo "      Created new venv: ${VENV_DIR}"
else
    echo "      Reusing existing venv: ${VENV_DIR}"
fi

# Activate the venv for the rest of this script. From here on, every 'pip'
# and 'python3' command targets the venv, not the system Python.
# shellcheck disable=SC1091
source "${VENV_DIR}/bin/activate"
echo "      Activated: $(which python3)"
echo

# ---- Step 3: install build dependencies into the venv ---------------------

echo "[3/5] Installing build dependencies inside the venv..."

# Upgrade pip first, otherwise sklearn may fail on Kali's older bundled pip.
python3 -m pip install --upgrade pip

# Core runtime + build dependencies. Inside a venv there is no need for
# --break-system-packages because the venv is not "externally managed".
python3 -m pip install --upgrade \
    pyinstaller \
    flask \
    psutil \
    requests \
    scikit-learn

# pywebview is optional on Linux (it needs GTK/Qt). Forensic workflows
# on Linux typically use CLI or browser mode anyway, so we tolerate failure.
python3 -m pip install pywebview 2>/dev/null || \
    echo "      Note: pywebview unavailable on this system (CLI mode unaffected)."
echo

# ---- Step 4: verify AVML is present (the Linux memory acquisition tool) ---

echo "[4/5] Verifying AVML is present..."
if [[ ! -f "avml" ]]; then
    echo "[ERROR] avml binary not found in the project root."
    echo "        Download from the official source:"
    echo
    echo "          wget https://github.com/microsoft/avml/releases/latest/download/avml"
    echo "          chmod +x avml"
    echo
    exit 1
fi
chmod +x avml
echo "      Found: ./avml ($(stat -c '%s' avml) bytes)"
echo

# ---- Step 5: run PyInstaller ----------------------------------------------

echo "[5/5] Cleaning previous build artefacts and running PyInstaller..."
rm -rf build dist
rm -f reezium-linux.spec Reezium Imager.spec

# Notes on the PyInstaller flags below:
#   --add-data uses ':' on Linux (versus ';' on Windows)
#   --onefile bundles everything into a single executable file
#   No --windowed flag (Linux ELF binaries don't hide consoles that way)
#   No --icon flag (Linux doesn't embed icons into ELFs)
#
# The many --hidden-import flags exist because PyInstaller's static analysis
# sometimes misses imports that happen via Flask blueprint discovery or
# scikit-learn's lazy submodule loading.

python3 -m PyInstaller --noconfirm --onefile --clean \
    --name "reezium-linux" \
    --add-data "templates:templates" \
    --add-data "static:static" \
    --add-data "config.json:." \
    --add-data "core/detection/whitelist.json:core/detection" \
    --add-binary "avml:." \
    --hidden-import "core" \
    --hidden-import "core.capture_engine" \
    --hidden-import "core.utils" \
    --hidden-import "core.detection" \
    --hidden-import "core.detection.scorer" \
    --hidden-import "core.detection.statistical" \
    --hidden-import "core.detection.entropy" \
    --hidden-import "core.detection.heuristics" \
    --hidden-import "core.detection.ml_models" \
    --hidden-import "core.ai" \
    --hidden-import "core.ai.llm_assistant" \
    --hidden-import "core.cloud" \
    --hidden-import "core.cloud.threat_intel" \
    --hidden-import "routes" \
    --hidden-import "routes.dashboard" \
    --hidden-import "routes.processes" \
    --hidden-import "routes.connections" \
    --hidden-import "routes.threat_hunt" \
    --hidden-import "routes.memory" \
    --hidden-import "routes.capture" \
    --hidden-import "routes.system" \
    --hidden-import "routes.threat_intel" \
    --hidden-import "routes.ai_assistant" \
    --hidden-import "sklearn" \
    --hidden-import "sklearn.ensemble" \
    --hidden-import "sklearn.ensemble._iforest" \
    --hidden-import "sklearn.preprocessing" \
    --hidden-import "sklearn.preprocessing._data" \
    --hidden-import "sklearn.utils._typedefs" \
    --hidden-import "sklearn.neighbors._partition_nodes" \
    --hidden-import "engineio.async_drivers.threading" \
    app.py

echo
# ---- Result check ---------------------------------------------------------

if [[ -f "dist/reezium-linux" ]]; then
    SIZE=$(du -h dist/reezium-linux | cut -f1)
    echo "[SUCCESS] Build successful!"
    echo "          Location: $(pwd)/dist/reezium-linux"
    echo "          Size:     ${SIZE}"
    echo
    echo "To use:"
    echo "    chmod +x dist/reezium-linux"
    echo "    sudo ./dist/reezium-linux --cli --case TEST-001"
    echo
    echo "Or copy to a USB stick for field deployment:"
    echo "    cp dist/reezium-linux /media/\$USER/USB_DRIVE/Reezium/"
else
    echo "[ERROR] Build failed. Check the PyInstaller output above."
    exit 1
fi