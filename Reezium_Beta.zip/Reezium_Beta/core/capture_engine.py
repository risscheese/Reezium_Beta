"""
core/capture_engine.py
----------------------
The CaptureEngine class is the single authority for memory acquisition.
It wraps the external drivers (WinPMEM on Windows, AVML on Linux) and
exposes a unified status surface used by both the CLI and Web UI.

Improvements applied:
    - Hash computation (MD5 + SHA256) for chain-of-custody
    - Write-protect output after capture
    - Order of volatility pre-capture snapshot
    - Tool footprint disclosure in metadata
    - Proper logging instead of print()
    - Thread-safe error handling (no re-raise in threads)
    - OS-guarded ctypes calls
"""

import psutil
import platform
import datetime
import time
import hashlib
import os
import json
import subprocess
import threading
import shutil
import sys
import ctypes
import logging

logger = logging.getLogger('reezium.capture')


class CaptureEngine:
    """Unified memory-acquisition controller shared by CLI and Web modes."""

    def __init__(self):
        self.status = 'idle'
        self.progress = 0
        self.message = 'Ready'
        self.filename = None
        self.captured_os = None   # 'Windows' or 'Linux' — set after a successful capture
        self.error = None

    def is_admin(self):
        """Return True if the current process has admin/root privileges."""
        if platform.system() == 'Windows':
            try:
                if ctypes.windll.shell32.IsUserAnAdmin() != 0:
                    return True
            except Exception:
                pass
            return False
        else:
            try:
                return os.geteuid() == 0
            except Exception:
                return False

    def check_requirements(self):
        """Locate the platform-appropriate acquisition driver.

        Searches in _MEIPASS (for PyInstaller onefile bundles), the directory
        containing the executable/script, and the project root.

        Returns the path to winpmem.exe (Windows) or avml (Linux), or None
        if the platform is unsupported. Does NOT raise if the file is
        missing — capture will fail later with a clear error.
        """
        current_os = platform.system()
        # capture_engine lives in core/, so the project root is one level up.
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        target_file = 'winpmem.exe' if current_os == 'Windows' else ('avml' if current_os == 'Linux' else None)
        if not target_file:
            return None

        # Build search locations in priority order
        search_dirs = []
        if getattr(sys, 'frozen', False):
            meipass = getattr(sys, '_MEIPASS', None)
            if meipass:
                search_dirs.append(meipass)
            search_dirs.append(os.path.dirname(sys.executable))

        search_dirs.append(base_dir)

        tool_path = None
        for d in search_dirs:
            candidate = os.path.join(d, target_file)
            if os.path.exists(candidate):
                tool_path = candidate
                break

        if not tool_path:
            # Fall back to default location for warning log
            tool_path = os.path.join(base_dir, target_file)
            logger.warning(
                "Capture tool not found at %s. "
                "RAM Capture will fail, but Analysis will work.", tool_path
            )

        return tool_path

    def get_storage_dir(self):
        """Return the directory where captured dumps should be saved.

        Frozen (PyInstaller) builds save next to the .exe. Source runs
        save next to the project root so the dump sits in the working tree.
        """
        if getattr(sys, 'frozen', False):
            return os.path.dirname(sys.executable)
        else:
            # Project root is one above core/
            return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    def compute_hashes(self, filepath):
        """Compute MD5 and SHA256 hashes of a file for chain-of-custody.

        Args:
            filepath: Absolute path to the file to hash.

        Returns:
            A dict with 'md5' and 'sha256' hex digest strings.
        """
        hashes = {
            'md5': hashlib.md5(),
            'sha256': hashlib.sha256(),
        }
        try:
            with open(filepath, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    for h in hashes.values():
                        h.update(chunk)
            return {k: v.hexdigest() for k, v in hashes.items()}
        except Exception as e:
            logger.error("Hash computation failed: %s", e)
            return {'md5': 'error', 'sha256': 'error'}

    def _write_protect(self, filepath):
        """Set the output file to read-only to prevent accidental modification."""
        try:
            if platform.system() == 'Windows':
                subprocess.run(['attrib', '+R', filepath], check=False)
            else:
                os.chmod(filepath, 0o444)
            logger.info("Write-protected output: %s", filepath)
        except Exception as e:
            logger.warning("Could not write-protect output: %s", e)

    def _capture_volatility_snapshot(self):
        """Capture order-of-volatility data before the RAM dump.

        Per RFC 3227 and NIST SP 800-86, we snapshot volatile data
        (processes, connections) before the memory acquisition because
        the act of dumping RAM alters RAM contents.

        Returns:
            A dict of pre-capture volatile data.
        """
        snapshot = {}
        try:
            # Process list
            procs = []
            for p in psutil.process_iter(['pid', 'name', 'ppid', 'status']):
                try:
                    procs.append(p.info)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            snapshot['process_count'] = len(procs)
            snapshot['processes_sample'] = procs[:50]

            # Network connections
            try:
                conns = psutil.net_connections(kind='inet')
                snapshot['connection_count'] = len(conns)
            except (psutil.AccessDenied, OSError):
                snapshot['connection_count'] = 'access_denied'

            # System info
            snapshot['cpu_percent'] = psutil.cpu_percent(interval=0.1)
            snapshot['memory_percent'] = psutil.virtual_memory().percent

        except Exception as e:
            logger.warning("Volatility snapshot partially failed: %s", e)

        return snapshot

    def _get_tool_footprint(self):
        """Document what artifacts this tool leaves on the system.

        Forensic best practice requires disclosing the acquisition tool's
        own footprint so analysts can exclude it from analysis.
        """
        footprint = {
            'tool_name': 'Reezium Imager',
            'tool_version': '0.1',
            'tool_pid': os.getpid(),
        }
        try:
            p = psutil.Process(os.getpid())
            footprint['tool_memory_mb'] = round(p.memory_info().rss / 1024 / 1024, 2)
            footprint['tool_exe'] = p.exe()
            footprint['tool_threads'] = p.num_threads()
        except Exception:
            pass
        return footprint

    def _cli_spinner(self):
        """Visual spinner while the long-running capture is in progress (CLI only)."""
        spinner = ['|', '/', '-', '\\']
        idx = 0
        while self.status == 'running':
            sys.stdout.write(f"\r[*] Capturing... {spinner[idx]} ")
            sys.stdout.flush()
            idx = (idx + 1) % len(spinner)
            time.sleep(0.1)
        sys.stdout.write("\r[*] Capturing... Done!   \n")

    def run_capture(self, output_path, options, is_cli=False):
        """Run the acquisition end-to-end. Updates self.status as it goes.

        NOTE: When called from a background thread (web UI mode), exceptions
        are caught and stored in self.error — NOT re-raised — so the thread
        exits cleanly and the UI can poll the error status.
        """
        self.status = 'running'
        self.message = 'Initializing...'

        try:
            tool_path = self.check_requirements()
            if not tool_path or not os.path.exists(tool_path):
                raise FileNotFoundError(
                    "Capture tool (winpmem/avml) not found. "
                    "Please place it in the app folder."
                )

            current_os = platform.system()

            # Pre-capture: order of volatility snapshot
            self.message = 'Capturing pre-dump volatility snapshot...'
            vol_snapshot = self._capture_volatility_snapshot()

            # Disk Check: need at least RAM size + 500 MB headroom
            mem = psutil.virtual_memory()
            required_bytes = mem.total + (500 * 1024 * 1024)
            free_bytes = shutil.disk_usage(os.path.dirname(output_path)).free

            if free_bytes < required_bytes:
                raise IOError(
                    f"Insufficient disk space. "
                    f"Need {round(required_bytes / 1024**3, 2)} GB."
                )

            # Prepare Command
            cmd = []
            if current_os == 'Windows':
                self.message = 'Acquiring Windows physical memory (WinPMEM)...'
                cmd = [tool_path, output_path]
            elif current_os == 'Linux':
                self.message = 'Acquiring Linux memory (LiME/AVML)...'
                os.chmod(tool_path, 0o755)
                cmd = ['sudo', tool_path, output_path]

            if is_cli:
                logger.info("Starting capture: %s", ' '.join(cmd))
                spinner_thread = threading.Thread(target=self._cli_spinner)
                spinner_thread.start()

            # Admin check (OS-guarded)
            if current_os == 'Windows':
                try:
                    is_admin_check = ctypes.windll.shell32.IsUserAnAdmin()
                    logger.debug("run_capture Admin Check: %s", is_admin_check)
                except Exception:
                    logger.debug("Admin check not available")
            else:
                logger.debug("Running on %s, skipping Windows admin check", current_os)

            # Execute
            startupinfo = None
            if os.name == 'nt':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                startupinfo=startupinfo
            )

            stdout, stderr = process.communicate()

            # WinPMEM returns 1 on "bad pages" but the dump is still usable.
            # Treat a >100 MB file as success even with a non-zero exit code.
            file_exists = os.path.exists(output_path)
            file_size = os.path.getsize(output_path) if file_exists else 0

            if process.returncode != 0:
                if file_exists and file_size > (100 * 1024 * 1024):
                    logger.warning(
                        "Tool reported read errors (Code %d), "
                        "but dump file was created.", process.returncode
                    )
                else:
                    raise Exception(
                        f"Tool failed (Code {process.returncode}): "
                        f"{stderr or stdout}"
                    )

            if file_exists and file_size > 0:
                # DO NOT set status to 'completed' yet — hash computation
                # and sidecar writing still need to finish. Setting it early
                # caused users to close the window (seeing "Done!") while
                # the multi-minute hash was still running, killing the
                # thread before the sidecar JSON was written.
                self.progress = 90
                self.message = f'Acquisition successful ({current_os}). Finalising...'
                self.filename = os.path.basename(output_path)
                self.captured_os = current_os   # expose to API for correct Volatility hint

                # Compute hashes for chain-of-custody
                # NOTE: For a 10 GB dump this takes 3-5 minutes.
                self.message = 'Computing integrity hashes (this may take a few minutes)...'
                file_hashes = self.compute_hashes(output_path)
                self.progress = 95

                # Write-protect the evidence file
                self._write_protect(output_path)

                # Sidecar metadata
                self.message = 'Writing evidence metadata...'
                meta_path = output_path + ".json"
                options['captured_os'] = current_os
                options['file_size_bytes'] = file_size
                options['hashes'] = file_hashes
                options['pre_capture_snapshot'] = vol_snapshot
                options['tool_footprint'] = self._get_tool_footprint()
                options['capture_completed'] = datetime.datetime.now().isoformat()

                with open(meta_path, 'w') as f:
                    json.dump(options, f, indent=2)

                # Forensic integrity: the sidecar JSON contains the dump's
                # MD5/SHA256 hashes used for chain-of-custody verification.
                # If the sidecar remained writable while the dump was
                # read-only, an attacker who tampered with both would only
                # need to update the hashes in the sidecar to mask the
                # tampering. Write-protecting the sidecar closes this gap.
                self._write_protect(meta_path)

                # NOW it's truly completed — all files written and protected.
                self.status = 'completed'
                self.progress = 100
                self.message = 'Capture complete. Evidence files secured.'

                if is_cli:
                    logger.info("Memory dumped to: %s", output_path)
                    logger.info("MD5:    %s", file_hashes.get('md5', 'N/A'))
                    logger.info("SHA256: %s", file_hashes.get('sha256', 'N/A'))
            else:
                raise Exception("Output file is missing or empty after capture.")

        except Exception as e:
            self.status = 'error'
            self.message = str(e)
            self.error = str(e)
            if is_cli:
                logger.error("%s", str(e))
                raise e
            else:
                # In thread mode (web UI), do NOT re-raise.
                # The UI polls self.status and will see 'error'.
                logger.error("Capture failed (thread mode): %s", str(e))


# Global engine instance — imported by routes and app.py.
engine = CaptureEngine()