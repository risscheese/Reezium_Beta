"""
core/detection/heuristics.py
----------------------------
Heuristic and signature-based detection rules. These encode "expert
knowledge" about what looks malicious on a Windows/Linux host.

Categories implemented:
    1. Suspicious keyword match in process name
    2. Shell + active network connection (reverse-shell indicator)
    3. Suspicious execution path (Temp, AppData, Public, /tmp, /dev/shm, etc.)
    4. System-process impersonation / masquerading (Windows + Linux)
    5. Parent-child process chain analysis (Windows + Linux)
    6. Linux-specific LOLBin / living-off-the-land command-line detection
    7. Linux suspicious path execution (/tmp, /dev/shm, /var/tmp, etc.)

Each detection is tagged with a MITRE ATT&CK technique ID for SOC-standard
reporting.

Platform detection
------------------
Linux-specific rules are gated behind a platform check at import time so
the same module works correctly on both Windows and Linux without producing
false positives from cross-platform rule mismatches.

Whitelist loading
-----------------
The KNOWN_GOOD_NAMES and SKIP_PROCESSES sets are loaded at import time
from core/detection/whitelist.json. If the file is missing or unparseable,
a minimal hardcoded fallback is used so the tool still functions.

The JSON config is the single source of truth — add new entries there,
not in this file. The JSON also documents the risk profile of each
whitelist category, which is useful when defending whitelist decisions
in viva.
"""

import json
import logging
import os
import platform

logger = logging.getLogger('reezium.detection')

# Detect platform once at import time — used to gate OS-specific rules.
_IS_LINUX = platform.system() == 'Linux'
_IS_WINDOWS = platform.system() == 'Windows'


# --- MITRE ATT&CK Technique Mapping ----------------------------------------

MITRE_TECHNIQUES = {
    'suspicious_name': {
        'id': 'T1036',
        'name': 'Masquerading',
        'tactic': 'Defense Evasion',
        'url': 'https://attack.mitre.org/techniques/T1036',
    },
    'reverse_shell': {
        'id': 'T1059',
        'name': 'Command and Scripting Interpreter',
        'tactic': 'Execution',
        'url': 'https://attack.mitre.org/techniques/T1059',
    },
    'suspicious_path': {
        'id': 'T1564',
        'name': 'Hide Artifacts',
        'tactic': 'Defense Evasion',
        'url': 'https://attack.mitre.org/techniques/T1564',
    },
    'masquerading': {
        'id': 'T1036.005',
        'name': 'Match Legitimate Name or Location',
        'tactic': 'Defense Evasion',
        'url': 'https://attack.mitre.org/techniques/T1036/005',
    },
    'suspicious_parent': {
        'id': 'T1055',
        'name': 'Process Injection',
        'tactic': 'Defense Evasion, Privilege Escalation',
        'url': 'https://attack.mitre.org/techniques/T1055',
    },
    'random_name': {
        'id': 'T1027',
        'name': 'Obfuscated Files or Information',
        'tactic': 'Defense Evasion',
        'url': 'https://attack.mitre.org/techniques/T1027',
    },
    'fileless_cmdline': {
        'id': 'T1059.001',
        'name': 'PowerShell',
        'tactic': 'Execution',
        'url': 'https://attack.mitre.org/techniques/T1059/001',
    },
    # --- New LOLBin / living-off-the-land techniques (Enhancement 2) ---
    'scheduled_task': {
        'id': 'T1053.005',
        'name': 'Scheduled Task',
        'tactic': 'Execution, Persistence, Privilege Escalation',
        'url': 'https://attack.mitre.org/techniques/T1053/005',
    },
    'service_creation': {
        'id': 'T1543.003',
        'name': 'Windows Service',
        'tactic': 'Persistence, Privilege Escalation',
        'url': 'https://attack.mitre.org/techniques/T1543/003',
    },
    'registry_run_key': {
        'id': 'T1547.001',
        'name': 'Registry Run Keys / Startup Folder',
        'tactic': 'Persistence, Privilege Escalation',
        'url': 'https://attack.mitre.org/techniques/T1547/001',
    },
    'wmi_execution': {
        'id': 'T1047',
        'name': 'Windows Management Instrumentation',
        'tactic': 'Execution',
        'url': 'https://attack.mitre.org/techniques/T1047',
    },
    'mshta_abuse': {
        'id': 'T1218.005',
        'name': 'Mshta',
        'tactic': 'Defense Evasion',
        'url': 'https://attack.mitre.org/techniques/T1218/005',
    },
    'certutil_abuse': {
        'id': 'T1140',
        'name': 'Deobfuscate/Decode Files or Information',
        'tactic': 'Defense Evasion',
        'url': 'https://attack.mitre.org/techniques/T1140',
    },
    'bitsadmin_abuse': {
        'id': 'T1197',
        'name': 'BITS Jobs',
        'tactic': 'Defense Evasion, Persistence',
        'url': 'https://attack.mitre.org/techniques/T1197',
    },
    # --- Linux-specific MITRE techniques ---
    'linux_reverse_shell': {
        'id': 'T1059.004',
        'name': 'Unix Shell',
        'tactic': 'Execution',
        'url': 'https://attack.mitre.org/techniques/T1059/004',
    },
    'linux_suspicious_path': {
        'id': 'T1564.001',
        'name': 'Hidden Files and Directories',
        'tactic': 'Defense Evasion',
        'url': 'https://attack.mitre.org/techniques/T1564/001',
    },
    'linux_lolbin': {
        'id': 'T1059.004',
        'name': 'Unix Shell LOLBin Abuse',
        'tactic': 'Execution, Defense Evasion',
        'url': 'https://attack.mitre.org/techniques/T1059/004',
    },
    'linux_cron_persistence': {
        'id': 'T1053.003',
        'name': 'Cron',
        'tactic': 'Execution, Persistence, Privilege Escalation',
        'url': 'https://attack.mitre.org/techniques/T1053/003',
    },
    'linux_suid_abuse': {
        'id': 'T1548.001',
        'name': 'Setuid and Setgid',
        'tactic': 'Privilege Escalation, Defense Evasion',
        'url': 'https://attack.mitre.org/techniques/T1548/001',
    },
    'linux_masquerading': {
        'id': 'T1036.005',
        'name': 'Match Legitimate Name or Location',
        'tactic': 'Defense Evasion',
        'url': 'https://attack.mitre.org/techniques/T1036/005',
    },
    'linux_download_exec': {
        'id': 'T1105',
        'name': 'Ingress Tool Transfer',
        'tactic': 'Command and Control',
        'url': 'https://attack.mitre.org/techniques/T1105',
    },
}


# --- Detection Rule Tables --------------------------------------------------

# Process names that are strong malware indicators.
# Matched as EXACT process names (without extension), NOT substrings.
SUSPICIOUS_EXACT_NAMES = {
    'nc', 'ncat', 'netcat', 'mimikatz', 'meterpreter',
    'cobaltstrike', 'beacon', 'lazagne', 'rubeus',
    'sharphound', 'bloodhound',
}

# Substring matches — only longer, more specific ones.
SUSPICIOUS_SUBSTRINGS = [
    'backdoor', 'keylog', 'reverse_shell', 'payload',
    'exploit', 'ransomware', 'cryptominer',
]

# Folders commonly abused by malware as drop locations (Windows + Linux).
SUSPICIOUS_PATHS = [
    '\\temp\\', '\\tmp\\', 'users\\public', '\\recycle',
    '\\perflogs\\',
    # Linux drop & staging directories
    '/tmp/', '/var/tmp/', '/dev/shm/', '/run/shm/',
]

# Critical system processes that should ONLY run from a specific path (Windows + Linux).
SYSTEM_PROCESS_PATHS = {
    'svchost.exe':  'c:\\windows\\system32',
    'csrss.exe':    'c:\\windows\\system32',
    'lsass.exe':    'c:\\windows\\system32',
    'services.exe': 'c:\\windows\\system32',
    'winlogon.exe': 'c:\\windows\\system32',
    'explorer.exe': 'c:\\windows',
    # Linux core system daemons
    'sshd':         ('/usr/sbin', '/sbin', '/usr/bin'),
    'cron':         ('/usr/sbin', '/sbin', '/usr/bin'),
    'crond':        ('/usr/sbin', '/sbin', '/usr/bin'),
    'systemd':      ('/lib/systemd', '/usr/lib/systemd', '/bin', '/sbin'),
}

# Shell processes — if these have active network connections, it indicates a reverse shell.
SHELL_PROCESSES = [
    'cmd.exe', 'powershell.exe', 'bash.exe', 'wscript.exe',
    # Linux shells
    'bash', 'sh', 'dash', 'zsh', 'ksh', 'fish',
]

# Processes whose command lines are worth inspecting for fileless indicators.
# Only these are checked — scanning every process's cmdline would be noisy.
CMDLINE_INSPECT_PROCESSES = {
    'powershell.exe', 'pwsh.exe', 'cmd.exe',
    'wscript.exe', 'cscript.exe', 'mshta.exe',
    'regsvr32.exe', 'msiexec.exe', 'rundll32.exe',
    # --- Added for LOLBin expansion (Enhancement 2) ---
    'schtasks.exe', 'sc.exe', 'reg.exe',
    'wmic.exe', 'certutil.exe', 'bitsadmin.exe',
    # --- Linux shells and LOLBins ---
    'bash', 'sh', 'dash', 'zsh',
    'curl', 'wget', 'socat', 'nc', 'ncat', 'netcat',
    'python', 'python3', 'perl', 'ruby', 'php', 'crontab',
}

# Suspicious command-line patterns — fileless malware indicators (Windows + Linux).
# Each entry is (pattern_to_match, human_description).
# Patterns are matched case-insensitively against the joined cmdline string.
#
# Sources:
#   - MITRE ATT&CK T1059.001 (PowerShell) & T1059.004 (Unix Shell)
#   - Red Canary Threat Detection Report 2023
#   - GTFOBins & SANS FOR508 "Advanced Incident Response" courseware
SUSPICIOUS_CMDLINE_PATTERNS = [
    # Encoding & obfuscation flags
    ('-enc ',                  'Encoded Command (Base64 payload)'),
    ('-encodedcommand ',       'Encoded Command (Base64 payload)'),
    ('-e ',                    'Encoded Command (short flag)'),
    # Stealth execution flags
    ('-w hidden',              'Hidden Window (stealth execution)'),
    ('-windowstyle hidden',    'Hidden Window (stealth execution)'),
    ('-nop',                   'No Profile (stealth startup)'),
    ('-noprofile',             'No Profile (stealth startup)'),
    ('-noni',                  'Non-Interactive Mode'),
    ('-noninteractive',        'Non-Interactive Mode'),
    # Policy bypass
    ('-ep bypass',             'Execution Policy Bypass'),
    ('-executionpolicy bypass','Execution Policy Bypass'),
    # In-memory execution patterns
    ('downloadstring(',        'In-Memory Download (WebClient)'),
    ('downloadfile(',          'File Download (WebClient)'),
    ('invoke-expression',      'Dynamic Code Execution (IEX)'),
    ('iex(',                   'Dynamic Code Execution (IEX alias)'),
    ('iex (',                  'Dynamic Code Execution (IEX alias)'),
    ('frombase64string',       'Base64 Decode in Memory'),
    ('net.webclient',          'WebClient Object (download cradle)'),
    ('bitstransfer',           'BITS Transfer (LOLBin download)'),
    ('start-bitstransfer',     'BITS Transfer (LOLBin download)'),
    # Reflection / assembly loading
    ('reflection.assembly',    'Reflective Assembly Loading'),
    ('[system.convert]::',     'Type Conversion (potential decode)'),
    # --- LOLBin abuse patterns (Enhancement 2) ---
    # Scheduled Task abuse (T1053.005)
    ('/create',                'Scheduled Task Creation'),
    ('schtasks',               'Scheduled Task Utility'),
    # Service creation (T1543.003)
    (' create ',               'Service Creation (persistence)'),
    (' config ',               'Service Configuration Change'),
    ('binpath=',               'Service Binary Path Modification'),
    # Registry Run Key persistence (T1547.001)
    ('\\currentversion\\run',  'Registry Run Key (persistence)'),
    ('\\currentversion\\runonce', 'Registry RunOnce Key (persistence)'),
    (' add ',                  'Registry Add Operation'),
    # WMI execution (T1047)
    ('process call create',    'WMI Process Creation'),
    (' process ',              'WMI Process Manipulation'),
    (' os get',                'WMI System Reconnaissance'),
    # MSHTA remote HTA loading (T1218.005)
    ('http://',                'Remote Resource Loading (HTTP)'),
    ('https://',               'Remote Resource Loading (HTTPS)'),
    ('javascript:',            'MSHTA JavaScript Execution'),
    ('vbscript:',              'MSHTA VBScript Execution'),
    # Certutil abuse (T1140)
    ('-urlcache',              'Certutil URL Cache (download)'),
    ('-decode',                'Certutil Decode (deobfuscation)'),
    ('-decodehex',             'Certutil Hex Decode (deobfuscation)'),
    # BITSAdmin abuse (T1197)
    ('/transfer',              'BITSAdmin File Transfer'),
    ('/addfile',               'BITSAdmin Add File'),
    # --- Linux reverse shell & execution patterns (T1059.004) ---
    ('/dev/tcp/',              'Bash /dev/tcp Network Redirect (reverse shell)'),
    ('bash -i',                'Interactive Shell Flag (reverse shell)'),
    ('sh -i',                  'Interactive Shell Flag (reverse shell)'),
    ('nc -e',                  'Netcat Command Execution Flag (reverse shell)'),
    ('ncat -e',                'Ncat Command Execution Flag (reverse shell)'),
    ('socat exec',             'Socat Command Execution Flag (reverse shell)'),
    ('socket.socket',          'Socket Connection in Script (reverse shell)'),
    ('pty.spawn',              'Interactive PTY Spawn (reverse shell)'),
    # Linux download & execute (T1105)
    ('| bash',                 'Pipe to Bash (remote script execution)'),
    ('| sh',                   'Pipe to Shell (remote script execution)'),
    ('|bash',                  'Pipe to Bash (remote script execution)'),
    ('|sh',                    'Pipe to Shell (remote script execution)'),
    # Linux SUID / privilege escalation (T1548.001)
    ('chmod +s',               'Setuid/Setgid Bit Modification (privilege escalation)'),
    ('chmod 4777',             'SUID World-Writable Bit Set (privilege escalation)'),
    # Linux anti-forensics (T1070)
    ('history -c',             'Command History Clearing (anti-forensics)'),
    ('unset histfile',         'Shell History Disabling (anti-forensics)'),
]

# Suspicious parent-child process chains (Windows + Linux).
SUSPICIOUS_CHAINS = [
    ('winword.exe',  'powershell.exe'),
    ('winword.exe',  'cmd.exe'),
    ('excel.exe',    'cmd.exe'),
    ('excel.exe',    'powershell.exe'),
    ('outlook.exe',  'wscript.exe'),
    ('outlook.exe',  'powershell.exe'),
    ('outlook.exe',  'cmd.exe'),
    ('mshta.exe',    'powershell.exe'),
    ('wscript.exe',  'powershell.exe'),
    ('cscript.exe',  'powershell.exe'),
    # --- New chains for LOLBin expansion (Enhancement 2) ---
    ('explorer.exe', 'mshta.exe'),
    ('cmd.exe',      'certutil.exe'),
    ('cmd.exe',      'bitsadmin.exe'),
    ('powershell.exe', 'certutil.exe'),
    ('powershell.exe', 'bitsadmin.exe'),
    ('winword.exe',  'mshta.exe'),
    ('excel.exe',    'mshta.exe'),
    ('outlook.exe',  'mshta.exe'),
    ('wscript.exe',  'cmd.exe'),
    ('cscript.exe',  'cmd.exe'),
    # --- Linux suspicious process chains ---
    ('apache2',      'bash'),
    ('apache2',      'sh'),
    ('nginx',        'bash'),
    ('nginx',        'sh'),
    ('httpd',        'bash'),
    ('httpd',        'sh'),
    ('php-fpm',      'bash'),
    ('php-fpm',      'sh'),
    ('php',          'sh'),
    ('php',          'bash'),
    ('python',       'bash'),
    ('python3',      'bash'),
    ('java',         'bash'),
    ('java',         'sh'),
    ('cron',         'curl'),
    ('cron',         'wget'),
    ('crond',        'curl'),
    ('crond',        'wget'),
]


# --- Whitelist loading ------------------------------------------------------

# Minimal hardcoded fallback if whitelist.json is missing or broken.
# This ensures Reezium still runs without false-positive suppression
# completely failing — the worst-case behaviour is "noisier than usual"
# rather than "crashes on startup".

_FALLBACK_SKIP = {
    'system idle process', 'system', 'registry', 'memcompression',
    'memory compression', 'idle', 'secure system', 'wininit',
}

_FALLBACK_KNOWN_GOOD = {
    'python', 'pythonw', 'py',
    'chrome', 'firefox', 'msedge', 'msedgewebview2',
    'explorer', 'dwm',
    'svchost', 'csrss', 'lsass', 'services', 'winlogon',
    'runtimebroker', 'searchindexer',
    'steam', 'steamservice', 'steamwebhelper',
    'discord', 'slack', 'teams', 'spotify',
    'code',
    'msmpsvc', 'msmpeng',
    'powershell', 'pwsh', 'cmd',
}


def _load_whitelist():
    """Load skip_processes + known_good from whitelist.json.

    Returns:
        (skip_processes_set, known_good_set)
    """
    whitelist_path = os.path.join(os.path.dirname(__file__), 'whitelist.json')

    if not os.path.exists(whitelist_path):
        logger.warning(
            "whitelist.json not found at %s — using hardcoded fallback "
            "(detection will produce more false positives)", whitelist_path
        )
        return _FALLBACK_SKIP, _FALLBACK_KNOWN_GOOD

    try:
        # utf-8-sig transparently strips the Windows BOM if Notepad
        # or another editor saved the file with one. Behaves identically
        # to utf-8 when no BOM is present. Without this, a Notepad-saved
        # whitelist would silently fail to load (falling back to the
        # minimal hardcoded set) and the user would see a flood of new
        # false positives with no obvious cause.
        with open(whitelist_path, 'r', encoding='utf-8-sig') as f:
            config = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        logger.error(
            "Failed to parse whitelist.json (%s) — using hardcoded fallback",
            e
        )
        return _FALLBACK_SKIP, _FALLBACK_KNOWN_GOOD

    # Collect skip_processes
    skip = set()
    skip_node = config.get('skip_processes', {})
    for name in skip_node.get('names', []):
        skip.add(name.lower())

    # Collect known_good — flatten across all categories
    known_good = set()
    kg_node = config.get('known_good', {})
    for category_name, category in kg_node.items():
        if not isinstance(category, dict):
            continue
        if category_name == 'description':
            continue
        for name in category.get('names', []):
            known_good.add(name.lower())

    logger.info(
        "Whitelist loaded: %d skip entries, %d known-good entries",
        len(skip), len(known_good)
    )
    return skip, known_good


# Load at import time
SKIP_PROCESSES, KNOWN_GOOD_NAMES = _load_whitelist()


# --- Scoring Functions ------------------------------------------------------

def score_suspicious_names(name_lower):
    """Add score for names matching the malware-keyword lists.

    Uses EXACT name matching (not substring) for short keywords to prevent
    false positives like 'nc' matching 'OneDrive.Sync.Service.exe'.

    MITRE: T1036 (Masquerading)

    Returns:
        (score, reasons, mitre_tags)
    """
    name_core = name_lower
    for ext in ['.exe', '.dll', '.com', '.scr']:
        if name_core.endswith(ext):
            name_core = name_core[:-len(ext)]
            break

    if name_core in SUSPICIOUS_EXACT_NAMES:
        mitre = MITRE_TECHNIQUES['suspicious_name']
        return 50, [f"Known Malicious Tool: '{name_core}' [{mitre['id']}]"], [mitre]

    for s in SUSPICIOUS_SUBSTRINGS:
        if s in name_lower:
            mitre = MITRE_TECHNIQUES['suspicious_name']
            return 50, [f"Suspicious Name Match: '{s}' [{mitre['id']}]"], [mitre]

    return 0, [], []


def score_network_anomalies(pid, name_lower, connections):
    """Detect shells with active network connections (reverse-shell signal).

    MITRE: T1059 (Command and Scripting Interpreter)

    Returns:
        (score, reasons, mitre_tags)
    """
    score = 0
    reasons = []
    mitre_tags = []
    has_conn = pid in connections
    is_shell = name_lower in SHELL_PROCESSES

    if has_conn:
        if is_shell:
            mitre = MITRE_TECHNIQUES['reverse_shell']
            score += 100
            reasons.append(
                f"Shell with Network Connection (Reverse Shell?) [{mitre['id']}]"
            )
            mitre_tags.append(mitre)
        else:
            score += 5

    return score, reasons, mitre_tags


def score_path_anomalies(name_lower, exe):
    """Detect processes running from suspicious paths or masquerading.

    MITRE: T1564 (Hide Artifacts), T1036.005 (Match Legitimate Name)

    Returns:
        (score, reasons, mitre_tags)
    """
    score = 0
    reasons = []
    mitre_tags = []

    if not exe:
        return score, reasons, mitre_tags

    exe_lower = exe.lower()

    if any(sp in exe_lower for sp in SUSPICIOUS_PATHS):
        mitre = MITRE_TECHNIQUES['suspicious_path']
        score += 40
        reasons.append(f"Running from Temporary/Public Path [{mitre['id']}]")
        mitre_tags.append(mitre)

    if name_lower in SYSTEM_PROCESS_PATHS:
        expected = SYSTEM_PROCESS_PATHS[name_lower]
        if isinstance(expected, (list, tuple)):
            mismatch = not any(exp in exe_lower for exp in expected)
            expected_display = ' or '.join(expected)
        else:
            mismatch = expected not in exe_lower
            expected_display = expected

        if mismatch:
            mitre = MITRE_TECHNIQUES['masquerading']
            score += 100
            reasons.append(
                f"System Process Impersonation "
                f"(Expected {expected_display}) [{mitre['id']}]"
            )
            mitre_tags.append(mitre)

    return score, reasons, mitre_tags


def score_parent_child(parent_pid, child_name_lower, pid_name_map):
    """Detect suspicious parent-child process chains.

    MITRE: T1055 (Process Injection) / T1059 (Command Interpreter)

    Returns:
        (score, reasons, mitre_tags)
    """
    score = 0
    reasons = []
    mitre_tags = []

    parent_name = pid_name_map.get(parent_pid)
    if not parent_name:
        return score, reasons, mitre_tags

    for sus_parent, sus_child in SUSPICIOUS_CHAINS:
        if parent_name == sus_parent and child_name_lower == sus_child:
            mitre = MITRE_TECHNIQUES['suspicious_parent']
            score += 80
            reasons.append(
                f"Suspicious Process Chain: "
                f"{sus_parent} → {sus_child} [{mitre['id']}]"
            )
            mitre_tags.append(mitre)
            break

    return score, reasons, mitre_tags


# Mapping from LOLBin process names to MITRE technique keys.
# Used by score_cmdline_anomalies() to tag alerts with the correct
# technique instead of always defaulting to T1059.001 (PowerShell).
_LOLBIN_MITRE_MAP = {
    'schtasks.exe':  'scheduled_task',
    'sc.exe':        'service_creation',
    'reg.exe':       'registry_run_key',
    'wmic.exe':      'wmi_execution',
    'mshta.exe':     'mshta_abuse',
    'certutil.exe':  'certutil_abuse',
    'bitsadmin.exe': 'bitsadmin_abuse',
    # --- Linux LOLBins ---
    'curl':          'linux_download_exec',
    'wget':          'linux_download_exec',
    'crontab':       'linux_cron_persistence',
    'bash':          'linux_reverse_shell',
    'sh':            'linux_reverse_shell',
    'dash':          'linux_reverse_shell',
    'zsh':           'linux_reverse_shell',
    'socat':         'reverse_shell',
}


def score_cmdline_anomalies(name_lower, cmdline):
    """Detect suspicious command-line flags (fileless malware indicators).

    Only inspects processes in CMDLINE_INSPECT_PROCESSES (shells, LOLBins).
    Requires TWO or more suspicious flags to fire — a single flag (e.g.
    '-nop' alone) is too noisy.  With 2+ flags, the score is strong enough
    to surface as a threat on its own (60 points > REPORTING_THRESHOLD).

    MITRE: T1059.001 (PowerShell) / T1059 (Command and Scripting Interpreter)

    Args:
        name_lower: Process name, lowercased.
        cmdline:    Command-line list from psutil (list of strings).

    Returns:
        (score, reasons, mitre_tags)
    """
    score = 0
    reasons = []
    mitre_tags = []

    # Only inspect known shells and LOLBins.
    if name_lower not in CMDLINE_INSPECT_PROCESSES:
        return score, reasons, mitre_tags

    # Build a single lowercase string from the cmdline list.
    if isinstance(cmdline, list):
        cmdline_str = ' '.join(str(c) for c in cmdline).lower()
    else:
        cmdline_str = str(cmdline).lower()

    if not cmdline_str:
        return score, reasons, mitre_tags

    # Collect all matching patterns (deduplicate by description).
    seen_descriptions = set()
    hits = []
    for pattern, description in SUSPICIOUS_CMDLINE_PATTERNS:
        if pattern in cmdline_str and description not in seen_descriptions:
            seen_descriptions.add(description)
            hits.append((pattern, description))

    # Require 2+ distinct suspicious flags to reduce false positives.
    # A single flag (e.g. just '-nop') is common in legitimate automation.
    if len(hits) >= 2:
        # Determine the appropriate MITRE technique tag based on which
        # LOLBin is running. Falls back to the generic T1059.001
        # (PowerShell) tag for shells and unknown LOLBins.
        mitre_key = _LOLBIN_MITRE_MAP.get(name_lower, 'fileless_cmdline')
        mitre = MITRE_TECHNIQUES[mitre_key]

        # Score scales with the number of suspicious flags found.
        # 2 flags = 60 pts (fires alone), 3+ flags = 80 pts (critical).
        score = min(60 + (len(hits) - 2) * 10, 80)

        flag_summary = ', '.join(desc for _, desc in hits[:4])
        reasons.append(
            f"Suspicious Command Line ({len(hits)} indicators: "
            f"{flag_summary}) [{mitre['id']}]"
        )
        mitre_tags.append(mitre)

    return score, reasons, mitre_tags


def is_known_good(process_name):
    """Check if a process name is in the known-good whitelist.

    Used by the scorer to suppress false positives on legitimate Windows
    processes and common user applications.

    Case-insensitive — always normalises to lowercase before checking.
    """
    name_core = process_name.lower()
    for ext in ('.exe', '.dll'):
        if name_core.endswith(ext):
            name_core = name_core[:-len(ext)]
            break
    return name_core in KNOWN_GOOD_NAMES