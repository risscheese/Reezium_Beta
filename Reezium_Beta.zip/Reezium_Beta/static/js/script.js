// =============================================================================
// CLIENT-SIDE DATA CACHE
// =============================================================================
// Prevents redundant API calls when switching between tabs. Each tab's data
// is cached with a timestamp. If the cache is still fresh (within TTL), the
// cached data is rendered instantly. The manual REFRESH buttons always
// bypass the cache and force a fresh fetch.
//
// TTL values are per-tab because some data changes faster than others.
// =============================================================================

const dataCache = {};

const CACHE_TTL = {
    processes: 10000,   // 10 seconds — process data changes frequently
    connections: 10000,   // 10 seconds — network connections are dynamic
    suspicious: 15000,   // 15 seconds — threat scan is expensive
    timeline: 30000,   // 30 seconds — process timeline is fairly stable
    memory: 15000,   // 15 seconds — memory overview doesn't shift fast
    specs: 120000,  // 120 seconds — hardware specs almost never change
    capture: 60000,   // 60 seconds — capture system info is static
};

/**
 * Check if cached data exists and is still fresh for the given key.
 */
function isCacheFresh(key) {
    const entry = dataCache[key];
    if (!entry) return false;
    const ttl = CACHE_TTL[key] || 5000;
    return (Date.now() - entry.timestamp) < ttl;
}

/**
 * Store data in the cache with the current timestamp.
 */
function setCacheData(key, data) {
    dataCache[key] = { data: data, timestamp: Date.now() };
}

/**
 * Get cached data (returns cached data even if stale/expired, or null if missing).
 */
function getCacheData(key) {
    const entry = dataCache[key];
    return entry ? entry.data : null;
}

/**
 * Check if a tab is currently active.
 */
function isTabActive(viewId) {
    const el = document.getElementById(viewId);
    return el && el.classList.contains('active-view');
}

/**
 * Invalidate a specific cache entry (used by REFRESH buttons).
 */
function invalidateCache(key) {
    delete dataCache[key];
}

// =============================================================================
// TAB SWITCHING
// =============================================================================

function switchView(viewId, navElement) {
    document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active-view'));
    document.getElementById(viewId).classList.add('active-view');

    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
    navElement.classList.add('active');

    // Tabs that load their data on entry — use cached data when available
    if (viewId === 'processes') loadProcessesCached();
    if (viewId === 'specs') loadSpecsCached();
    if (viewId === 'connections') loadConnectionsCached();
    if (viewId === 'suspicious') loadSuspiciousCached();
    if (viewId === 'timeline') loadTimelineCached();
    if (viewId === 'memory') loadMemoryCached();
    if (viewId === 'capture') loadCaptureCached();

    // Auto-refresh handling: the Threat Hunt page can poll itself on a
    // 10-second interval while the tab is visible. The timer is cleared
    // when the user switches to any other tab so we don't burn CPU on
    // background polling.
    if (viewId === 'suspicious') {
        startThreatHuntAutoRefresh();
    } else {
        stopThreatHuntAutoRefresh();
    }
}

// =============================================================================
// CACHE-AWARE LOADERS (STALE-WHILE-REVALIDATE)
// =============================================================================

function loadProcessesCached() {
    const cached = getCacheData('processes');
    if (cached) {
        allProcesses = cached;
        displayProcesses(cached);
    } else {
        document.getElementById('proc-body').innerHTML = '<tr><td colspan="8" style="text-align:center;" class="loading">Loading processes...</td></tr>';
    }
    if (!isCacheFresh('processes')) {
        fetchProcessesBackground();
    }
}

function loadConnectionsCached() {
    const cached = getCacheData('connections');
    if (cached) {
        renderConnections(cached);
    } else {
        document.getElementById('conn-body').innerHTML = '<tr><td colspan="6" class="loading">Loading...</td></tr>';
    }
    if (!isCacheFresh('connections')) {
        fetchConnectionsBackground();
    }
}

function loadSuspiciousCached() {
    const cached = getCacheData('suspicious');
    if (cached) {
        renderSuspicious(cached);
    } else {
        document.getElementById('threat-alerts').innerHTML = '<div class="loading">Running Heuristic Scan...</div>';
    }
    if (!isCacheFresh('suspicious')) {
        fetchSuspiciousBackground();
    }
}

function loadTimelineCached() {
    const cached = getCacheData('timeline');
    if (cached) {
        renderTimeline(cached);
    } else {
        document.getElementById('timeline-content').innerHTML = '<div class="loading">Loading...</div>';
    }
    if (!isCacheFresh('timeline')) {
        fetchTimelineBackground();
    }
}

function loadMemoryCached() {
    const cached = getCacheData('memory');
    if (cached) {
        renderMemory(cached);
    } else {
        document.getElementById('mem-overview').innerHTML = '<div class="loading">Scanning...</div>';
        document.getElementById('mem-top').innerHTML = '<div class="loading">Scanning...</div>';
        document.getElementById('mem-regions').innerHTML = '<div class="loading">Scanning...</div>';
    }
    if (!isCacheFresh('memory')) {
        fetchMemoryBackground();
    }
}

function loadSpecsCached() {
    const cached = getCacheData('specs');
    if (cached) {
        renderSpecs(cached);
    } else {
        document.getElementById('spec-os-list').innerHTML = '<div class="loading">Loading...</div>';
        document.getElementById('spec-cpu-list').innerHTML = '<div class="loading">Loading...</div>';
        document.getElementById('spec-disk-list').innerHTML = '<div class="loading">Loading...</div>';
        document.getElementById('spec-net-list').innerHTML = '<div class="loading">Loading...</div>';
    }
    if (!isCacheFresh('specs')) {
        fetchSpecsBackground();
    }
}

function loadCaptureCached() {
    const cached = getCacheData('capture');
    if (cached) {
        renderCapture(cached);
    }
    if (!isCacheFresh('capture')) {
        fetchCaptureBackground();
    }
}

// =============================================================================
// BACKGROUND REFRESH FUNCTIONS
// =============================================================================

function fetchProcessesBackground() {
    fetch('/api/processes')
        .then(res => {
            if (!res.ok) throw new Error('Failed to fetch processes');
            return res.json();
        })
        .then(data => {
            allProcesses = data;
            setCacheData('processes', data);
            if (isTabActive('processes')) {
                displayProcesses(data);
            }
        })
        .catch(err => {
            console.error('Error background loading processes:', err);
        });
}

function fetchConnectionsBackground() {
    const filter = document.getElementById('conn-filter').value;
    let url = '/api/connections';
    if (filter) url += '?status=' + filter;

    fetch(url)
        .then(res => {
            if (!res.ok) throw new Error('Failed to fetch connections');
            return res.json();
        })
        .then(data => {
            setCacheData('connections', data);
            if (isTabActive('connections')) {
                renderConnections(data);
            }
        })
        .catch(err => {
            console.error('Error background loading connections:', err);
        });
}

function fetchSuspiciousBackground() {
    fetch('/api/suspicious')
        .then(res => {
            if (!res.ok) throw new Error('Failed to analyze threats');
            return res.json();
        })
        .then(data => {
            setCacheData('suspicious', data);
            if (isTabActive('suspicious')) {
                renderSuspicious(data);
            }
        })
        .catch(err => {
            console.error('Error background loading suspicious:', err);
        });
}

function fetchTimelineBackground() {
    fetch('/api/timeline')
        .then(res => {
            if (!res.ok) throw new Error('Failed to load timeline');
            return res.json();
        })
        .then(data => {
            setCacheData('timeline', data);
            if (isTabActive('timeline')) {
                renderTimeline(data);
            }
        })
        .catch(err => {
            console.error('Error background loading timeline:', err);
        });
}

function fetchMemoryBackground() {
    fetch('/api/memory')
        .then(res => {
            if (!res.ok) throw new Error('Failed to scan memory');
            return res.json();
        })
        .then(data => {
            setCacheData('memory', data);
            if (isTabActive('memory')) {
                renderMemory(data);
            }
        })
        .catch(err => {
            console.error('Error background loading memory:', err);
        });
}

function fetchSpecsBackground() {
    fetch('/api/specs')
        .then(res => {
            if (!res.ok) throw new Error('Failed to load specs');
            return res.json();
        })
        .then(data => {
            setCacheData('specs', data);
            if (isTabActive('specs')) {
                renderSpecs(data);
            }
        })
        .catch(err => {
            console.error('Error background loading specs:', err);
        });
}

function fetchCaptureBackground() {
    fetch('/api/capture/info?_=' + Date.now())
        .then(res => {
            if (!res.ok) throw new Error('Failed to load capture info');
            return res.json();
        })
        .then(data => {
            setCacheData('capture', data);
            if (isTabActive('capture')) {
                renderCapture(data);
            }
        })
        .catch(err => {
            console.error('Error background loading capture:', err);
        });
}

// --- Threat Hunt auto-refresh ----------------------------------------------
// Default: enabled. Interval: 10 seconds. Can be toggled by the user
// via the AUTO-REFRESH button on the Threat Hunt page.

let threatHuntTimer = null;
let threatHuntAutoRefreshEnabled = true;
const THREAT_HUNT_REFRESH_INTERVAL_MS = 10000;   // 10 seconds

function startThreatHuntAutoRefresh() {
    if (!threatHuntAutoRefreshEnabled) return;
    if (threatHuntTimer !== null) return;        // already running
    threatHuntTimer = setInterval(() => {
        // Only refresh if the Threat Hunt tab is still active. Defensive
        // check in case the timer fires during a tab transition.
        const tab = document.getElementById('suspicious');
        if (tab && tab.classList.contains('active-view')) {
            analyzeSuspicious();
        }
    }, THREAT_HUNT_REFRESH_INTERVAL_MS);
    updateAutoRefreshButton();
}

function stopThreatHuntAutoRefresh() {
    if (threatHuntTimer !== null) {
        clearInterval(threatHuntTimer);
        threatHuntTimer = null;
    }
}

function toggleThreatHuntAutoRefresh() {
    threatHuntAutoRefreshEnabled = !threatHuntAutoRefreshEnabled;
    if (threatHuntAutoRefreshEnabled) {
        startThreatHuntAutoRefresh();
    } else {
        stopThreatHuntAutoRefresh();
    }
    updateAutoRefreshButton();
}

function updateAutoRefreshButton() {
    const btn = document.getElementById('auto-refresh-btn');
    if (!btn) return;
    if (threatHuntAutoRefreshEnabled) {
        btn.innerText = 'AUTO-REFRESH: ON';
        btn.style.opacity = '1';
    } else {
        btn.innerText = 'AUTO-REFRESH: OFF';
        btn.style.opacity = '0.6';
    }
}


let allProcesses = [];
let cpuChart, ramChart;
let isExe = false;

function initCharts() {
    const commonOptions = {
        responsive: true,
        maintainAspectRatio: false,
        animation: false,
        scales: {
            y: {
                beginAtZero: true,
                max: 100,
                grid: { color: '#333' },
                ticks: { color: '#888' }
            },
            x: {
                display: false
            }
        },
        plugins: {
            legend: { display: false }
        },
        elements: {
            line: {
                tension: 0.4,
                borderColor: '#00ff41',
                borderWidth: 2,
                fill: true,
                backgroundColor: 'rgba(0, 255, 65, 0.1)'
            },
            point: { radius: 0 }
        }
    };

    const cpuCtx = document.getElementById('cpuChart').getContext('2d');
    cpuChart = new Chart(cpuCtx, {
        type: 'line',
        data: {
            labels: Array(20).fill(''),
            datasets: [{ data: Array(20).fill(0) }]
        },
        options: commonOptions
    });

    const ramCtx = document.getElementById('ramChart').getContext('2d');
    ramChart = new Chart(ramCtx, {
        type: 'line',
        data: {
            labels: Array(20).fill(''),
            datasets: [{ data: Array(20).fill(0) }]
        },
        options: commonOptions
    });
}

function showError(elementId, message) {
    document.getElementById(elementId).innerHTML = `<div class="error-message">Error: ${message}</div>`;
}

let _dashboardFetchInFlight = false;

function updateDashboard() {
    // Skip if the previous poll hasn't returned yet. Prevents request
    // pile-up when the server is under load.
    if (_dashboardFetchInFlight) return;
    _dashboardFetchInFlight = true;

    fetch('/api/stats')
        .then(res => {
            if (!res.ok) throw new Error('Network response was not ok');
            return res.json();
        })
        .then(data => {
            document.getElementById('dash-cpu').innerText = data.cpu.toFixed(1) + '%';
            if (cpuChart) {
                cpuChart.data.datasets[0].data.push(data.cpu);
                cpuChart.data.datasets[0].data.shift();
                cpuChart.update();
            }

            document.getElementById('dash-ram').innerText = data.ram.toFixed(1) + '%';
            if (ramChart) {
                ramChart.data.datasets[0].data.push(data.ram);
                ramChart.data.datasets[0].data.shift();
                ramChart.update();
            }

            document.getElementById('dash-procs').innerText = data.process_count;
            document.getElementById('dash-conns').innerText = data.connection_count;
            document.getElementById('dash-threats').innerText = data.suspicious_count + ' THREATS';
            document.getElementById('dash-uptime').innerText = data.uptime;
        })
        .catch(err => {
            console.error('Dashboard update error:', err);
        })
        .finally(() => {
            _dashboardFetchInFlight = false;
        });
}

// =============================================================================
// PROCESSES — fetch + cache, then render
// =============================================================================

function refreshProcesses() {
    invalidateCache('processes');
    document.getElementById('proc-body').innerHTML = '<tr><td colspan="8" style="text-align:center;" class="loading">Loading processes...</td></tr>';
    fetch('/api/processes')
        .then(res => {
            if (!res.ok) throw new Error('Failed to fetch processes');
            return res.json();
        })
        .then(data => {
            console.log('Processes loaded:', data.length);
            allProcesses = data;
            setCacheData('processes', data);
            displayProcesses(data);
        })
        .catch(err => {
            console.error('Error loading processes:', err);
            document.getElementById('proc-body').innerHTML = '<tr><td colspan="8" style="text-align:center;" class="error-message">Error loading processes. Check console for details.</td></tr>';
        });
}

function displayProcesses(procs) {
    let html = '';
    if (procs.length === 0) {
        html = '<tr><td colspan="8" style="text-align:center; color: var(--warning);">No processes found</td></tr>';
    } else {
        procs.forEach(p => {
            const statusClass = p.status === 'running' ? 'normal' : 'warning';
            const status = p.status ? p.status.toUpperCase() : 'UNKNOWN';
            const memPercent = p.memory_percent != null ? p.memory_percent.toFixed(2) : '0.00';
            const cpuPercent = p.cpu_percent != null ? p.cpu_percent.toFixed(1) : '0.0';
            html += `<tr>
                <td>${p.pid}</td>
                <td style="color:#fff; font-weight:bold;">${p.name || 'Unknown'}</td>
                <td class="${statusClass}">${status}</td>
                <td>${memPercent}%</td>
                <td>${cpuPercent}%</td>
                <td>${p.num_threads || '0'}</td>
                <td>${p.connections || 0}</td>
                <td>
                    <button class="btn btn-danger" onclick="killProc(${p.pid})">KILL</button>
                    <button class="btn" onclick="inspectProc(${p.pid})">INSPECT</button>
                </td>
            </tr>`;
        });
    }
    document.getElementById('proc-body').innerHTML = html;
}

function filterProcesses() {
    const search = document.getElementById('proc-search').value.toLowerCase();
    const filtered = allProcesses.filter(p =>
        (p.name && p.name.toLowerCase().includes(search)) ||
        (p.pid && p.pid.toString().includes(search))
    );
    displayProcesses(filtered);
}

function killProc(pid) {
    if (confirm("Terminate process " + pid + "?")) {
        fetch('/api/kill/' + pid, { method: 'POST' })
            .then(res => res.json())
            .then(data => {
                alert(data.message);
                invalidateCache('processes');
                refreshProcesses();
            })
            .catch(err => {
                alert('Error killing process: ' + err.message);
            });
    }
}

function inspectProc(pid) {
    fetch('/api/process/' + pid)
        .then(res => {
            if (!res.ok) throw new Error('Failed to fetch process details');
            return res.json();
        })
        .then(data => {
            if (data.error) {
                alert('Error: ' + data.error);
                return;
            }
            let info = `PROCESS INSPECTION - PID: ${pid}\n\n`;
            info += `Name: ${data.name}\n`;
            info += `Status: ${data.status}\n`;
            info += `Parent PID: ${data.ppid}\n`;
            info += `Created: ${data.create_time}\n`;
            info += `User: ${data.username}\n`;
            info += `Executable: ${data.exe}\n`;
            info += `Command Line: ${data.cmdline}\n`;
            info += `\nMemory Info:\n`;
            if (data.memory_info) {
                info += `RSS: ${(data.memory_info.rss / 1024 / 1024).toFixed(2)} MB\n`;
                info += `VMS: ${(data.memory_info.vms / 1024 / 1024).toFixed(2)} MB\n`;
            }
            alert(info);
        })
        .catch(err => {
            alert('Error inspecting process: ' + err.message);
        });
}

// =============================================================================
// CONNECTIONS — fetch + cache, then render
// =============================================================================

function refreshConnections() {
    invalidateCache('connections');
    const filter = document.getElementById('conn-filter').value;
    let url = '/api/connections';
    if (filter) url += '?status=' + filter;

    document.getElementById('conn-body').innerHTML = '<tr><td colspan="6" class="loading">Loading...</td></tr>';
    fetch(url)
        .then(res => {
            if (!res.ok) throw new Error('Failed to fetch connections');
            return res.json();
        })
        .then(data => {
            setCacheData('connections', data);
            renderConnections(data);
        })
        .catch(err => {
            console.error('Connection error:', err);
            showError('conn-body', 'Failed to load connections');
        });
}

function renderConnections(data) {
    let html = '';
    if (data.length === 0) {
        html = '<tr><td colspan="6" style="text-align:center;">No active connections</td></tr>';
    } else {
        data.forEach(c => {
            const statusClass = c.status === 'ESTABLISHED' ? 'normal' : 'warning';
            html += `<tr>
                <td>${c.pid || 'N/A'}</td>
                <td style="color:#fff;">${c.process || 'Unknown'}</td>
                <td>${c.local}</td>
                <td>${c.remote || 'N/A'}</td>
                <td class="${statusClass}">${c.status}</td>
                <td>${c.type}</td>
            </tr>`;
        });
    }
    document.getElementById('conn-body').innerHTML = html;
}

// =============================================================================
// THREAT HUNT — fetch + cache, then render
// =============================================================================

function analyzeSuspicious() {
    invalidateCache('suspicious');
    document.getElementById('threat-alerts').innerHTML = '<div class="loading">Running Heuristic Scan...</div>';
    fetch('/api/suspicious?enrich=true')
        .then(res => {
            if (!res.ok) throw new Error('Failed to analyze threats');
            return res.json();
        })
        .then(data => {
            setCacheData('suspicious', data);
            renderSuspicious(data);
        })
        .catch(err => {
            console.error('Threat analysis error:', err);
            showError('threat-alerts', 'Failed to analyze threats');
        });
}

function renderSuspicious(data) {
    let html = '';

    // Threat Level Summary
    let level = 'LOW';
    let color = 'var(--neon)';
    if (data.threats.length > 0) {
        level = 'ELEVATED';
        color = 'var(--warning)';
    }
    if (data.threats.some(t => t.severity === 'critical' || t.severity === 'high')) {
        level = 'CRITICAL';
        color = 'var(--danger)';
    }

    html += `<div style="margin-bottom: 20px; padding: 15px; border: 1px solid ${color}; color: ${color}; text-align: center;">
        <h3 style="margin:0;">THREAT LEVEL: ${level}</h3>
        <small>${data.threats.length} potential anomalies detected</small>
    </div>`;

    if (data.threats.length === 0) {
        html += '<div class="alert alert-info">No immediate heuristic matches found.</div>';
    } else {
        data.threats.forEach((t, idx) => {
            let alertClass = 'alert-info';
            let badgeClass = 'badge-info';

            if (t.severity === 'medium') { alertClass = 'alert-warning'; badgeClass = 'badge-warning'; }
            if (t.severity === 'high') { alertClass = 'alert-danger'; badgeClass = 'badge-danger'; }
            if (t.severity === 'critical') { alertClass = 'alert-danger'; badgeClass = 'badge-danger blink'; }

            // Build MITRE technique badges (if any).
            let mitreHtml = '';
            if (t.mitre_techniques && t.mitre_techniques.length > 0) {
                mitreHtml = '<div class="mitre-tags-row">';
                t.mitre_techniques.forEach(tech => {
                    mitreHtml += `<a href="${tech.url}" target="_blank" rel="noopener noreferrer" class="badge badge-mitre" title="${tech.name}">${tech.id}</a>`;
                });
                if (t.mitre_tactics && t.mitre_tactics.length > 0) {
                    mitreHtml += `<span class="mitre-tactic">${t.mitre_tactics.join(', ')}</span>`;
                }
                mitreHtml += '</div>';
            }

            // Build cloud intelligence badges (if enrichment data present).
            let cloudHtml = '';
            if (t.cloud_intel) {
                cloudHtml = '<div class="cloud-intel-row">';
                if (t.cloud_intel.virustotal) {
                    const vt = t.cloud_intel.virustotal;
                    if (vt.found) {
                        const mal = vt.malicious || 0;
                        const total = vt.total_engines || 0;
                        const label = vt.popular_threat_name ? ` (${vt.popular_threat_name})` : '';
                        if (mal > 0) {
                            cloudHtml += `<span class="badge badge-virustotal" title="VirusTotal: ${mal}/${total} security vendors flagged this hash">🛡️ VT: ${mal}/${total} Malicious${label}</span>`;
                        } else {
                            cloudHtml += `<span class="badge badge-virustotal-clean" title="VirusTotal: 0/${total} security vendors flagged this hash">🛡️ VT: Clean (0/${total})</span>`;
                        }
                    } else if (vt.found === false) {
                        cloudHtml += `<span class="badge badge-virustotal-unknown" title="VirusTotal: File hash not in VT database">🛡️ VT: Unknown Hash</span>`;
                    }
                }
                if (t.cloud_intel.ip_reputation) {
                    t.cloud_intel.ip_reputation.forEach(ip => {
                        if (ip.abuse_confidence > 50) {
                            cloudHtml += `<span class="badge badge-abuseipdb" title="AbuseIPDB">⚠ IP ${ip.ip}: ${ip.abuse_confidence}% abuse</span>`;
                        } else if (ip.abuse_confidence > 0) {
                            cloudHtml += `<span class="badge badge-abuseipdb-low" title="AbuseIPDB">IP ${ip.ip}: ${ip.abuse_confidence}% abuse</span>`;
                        }
                    });
                }
                cloudHtml += '</div>';
            }

            // Store threat data for AI explain (use data attribute via index).
            const threatDataAttr = encodeURIComponent(JSON.stringify(t));

            html += `<div class="alert ${alertClass}" style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <span class="badge ${badgeClass}">${t.severity.toUpperCase()}</span>
                    <strong>${t.type}</strong> <span style="color:#888;">(Score: ${t.score})</span>: ${t.message}
                    <div style="margin-top:5px; font-size:0.85rem; color:#ccc; word-break:break-all;">
                        <span style="color:#666;">PID: ${t.pid}</span> | ${t.details}
                    </div>
                    ${mitreHtml}
                    ${cloudHtml}
                </div>
                <div style="display: flex; gap: 5px; flex-shrink: 0;">
                    <button class="btn btn-ai btn-sm" onclick="explainThreat('${threatDataAttr}')" style="padding: 2px 8px; font-size: 0.7rem;">🤖 AI</button>
                    <button class="btn btn-sm" onclick="inspectProc(${t.pid})" style="padding: 2px 8px; font-size: 0.7rem;">INSPECT</button>
                    ${t.pid ? `<button class="btn btn-danger btn-sm" onclick="killProc(${t.pid})" style="padding: 2px 8px; font-size: 0.7rem;">KILL</button>` : ''}
                </div>
            </div>`;
        });
    }
    document.getElementById('threat-alerts').innerHTML = html;
}

// =============================================================================
// TIMELINE — fetch + cache, then render
// =============================================================================

function loadTimeline() {
    invalidateCache('timeline');
    document.getElementById('timeline-content').innerHTML = '<div class="loading">Loading...</div>';
    fetch('/api/timeline')
        .then(res => {
            if (!res.ok) throw new Error('Failed to load timeline');
            return res.json();
        })
        .then(data => {
            setCacheData('timeline', data);
            renderTimeline(data);
        })
        .catch(err => {
            console.error('Timeline error:', err);
            showError('timeline-content', 'Failed to load timeline');
        });
}

function renderTimeline(data) {
    let html = '';
    data.forEach(item => {
        html += `<div class="timeline-item">
            <strong style="color: var(--neon);">${item.time}</strong> - 
            <span style="color: #fff;">${item.event}</span>
            <br><small>${item.details}</small>
        </div>`;
    });
    document.getElementById('timeline-content').innerHTML = html || '<p>No events recorded yet.</p>';
}

// =============================================================================
// MEMORY — fetch + cache, then render
// =============================================================================

function scanMemory() {
    invalidateCache('memory');
    document.getElementById('mem-overview').innerHTML = '<div class="loading">Scanning...</div>';
    document.getElementById('mem-top').innerHTML = '<div class="loading">Scanning...</div>';
    document.getElementById('mem-regions').innerHTML = '<div class="loading">Scanning...</div>';

    fetch('/api/memory')
        .then(res => {
            if (!res.ok) throw new Error('Failed to scan memory');
            return res.json();
        })
        .then(data => {
            setCacheData('memory', data);
            renderMemory(data);
        })
        .catch(err => {
            console.error('Memory scan error:', err);
            showError('mem-overview', 'Failed to scan memory');
            showError('mem-top', 'Failed to scan memory');
            showError('mem-regions', 'Failed to scan memory');
        });
}

function renderMemory(data) {
    document.getElementById('mem-overview').innerHTML = `
        <div class="spec-row"><span class="spec-key">TOTAL</span><span class="spec-val">${data.total} GB</span></div>
        <div class="spec-row"><span class="spec-key">AVAILABLE</span><span class="spec-val">${data.available} GB</span></div>
        <div class="spec-row"><span class="spec-key">USED</span><span class="spec-val">${data.used} GB</span></div>
        <div class="spec-row"><span class="spec-key">PERCENT</span><span class="spec-val">${data.percent}%</span></div>
    `;

    let topHtml = '';
    data.top_processes.forEach((p, index) => {
        topHtml += `<div class="spec-row" style="padding: 12px 0;">
            <span class="spec-key" style="color: ${index < 3 ? 'var(--danger)' : '#888'};">${p.name} (${p.pid})</span>
            <span class="spec-val" style="color: ${index < 3 ? 'var(--danger)' : '#fff'}; font-weight: bold;">${p.memory} MB</span>
        </div>`;
    });
    document.getElementById('mem-top').innerHTML = topHtml;

    let regionsHtml = '<table><thead><tr><th>Category</th><th>Size</th><th>Type</th></tr></thead><tbody>';
    data.regions.forEach(r => {
        regionsHtml += `<tr><td>${r.name}</td><td>${r.size}</td><td>${r.type}</td></tr>`;
    });
    regionsHtml += '</tbody></table>';
    document.getElementById('mem-regions').innerHTML = regionsHtml;
}

function analyzeDump() {
    const pid = document.getElementById('dump-pid').value;
    if (!pid) {
        alert('Please enter a PID');
        return;
    }
    document.getElementById('dump-results').innerHTML = '<div class="loading">Analyzing...</div>';

    fetch('/api/dump/' + pid)
        .then(res => {
            if (!res.ok) throw new Error('Failed to analyze dump');
            return res.json();
        })
        .then(data => {
            if (data.error) {
                showError('dump-results', data.error);
                return;
            }
            let html = '<h4>MEMORY ANALYSIS RESULTS</h4>';
            html += `<div class="spec-row"><span class="spec-key">Process</span><span class="spec-val">${data.name}</span></div>`;
            html += `<div class="spec-row"><span class="spec-key">PID</span><span class="spec-val">${data.pid}</span></div>`;
            html += `<div class="spec-row"><span class="spec-key">Memory Usage</span><span class="spec-val">${data.memory_mb} MB</span></div>`;
            html += '<h4 style="margin-top: 20px;">OPEN FILES</h4>';
            if (data.files.length > 0) {
                data.files.forEach(f => {
                    html += `<div style="padding: 5px; border-bottom: 1px solid #222;">${f}</div>`;
                });
            } else {
                html += '<p>No open files</p>';
            }
            html += '<h4 style="margin-top: 20px;">LOADED LIBRARIES</h4>';
            if (data.libs.length > 0) {
                data.libs.slice(0, 10).forEach(l => {
                    html += `<div style="padding: 5px; border-bottom: 1px solid #222; font-size: 0.8rem;">${l}</div>`;
                });
            } else {
                html += '<p>No libraries found</p>';
            }
            document.getElementById('dump-results').innerHTML = html;
        })
        .catch(err => {
            console.error('Dump analysis error:', err);
            showError('dump-results', 'Failed to analyze memory dump');
        });
}

function exportProcesses() {
    fetch('/api/processes')
        .then(res => {
            if (!res.ok) throw new Error('Failed to fetch processes');
            return res.json();
        })
        .then(data => {
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'processes_' + Date.now() + '.json';
            a.click();
            URL.revokeObjectURL(url);
        })
        .catch(err => {
            alert('Export failed: ' + err.message);
        });
}

// =============================================================================
// SPECS — fetch + cache, then render
// =============================================================================

function loadSpecs() {
    invalidateCache('specs');
    fetch('/api/specs')
        .then(res => {
            if (!res.ok) throw new Error('Failed to load specs');
            return res.json();
        })
        .then(data => {
            setCacheData('specs', data);
            renderSpecs(data);
        })
        .catch(err => {
            console.error('Specs error:', err);
            showError('spec-os-list', 'Failed to load specs');
        });
}

function renderSpecs(data) {
    document.getElementById('spec-os-list').innerHTML = `
        <div class="spec-row"><span class="spec-key">SYSTEM</span><span class="spec-val">${data.os}</span></div>
        <div class="spec-row"><span class="spec-key">RELEASE</span><span class="spec-val">${data.release}</span></div>
        <div class="spec-row"><span class="spec-key">NODE NAME</span><span class="spec-val">${data.node}</span></div>
        <div class="spec-row"><span class="spec-key">VERSION</span><span class="spec-val">${data.version}</span></div>
    `;
    document.getElementById('spec-cpu-list').innerHTML = `
        <div class="spec-row"><span class="spec-key">PROCESSOR</span><span class="spec-val">${data.processor}</span></div>
        <div class="spec-row"><span class="spec-key">PHYSICAL CORES</span><span class="spec-val">${data.phys_cores}</span></div>
        <div class="spec-row"><span class="spec-key">TOTAL THREADS</span><span class="spec-val">${data.total_cores}</span></div>
        <div class="spec-row"><span class="spec-key">ARCHITECTURE</span><span class="spec-val">${data.architecture}</span></div>
    `;

    let diskHtml = '';
    data.disks.forEach(d => {
        diskHtml += `<div class="spec-row"><span class="spec-key">${d.device}</span><span class="spec-val">${d.used}/${d.total} (${d.percent}%)</span></div>`;
    });
    document.getElementById('spec-disk-list').innerHTML = diskHtml || '<p>No disk info</p>';

    let netHtml = '';
    data.network.forEach(n => {
        netHtml += `<div class="spec-row"><span class="spec-key">${n.interface}</span><span class="spec-val">${n.address}</span></div>`;
    });
    document.getElementById('spec-net-list').innerHTML = netHtml || '<p>No network interfaces</p>';
}

// =============================================================================
// RAM CAPTURE — fetch + cache, then render
// =============================================================================

function initCapture() {
    invalidateCache('capture');
    fetch('/api/capture/info?_=' + Date.now())
        .then(res => {
            if (!res.ok) throw new Error('Failed to load capture info');
            return res.json();
        })
        .then(data => {
            setCacheData('capture', data);
            renderCapture(data);
        })
        .catch(err => {
            console.error('Capture init error:', err);
        });
}

function renderCapture(data) {
    document.getElementById('cap-hostname').innerText = data.hostname;
    document.getElementById('cap-os').innerText = data.os;
    document.getElementById('cap-ram').innerText = data.ram_total;
    document.getElementById('cap-uptime').innerText = data.uptime;
    document.getElementById('cap-time').innerText = new Date().toLocaleString();
    isExe = data.is_exe;

    const btn = document.querySelector('#capture .btn-danger');
    const alertBox = document.getElementById('capture-progress');

    // Gate capture on admin/root privileges
    if (data.is_admin) {
        if (btn) {
            btn.disabled = false;
            btn.style.opacity = '1';
            btn.style.cursor = 'pointer';
            btn.innerText = "⚠ START ACQUISITION";
            btn.onclick = startCapture;
        }
        if (alertBox) {
            alertBox.style.display = 'none';
        }
    } else {
        if (btn) {
            btn.disabled = true;
            btn.style.opacity = '0.4';
            btn.style.cursor = 'not-allowed';
            btn.innerText = "🔒 ADMIN REQUIRED";
        }
        if (alertBox) {
            alertBox.style.display = 'block';
            document.getElementById('capture-status').innerText =
                'Administrator/root privileges required. Restart with sudo (Linux) or Run as Administrator (Windows).';
        }
    }
}

function showCaptureInfo() {
    alert(`REEZIUM IMAGER - RAM CAPTURE - VOLATILITY COMPATIBLE

This tool provides forensic-grade memory acquisition with multiple output formats compatible with Volatility Framework 2 & 3.

SUPPORTED OUTPUT FORMATS:

📁 .raw (RAW Memory Dump)
   • Industry standard format
   • Compatible with: Volatility 2/3, Rekall, Magnet AXIOM
   • Direct physical memory copy
   • Best for: Complete forensic analysis

📁 .lime (LiME Format)
   • Linux Memory Extractor format
   • Includes ELF headers with metadata
   • Compatible with: Volatility 3 (with LiME plugin)
   • Best for: Linux systems

📁 .mem (Generic Memory Image)
   • Generic extension for memory dumps
   • Treated as raw image by most tools
   • Best for: Broad compatibility

VOLATILITY 3 USAGE:
vol3 -f memory_dump.raw windows.info
vol3 -f memory_dump.raw windows.pslist
vol3 -f memory_dump.raw windows.netscan
vol3 -f memory_dump.raw windows.malfind

CHAIN OF CUSTODY:
✓ Cryptographic hashes (MD5, SHA256, SHA512)
✓ Investigator attribution
✓ Timestamp preservation
✓ System fingerprinting
✓ Acquisition metadata`);
}

async function startCapture() {
    const caseId = document.getElementById('case-id').value || 'UNKNOWN';
    const investigator = document.getElementById('investigator').value || 'UNKNOWN';
    const fmt = document.getElementById('output-format').value;

    // Show progress UI
    document.getElementById('capture-progress').style.display = 'block';
    document.getElementById('capture-bar').style.width = '0%';
    document.getElementById('capture-status').innerText = 'Starting capture agent...';

    const options = {
        case_id: caseId,
        investigator: investigator,
        format: fmt,
        timestamp: new Date().toISOString()
    };

    try {
        // 1. Start the Job
        const startRes = await fetch('/api/capture/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(options)
        });

        if (!startRes.ok) {
            const err = await startRes.json();
            throw new Error(err.error || 'Failed to start');
        }

        // 2. Poll for Status
        let complete = false;
        while (!complete) {
            await sleep(2000); // Poll every 2 seconds

            const statusRes = await fetch('/api/capture/status');
            const statusData = await statusRes.json();

            if (statusData.status === 'running') {
                // Pulse the bar to show activity since we can't get exact % from mini winpmem
                document.getElementById('capture-bar').style.width = '50%';
                document.getElementById('capture-status').innerText = statusData.message;
            }
            else if (statusData.status === 'completed') {
                complete = true;
                document.getElementById('capture-bar').style.width = '100%';
                document.getElementById('capture-status').innerText = 'Acquisition Complete!';

                // Trigger Download or Reveal
                const filename = statusData.filename;

                let html = `<h4>CAPTURE SUCCESSFUL</h4>`;
                html += `<div class="alert alert-info">File saved as: ${filename}</div>`;

                if (isExe) {
                    html += `<button onclick="revealFile('${filename}')" class="btn" style="display:block; width:100%; margin-top:10px;">📂 SHOW IN FOLDER</button>`;
                } else {
                    const downloadUrl = `/api/download/${filename}`;
                    html += `<a href="${downloadUrl}" class="btn" style="display:block; text-align:center; margin-top:10px;">⬇ DOWNLOAD RAW DUMP</a>`;
                }

                html += `<p style="margin-top:10px; font-size:0.8rem; color:#888;">Compatible with Volatility 3: <code>vol3 -f ${filename} ${statusData.captured_os === 'Linux' ? 'linux.pslist.PsList' : 'windows.info'}</code></p>`;

                document.getElementById('capture-artifacts').innerHTML = html;
            }
            else if (statusData.status === 'error') {
                throw new Error(statusData.message);
            }
        }

    } catch (err) {
        document.getElementById('capture-bar').style.background = 'var(--danger)';
        document.getElementById('capture-status').innerText = 'FAILED: ' + err.message;
        alert('Capture Error: ' + err.message);
    }
}

function updateProgress(percent, status) {
    document.getElementById('capture-bar').style.width = percent + '%';
    document.getElementById('capture-status').innerText = status;
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Dead code removed: displayCaptureResults, downloadCaptureFiles,
// createRawDump, createLimeDump, createDmpDump, createVmemDump,
// forceEnableCapture — these were leftovers from the old client-side
// capture system and are no longer called.

function revealFile(filename) {
    fetch('/api/reveal/' + filename)
        .catch(err => alert('Failed to open folder: ' + err));
}

// =============================================================================
// AI EXPLAIN PANEL
// =============================================================================

/**
 * Convert basic markdown to HTML for rendering LLM responses.
 * Handles headers, bold, code, lists, and paragraphs.
 */
function markdownToHtml(md) {
    if (!md) return '';
    let html = md
        // Horizontal rules (--- lines, must be checked before headers)
        .replace(/^---+$/gm, '<hr style="border-color:#333; margin:16px 0;">')
        // Headers (support optional emoji/unicode after ##)
        .replace(/^#### (.+)$/gm, '<h4>$1</h4>')
        .replace(/^### (.+)$/gm, '<h3>$1</h3>')
        .replace(/^## (.+)$/gm, '<h2>$1</h2>')
        .replace(/^# (.+)$/gm, '<h1>$1</h1>')
        // Bold and italic
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.+?)\*/g, '<em>$1</em>')
        // Inline code
        .replace(/`([^`]+)`/g, '<code>$1</code>')
        // Unordered lists (including indented bullets)
        .replace(/^\s*[\-\*] (.+)$/gm, '<li>$1</li>')
        // Ordered lists (including indented items)
        .replace(/^\s*\d+\. (.+)$/gm, '<li>$1</li>');

    // Wrap consecutive <li> in <ul>
    html = html.replace(/(<li>.*<\/li>\n?)+/g, match => '<ul>' + match + '</ul>');

    // Paragraphs: split by double newline
    html = html.split(/\n\n+/).map(block => {
        block = block.trim();
        if (!block) return '';
        // Don't wrap blocks that are already wrapped in block elements
        if (block.startsWith('<h') || block.startsWith('<ul') ||
            block.startsWith('<ol') || block.startsWith('<hr')) {
            return block;
        }
        return '<p>' + block.replace(/\n/g, '<br>') + '</p>';
    }).join('\n');

    return html;
}

// Store last-explained threat so Regenerate button can resend it.
let _currentExplainThreat = null;

/**
 * Open the AI explain panel and request an explanation for a threat.
 */
function explainThreat(encodedThreatData) {
    const threat = JSON.parse(decodeURIComponent(encodedThreatData));
    _currentExplainThreat = threat;
    _fetchExplanation(threat, false);
}

/**
 * Re-fetch the explanation for the current threat, bypassing the server cache.
 */
function regenExplanation() {
    if (!_currentExplainThreat) return;
    _fetchExplanation(_currentExplainThreat, true);
}

/**
 * Internal: open panel, show loading, call API, render result.
 * @param {object}  threat        - threat dict
 * @param {boolean} forceRefresh  - if true, pass force_refresh flag to bypass cache
 */
function _fetchExplanation(threat, forceRefresh) {
    // Show panel with loading state
    document.getElementById('ai-explain-overlay').classList.add('active');
    document.getElementById('ai-explain-panel').classList.add('active');
    document.getElementById('ai-explain-content').innerHTML = `
        <div class="ai-loading">
            <div class="ai-loading-spinner"></div>
            <div>${forceRefresh ? 'Regenerating analysis...' : 'Analyzing threat...'}</div>
            <div style="font-size: 0.8rem; color: #666; margin-top: 8px;">PID ${threat.pid} — ${threat.name}</div>
        </div>
    `;
    document.getElementById('ai-explain-provider').textContent = '';
    document.getElementById('ai-explain-cache-status').textContent = '';
    document.getElementById('ai-regen-btn').style.display = 'none';

    // Call the AI explain endpoint
    fetch('/api/ai/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ threat: threat, force_refresh: forceRefresh }),
    })
        .then(res => {
            if (!res.ok) throw new Error('AI explain request failed');
            return res.json();
        })
        .then(data => {
            if (data.error && !data.explanation) {
                document.getElementById('ai-explain-content').innerHTML = `
                <div class="error-message">${data.error}</div>
            `;
                return;
            }

            // Render the explanation (convert markdown to HTML)
            const htmlContent = markdownToHtml(data.explanation);
            document.getElementById('ai-explain-content').innerHTML = htmlContent;

            // Scroll back to top after rendering
            document.getElementById('ai-explain-body') &&
                (document.querySelector('.ai-explain-body').scrollTop = 0);

            // Footer: provider badge + cache status + regen button
            const provider = data.provider || 'unknown';
            const model = data.model || '';
            document.getElementById('ai-explain-provider').innerHTML =
                `<span class="ai-badge">${provider.toUpperCase()}${model ? ' / ' + model : ''}</span>`;
            document.getElementById('ai-explain-cache-status').textContent =
                data.cached ? '⚡ cached' : '✓ fresh';
            document.getElementById('ai-regen-btn').style.display = 'inline-block';
        })
        .catch(err => {
            console.error('AI explain error:', err);
            document.getElementById('ai-explain-content').innerHTML = `
            <div class="error-message">Failed to get AI explanation: ${err.message}</div>
        `;
        });
}

/**
 * Close the AI explain slide-out panel.
 */
function closeExplainPanel() {
    document.getElementById('ai-explain-overlay').classList.remove('active');
    document.getElementById('ai-explain-panel').classList.remove('active');
}

// Close panel on Escape key
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeExplainPanel();
});

setInterval(updateDashboard, 2000);
document.addEventListener('DOMContentLoaded', initCharts);
updateDashboard();