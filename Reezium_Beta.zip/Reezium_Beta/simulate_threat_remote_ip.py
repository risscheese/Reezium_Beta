"""
simulate_threat_remote_ip.py
----------------------------
Remote-IP Threat Simulation Script for Reezium Imager Testing.

This script is the companion to simulate_threat.py. It spawns a simulated
suspicious background process that connects to a KNOWN MALICIOUS public IP
address so that Reezium's AbuseIPDB cloud-intel lookup returns a real,
high-confidence abuse report — letting you verify the full reporting pipeline
end-to-end.

Detection profile triggered in Reezium:
    1. Heuristics:   PowerShell with Hidden Window, NoProfile & Encoded Command
    2. MITRE ATT&CK: T1059.001 (PowerShell Execution)
    3. Network:      Shell with an outbound established connection
    4. Cloud Intel:  AbuseIPDB query → known-malicious remote IP hit
    5. AI Explainer: Ready to be analyzed by the Gemini AI SOC Analyst
    6. Auto-Report:  Reezium reports the IP to AbuseIPDB on your behalf

REMOTE IP USED:
    185.220.101.45  — Tor exit node / known scanner, consistently flagged on
                      AbuseIPDB with 100 % confidence and thousands of reports.
                      Connecting to it on port 9001 (Tor ORPort) is harmless
                      — the TCP handshake stalls or is refused; no data is sent.

The process stays active until YOU terminate it (via Ctrl+C here, or
by clicking the 'KILL' button on Reezium's dashboard).
"""

import os
import sys
import time
import socket
import subprocess
import signal

# ── Simulation Target ─────────────────────────────────────────────────────────
# 185.220.101.45 is a well-known Tor exit relay that consistently scores
# 100 % abuse confidence on AbuseIPDB with tens-of-thousands of reports.
# Port 9001 is the standard Tor ORPort — connecting to it is benign (the
# kernel just completes the TCP handshake; no payload is sent).
REMOTE_IP   = "185.220.101.45"
REMOTE_PORT = 9001          # Tor ORPort — harmless SYN, no data exchange
# ─────────────────────────────────────────────────────────────────────────────


def main():
    print("=" * 60)
    print("    REEZIUM IMAGER — REMOTE IP THREAT SIMULATION")
    print("=" * 60)
    print("[*] Target remote IP  :", REMOTE_IP)
    print("[*] Target remote port:", REMOTE_PORT)
    print("[*] AbuseIPDB score   : ~100 % (Tor exit / known scanner)")
    print()
    print("[*] Launching simulated suspicious process...")

    # PowerShell command: keep an open outbound TCP connection to the remote IP.
    # This mimics beaconing / reverse-shell C2 activity without sending any data.
    ps_command = (
        f"while ($true) {{ "
        f"  try {{ "
        f"    $client = New-Object System.Net.Sockets.TcpClient('{REMOTE_IP}', {REMOTE_PORT}); "
        f"    while ($client.Connected) {{ Start-Sleep -Seconds 2 }} "
        f"  }} catch {{ Start-Sleep -Seconds 2 }} "
        f"}}"
    )

    cmd = [
        "powershell.exe",
        "-NoProfile",
        "-WindowStyle", "Hidden",
        "-ExecutionPolicy", "Bypass",
        "-Command", ps_command,
    ]

    try:
        proc = subprocess.Popen(
            cmd,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        )
    except Exception as e:
        print(f"[-] Failed to spawn PowerShell: {e}")
        print("[*] Falling back to pure-Python simulated socket process...")
        proc = None

    print()
    if proc:
        print(f"[+] SIMULATED THREAT RUNNING!")
        print(f"[+] Target Process  : powershell.exe")
        print(f"[+] Process PID     : {proc.pid}")
        print(f"[+] Remote IP       : {REMOTE_IP}:{REMOTE_PORT}")
    else:
        # Fallback: open the socket directly from this process
        pid = os.getpid()
        print(f"[+] SIMULATED THREAT RUNNING (Self PID: {pid})")
        sock = None
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            sock.connect((REMOTE_IP, REMOTE_PORT))
            print(f"[+] Socket connected to {REMOTE_IP}:{REMOTE_PORT}")
        except Exception as ex:
            print(f"[~] Socket attempt: {ex} (connection refused/timeout is fine — IP is still visible)")

    print()
    print("=" * 60)
    print("DETECTION PROFILE TRIGGERED IN REEZIUM:")
    print("  • Heuristic :  Suspicious Command Line (Hidden, NoProfile, Bypass)")
    print("  • MITRE Tag :  T1059.001 (PowerShell Execution)")
    print("  • Network   :  Shell with Active Outbound Connection")
    print(f"  • Remote IP :  {REMOTE_IP}  (100 % AbuseIPDB confidence)")
    print("  • Cloud Intel: AbuseIPDB lookup → HIGH abuse score")
    print("  • Auto-Report: Reezium will report this IP to AbuseIPDB")
    print("=" * 60)
    print()
    print("[!] INSTRUCTIONS:")
    print("  1. Open Reezium Imager dashboard (or refresh 'THREAT HUNT').")
    print("  2. Look for the HIGH / CRITICAL alert on powershell.exe.")
    print(f"  3. Confirm the remote IP shown is {REMOTE_IP}.")
    print("  4. Check the AbuseIPDB panel — score should be ~100 %.")
    print("  5. Verify Reezium auto-reports the IP to AbuseIPDB.")
    print("  6. Click '🤖 AI' to test your Gemini threat explanation.")
    print("  7. Click 'KILL' in Reezium or press Ctrl+C here to terminate.")
    print("=" * 60)
    print()

    try:
        while True:
            if proc and proc.poll() is not None:
                print(f"\n[*] Process PID {proc.pid} was terminated (killed via Reezium or closed)!")
                break
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[*] Stopping simulation...")
        if proc and proc.poll() is None:
            proc.terminate()
            proc.kill()
        print("[+] Process terminated safely. Goodbye!")


if __name__ == "__main__":
    main()
